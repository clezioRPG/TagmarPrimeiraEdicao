// Validações puras, sem dependência da API do Foundry.
export function validarEvocacao({dificuldades, nivel, dificuldade, gasto, karma, estagio}) {
  if (![nivel,dificuldade,gasto,karma,estagio].every(Number.isInteger)) return "Os valores de evocação devem ser inteiros.";
  if (nivel < 0 || estagio < 1 || karma < 0 || dificuldade < 1 || !Array.isArray(dificuldades) || !dificuldades.includes(dificuldade)) return "O efeito escolhido não existe na lista desta magia.";
  if (nivel < dificuldade) return "O nível na magia é menor que a dificuldade do efeito.";
  if (gasto < dificuldade) return "O Karma gasto não pode ser menor que a dificuldade do efeito.";
  if (gasto > estagio) return "Não é possível gastar mais Karma que o Estágio.";
  if (gasto > karma) return "Karma insuficiente.";
  return null;
}
export function validarCompraNivel({nivelAtual, estagio, custo, disponiveis, gastos}) {
  if (![nivelAtual,estagio,custo,disponiveis,gastos].every(Number.isInteger)) return "Dados de compra inválidos.";
  if (nivelAtual < 0 || estagio < 1 || custo < 1 || gastos < 0 || disponiveis < 0) return "Dados de compra inválidos.";
  if (nivelAtual >= estagio) return "O nível não pode ultrapassar o Estágio.";
  if (disponiveis - gastos < custo) return "Pontos insuficientes.";
  return null;
}
export function totalCreditosHistoricos(historico, estagio, grupo = null) {
  if (!Array.isArray(historico) || !Number.isInteger(estagio) || estagio < 1 || historico.length < estagio) return null;
  const entradas = historico.slice(0, estagio);
  const valores = entradas.map(v => grupo === null ? v : v?.[grupo]);
  if (!valores.every(v => Number.isInteger(v) && v >= 0)) return null;
  return valores.reduce((a,b) => a+b,0);
}

// Revalidação de compras após uma confirmação assíncrona: o nível efetivo
// inclui armas legadas, e não apenas o nível registrado em gruposArmas.
export function validarCompraConfirmada({nivelInicial, nivelAtual, estagio, custo, disponiveis, gastos}) {
  if (nivelAtual !== nivelInicial) return "O nível mudou durante a confirmação; tente novamente.";
  return validarCompraNivel({nivelAtual, estagio, custo, disponiveis, gastos});
}

// A edição de um atributo não deve modificar os créditos históricos válidos.
// Dados incompletos são explicitamente identificados, nunca corrigidos com zeros.
export function estadoHistorico(historico, estagio, grupos = null) {
  if (!Array.isArray(historico) || historico.length === 0) return "ausente";
  if (!Number.isInteger(estagio) || estagio < 1 || historico.length < estagio) return "incompleto";
  if (grupos === null) return totalCreditosHistoricos(historico, estagio) === null ? "invalido" : "valido";
  if (!Array.isArray(grupos) || grupos.length === 0 || !grupos.every(g => typeof g === "string" && g.length > 0)) return "invalido";
  return grupos.every(g => totalCreditosHistoricos(historico, estagio, g) !== null) ? "valido" : "invalido";
}

// Auditoria dos saldos: evita exibir créditos negativos como se fossem válidos.
// O histórico de compras continua sendo responsabilidade da ficha do Foundry.
export function validarSaldoCompra({creditos, gastos, custo}) {
  if (![creditos, gastos, custo].every(Number.isInteger) || creditos < 0 || gastos < 0 || custo < 1)
    return "Saldo ou custo inválido.";
  if (gastos > creditos) return "Os gastos registrados ultrapassam os créditos disponíveis.";
  if (creditos - gastos < custo) return "Pontos insuficientes.";
  return null;
}
