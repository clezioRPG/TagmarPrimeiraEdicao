/** Diagnóstico somente leitura para suporte no Foundry VTT 14. */
export function diagnosticarSistema() {
  const tipos = new Set(["personagem", "npc", "criatura"]);
  const atores = game.actors?.contents ?? [];
  const cenas = game.scenes?.contents ?? [];
  const tokens = cenas.flatMap(c => c.tokens?.contents ?? []).filter(t => tipos.has(t.actor?.type));
  const inconsistencias = tokens.filter(t => t.displayBars !== 0 || t.bar1?.attribute || t.bar2?.attribute);
  const prototipos = atores.filter(a => tipos.has(a.type) && (a.prototypeToken?.displayBars !== 0 || a.prototypeToken?.bar1?.attribute || a.prototypeToken?.bar2?.attribute));
  const relatorio = {
    sistema: game.system?.id,
    versaoSistema: game.system?.version,
    versaoFoundry: game.version,
    mestre: Boolean(game.user?.isGM),
    atores: atores.length,
    cenas: cenas.length,
    tokensTagmar: tokens.length,
    tokensComBarras: inconsistencias.length,
    prototiposComBarras: prototipos.length,
    compendiosTagmar: (game.packs?.contents ?? []).filter(p => p.metadata?.packageName === "tagmar1e").length
  };
  console.table(relatorio);
  return relatorio;
}
