import { atacarCriatura, aplicarDano, testarMoral } from "./rolagens.mjs";

const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;

// converte objetos {0:..,1:..} (formularios) em listas, recursivamente
export function arrayfy(v) {
  if (Array.isArray(v)) return v.map(arrayfy);
  if (v && typeof v === "object") {
    const ks = Object.keys(v);
    if (ks.length && ks.every(function (k) { return /^\d+$/.test(k); })) {
      return ks.sort(function (a, b) { return Number(a) - Number(b); }).map(function (k) { return arrayfy(v[k]); });
    }
    const o = {};
    for (const k of ks) o[k] = arrayfy(v[k]);
    return o;
  }
  return v;
}

export class CriaturaFicha extends HandlebarsApplicationMixin(ActorSheetV2) {
  static DEFAULT_OPTIONS = {
    classes: ["tagmar1e", "ficha", "criatura"],
    position: {width: 920, height: 620},
    window: {resizable: true},
    form: {submitOnChange: true},
    actions: {
      addAtaque: CriaturaFicha.#addAtaque,
      delAtaque: CriaturaFicha.#delAtaque,
      atacar: CriaturaFicha.#atacar,
      aplicarDano: CriaturaFicha.#aplicarDano,
      restaurarAbsorcao: CriaturaFicha.#restaurarAbsorcao,
      testarMoral: CriaturaFicha.#testarMoral
    }
  };

  static PARTS = {
    ficha: {template: "systems/tagmar1e/templates/criatura.hbs", scrollable: [""]}
  };

  async _onRender(context, options) {
    await super._onRender(context, options);
    const tema = game.settings.get("tagmar1e", "tema");
    for (const classe of ["tema-pergaminho", "tema-escuro", "tema-moderno"]) this.element.classList.remove(classe);
    this.element.classList.add("tema-" + (tema === "simples" ? "moderno" : tema));
    // Controle independente das actions da ficha; falhas aqui nao impedem a abertura.
    const raiz = this.element;
    if (raiz && !raiz.querySelector(".tg-seletor-tema")) {
      const barra = document.createElement("nav");
      barra.className = "tg-seletor-tema";
      barra.setAttribute("aria-label", "Tema visual da ficha");
      const titulo = document.createElement("span");
      titulo.textContent = "Visual da ficha: ";
      barra.append(titulo);
      for (const [valor, rotulo] of [["pergaminho", "Pergaminho"], ["escuro", "Medieval escuro"], ["moderno", "Moderno"]]) {
        const botao = document.createElement("button");
        botao.type = "button";
        botao.textContent = rotulo;
        botao.dataset.tema = valor;
        botao.addEventListener("click", async (event) => {
          event.preventDefault();
          try {
            await game.settings.set("tagmar1e", "tema", valor);
            // Atualiza esta ficha mesmo se o listener global nao estiver disponivel.
            for (const classe of ["tema-pergaminho", "tema-escuro", "tema-moderno"]) raiz.classList.remove(classe);
            raiz.classList.add("tema-" + valor);
          } catch (erro) {
            console.error("Tagmar | Falha ao mudar tema", erro);
            ui.notifications.error("Nao foi possivel mudar o tema da ficha.");
          }
        });
        barra.append(botao);
      }
      const destino = raiz.querySelector(".window-content") ?? raiz;
      destino.prepend(barra);
    }

  }

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const s = this.actor.system;
    ctx.actor = this.actor;
    ctx.system = s;
    ctx.editable = this.isEditable;
    ctx.ataques = s.ataques.map(function (a, i) {
      const valores = a.ataque.map(function (v, j) { return {j: j, v: v}; });
      const dano = [0, 1, 2, 3].map(function (j) { return {j: j, v: a.dano.length === 4 ? a.dano[j] : ""}; });
      return {i: i, tipo: a.tipo, valores: valores, dano: dano};
    });
    ctx.absTxt = s.absorcaoTotal > 0 ? s.absorcaoAtual + " de " + s.absorcaoTotal : "sem armadura";
    return ctx;
  }

  _prepareSubmitData(event, form, formData, updateData) {
    const data = super._prepareSubmitData(event, form, formData, updateData);
    const at = foundry.utils.getProperty(data, "system.ataques");
    if (at !== undefined) foundry.utils.setProperty(data, "system.ataques", arrayfy(at));
    return data;
  }

  static async #addAtaque(event, target) {
    const lista = this.actor.toObject().system.ataques;
    lista.push({tipo: "Ataque", ataque: new Array(21).fill(0), dano: [4, 3, 2, 1]});
    await this.actor.update({"system.ataques": lista});
  }

  static async #delAtaque(event, target) {
    const lista = this.actor.toObject().system.ataques;
    lista.splice(Number(target.dataset.index), 1);
    await this.actor.update({"system.ataques": lista});
  }

  static async #atacar(event, target) { await atacarCriatura(this.actor, Number(target.dataset.index)); }
  static async #aplicarDano(event, target) { await aplicarDano(this.actor); }
  static async #testarMoral(event, target) { await testarMoral(this.actor); }
  static async #restaurarAbsorcao(event, target) { await this.actor.update({"system.absorcao.restante": null}); }
}
