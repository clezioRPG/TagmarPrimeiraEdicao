// Tabelas do Tagmar 1a edicao (1991), digitalizadas do livro. Sem dependencias do Foundry.
export const COLS = {"-7": "VVVVVVBBBBBBBBYYLRAC", "-6": "VVVVVBBBBBBBBYYYLRAC", "-5": "VVVVBBBBBBBBYYYYLRAC", "-4": "VVVBBBBBBBBBYYYLLRAC", "-3": "VVVBBBBBBBBYYYYLLRAC", "-2": "VVVBBBBBBBBYYYLLRRAC", "-1": "VVBBBBBBBBYYYYLLRRAC", "0": "VVBBBBBBBBYYYLLLRRAC", "1": "VBBBBBBBBYYYYLLRRAAC", "2": "VBBBBBBBBYYYLLLRRAAC", "3": "VBBBBBBBYYYYLLLRRAAC", "4": "VBBBBBBBYYYLLLRRRAAC", "5": "VBBBBBBYYYYLLLRRAAAC", "6": "VBBBBBBYYYLLLLRRAAAC", "7": "VBBBBBYYYYLLLRRRAAAC", "8": "VBBBBBYYYLLLLRRRAAAC", "9": "VBBBBYYYYLLLLRRAAAAC", "10": "VBBBBYYYLLLLRRRAAAAC", "11": "VBBBYYYYLLLLRRRAAAAC", "12": "VBBBYYYLLLLLRRRAAAAC", "13": "VBBYYYYLLLLRRRAAAACC", "14": "VBBYYYLLLLLRRRAAAACC", "15": "VBYYYYLLLLLRRRAAAACC", "16": "VBYYYLLLLLRRRRAAAACC", "17": "VYYYYLLLLLRRRAAAAACC", "18": "VYYYLLLLLRRRRAAAAACC", "19": "VYYYLLLLLRRRRAAAAACC", "20": "VYYLLLLLRRRRRAAAAACC"};
export const CRIT = {"corte": {"cinza": "Oponente é decapitado.", "azul": "100% de dano. Corte vara um olho. A dor paralisa o adversário por duas rodadas.", "vermelho": "75% de dano. Corte no músculo do braço inutiliza o mesmo por uma semana.", "laranja": "75% de dano. Corte na cabeça põe adversário em coma por um dia se o mesmo não estiver usando elmo.", "amarelo": "50% de dano. Com um belo golpe, não só atinge o inimigo, como também o desarma.", "branco": "50% de dano. Corte no ombro impõe um ajuste de -4 por 1 dia.", "verde": "25% de dano. Corte no músculo do braço dá um ajuste de -4 na próxima rodada."}, "esmagamento": {"cinza": "Afundamento torácico destrói os pulmões do adversário.", "azul": "100% de dano. Golpe no pulso destrói a articulação, obrigando à amputação em 2 dias. O inimigo é paralisado por uma rodada.", "vermelho": "75% de dano. Pancada na cabeça. Elmo se parte (caso não seja mágico). Se não estiver de elmo, entra em coma por dois dias.", "laranja": "75% de dano. Escudo do inimigo se quebra (caso não seja mágico). Na ausência deste, seu braço se quebra (cura em 1 mês).", "amarelo": "50% de dano. Golpe no tórax derruba o adversário, que deixa cair sua arma (ou o que estiver segurando).", "branco": "50% de dano. Golpe duro no ombro paralisa o oponente na próxima rodada.", "verde": "25% de dano. Golpe no tronco desequilibra o adversário na próxima rodada, dando um ajuste de -4."}, "penetracao": {"cinza": "Golpe certeiro perfura o coração.", "azul": "100% de dano. Estocada na mão a inutiliza permanentemente. A dor paralisa o inimigo por duas rodadas.", "vermelho": "75% de dano. Perfuração no músculo do braço o inutiliza por uma semana.", "laranja": "75% de dano. Golpe no tronco derruba adversário que estiver usando escudo. Caso contrário, incapacita-o por 2 dias.", "amarelo": "50% de dano. Estocada no peito paralisa o adversário pelas próximas 3 rodadas.", "branco": "50% de dano. Penetração causa ajuste de -4 por dois dias. Se for flecha, o ajuste será de -6 até a mesma ser retirada.", "verde": "25% de dano. Estocada na perna reduz o movimento à metade e causa um ajuste de -2 por uma hora."}, "garras": {"cinza": "Força do golpe rasga a jugular.", "azul": "100% de dano. Ataque ao olho rasga o globo ocular, paralisando o adversário por duas rodadas.", "vermelho": "75% de dano. Ataque rasga o braço causando ajuste de -8 por 2 dias.", "laranja": "75% de dano. A ferocidade do golpe derruba o adversário impedindo-o de atacar pelas próximas 3 rodadas.", "amarelo": "75% de dano. Feroz ataque à mão desarma o inimigo.", "branco": "50% de dano. Rasgo na mão impede o adversário de realizar o seu próximo ataque.", "verde": "25% de dano. Ataque desequilibra o inimigo, levando-o a cair e a perder uma rodada."}, "magia": {"cinza": "Impacto total da magia mata o adversário.", "azul": "100% de dano. Impacto no pé causa a destruição do mesmo. O adversário fica paralisado por duas rodadas.", "vermelho": "75% de dano. Poder da magia leva o inimigo à inconsciência por meia hora.", "laranja": "75% de dano. Potente impacto paralisa o adversário, impedindo-o de atacar por 3 rodadas.", "amarelo": "50% de dano. A força da magia arremessa o adversário a 2 metros de distância, fazendo com que ele deixe cair sua arma.", "branco": "50% de dano. Impacto no braço causa um ajuste de -4 por um dia.", "verde": "25% de dano. Poder da magia atordoa o inimigo, impedindo que o mesmo realize o seu próximo ataque."}};
export const FALHA = {"cinza": "Em um golpe ruim, erra o adversário.", "azul": "O descontrole lhe dá um ajuste de -4 nas próximas 3 rodadas.", "vermelho": "Ataque precipitado causa 25% de dano em si mesmo.", "laranja": "Ataque desastroso causa 50% de dano em si mesmo.", "amarelo": "Sua arma escapa de suas mãos, caindo a 3 metros de distância.", "branco": "Tropeção o impede de realizar o seu próximo ataque.", "verde": "Faça um ataque no seu companheiro mais próximo."};
// arma: [valor na defesa 1, valor na defesa 9, valor na defesa 16 (cada faixa cai 1 por defesa), dano maximo]
export const ARMAS = {"Faca": [1, -3, -6, 8], "Punhal": [1, -2, -5, 12], "Cajado": [1, -1, -4, 12], "Porrete": [2, -1, -5, 12], "Machado": [2, -1, -4, 16], "Machado de guerra": [1, 3, 1, 20], "Gládio": [3, 0, -4, 16], "Espada": [3, 0, -3, 20], "Clava": [2, -1, -5, 16], "Maça": [0, 1, -2, 20], "Martelo de guerra": [0, 1, -1, 16], "Lança leve": [2, -1, -3, 16], "Lança pesada": [1, -1, -3, 20], "Arco simples": [4, 1, -2, 16], "Arco composto": [4, 1, -2, 20], "Espada de mão e meia (uma mão)": [2, 1, -1, 20], "Espada de mão e meia (duas mãos)": [0, 0, 1, 20], "Montante": [0, 2, 5, 24], "Maça de armas": [1, 2, 0, 20], "Mangual": [-2, 1, 4, 24], "Lança de cavalaria": [-1, 1, 4, 24]};
export const ARMADURAS = {"Nenhuma": 0, "Couro leve": 3, "Couro rígido": 6, "Cota de malha parcial": 9, "Cota de malha completa": 12, "Couraça parcial": 15};
export const ESCUDOS = {"Nenhum": 0, "Escudo pequeno": 3, "Escudo grande": 5};
export const ELMOS = {"Nenhum": 0, "Elmo aberto": 1, "Elmo fechado": 2};

export const COR = {
  V: {nome: "Verde",    hex: "#2d8d24", fg: "#fff", txt: "FALHA", pct: 0},
  B: {nome: "Branco",   hex: "#fbfbfc", fg: "#222", txt: "Errou o golpe", pct: 0},
  Y: {nome: "Amarelo",  hex: "#ea9d26", fg: "#222", txt: "25% do dano máximo", pct: 25},
  L: {nome: "Laranja",  hex: "#e46c23", fg: "#fff", txt: "50% do dano máximo", pct: 50},
  R: {nome: "Vermelho", hex: "#d7261a", fg: "#fff", txt: "75% do dano máximo", pct: 75},
  A: {nome: "Azul",     hex: "#1a719c", fg: "#fff", txt: "100% do dano máximo", pct: 100},
  C: {nome: "Cinza",    hex: "#93989c", fg: "#fff", txt: "CRÍTICO", pct: 0}
};
export const CHAVE = {V: "verde", B: "branco", Y: "amarelo", L: "laranja", R: "vermelho", A: "azul", C: "cinza"};
export const RANK = {V: 0, B: 1, Y: 2, L: 3, R: 4, A: 5, C: 6};
export const NIVEIS = [
  {nome: "Rotineiro", cor: "B"}, {nome: "Fácil", cor: "Y"}, {nome: "Médio", cor: "L"},
  {nome: "Difícil", cor: "R"}, {nome: "Muito difícil", cor: "A"}, {nome: "Absurdo", cor: "C"}
];

// Tabela II-5.8: valor da caracteristica -> ajuste
export function ajusteDe(v) {
  if (v < 3) return -7;
  if (v <= 4) return -5;
  if (v <= 6) return -3;
  if (v <= 8) return -1;
  if (v <= 12) return 0;
  if (v <= 15) return 1;
  if (v <= 17) return 2;
  if (v <= 19) return 3;
  if (v === 20) return 4;
  if (v === 21) return 5;
  return 6;
}

// Tabela IV-8.2: ajuste da arma contra a Defesa (1 a 21)
export function valorContraDefesa(arma, defesa) {
  const s = ARMAS[arma];
  const seg = defesa <= 8 ? 0 : (defesa <= 15 ? 1 : 2);
  const inicio = [1, 9, 16][seg];
  return s[seg] - (defesa - inicio);
}

// Tabelas IV-10.3a e IV-10.3b: dano de cada porcentagem (sem o ajuste de Forca)
export function danoBase(arma, pct) {
  return Math.round(ARMAS[arma][3] * pct / 100);
}

// menor resultado de d20 que da sucesso: primeira linha da coluna com cor igual ou melhor que a dificuldade (sem contar o verde)
export function minimoParaSucesso(coluna, corAlvo) {
  const linhas = COLS[String(coluna)];
  for (let i = 0; i < 20; i++) {
    if (linhas[i] !== "V" && RANK[linhas[i]] >= RANK[corAlvo]) return i + 1;
  }
  return null;
}

export function badge(letra, n) {
  const c = COR[letra];
  return '<span style="display:inline-block;min-width:1.6em;text-align:center;padding:1px 8px;border:1px solid #000;border-radius:3px;background:' + c.hex + ';color:' + c.fg + ';font-weight:bold">' + n + '</span> <b>' + c.nome + '</b>';
}

// ---------- Valores derivados (capitulos II, IV e V) ----------

// "175", "1,75 m" ou "70 kg" -> numero (ou null)
export function lerNumero(texto) {
  const m = String(texto === undefined || texto === null ? "" : texto).replace(",", ".").match(/\d+(\.\d+)?/);
  return m ? parseFloat(m[0]) : null;
}

// Tabela IV-3.1.1: Energia Fisica = coluna (Forca+Fisico) + linha (peso) - 2; zero ou menos = inviavel
const EF_PESO = [19, 24, 29, 35, 39, 45, 49, 59, 69, 79, 89, 99, 109, 130];
const EF_SOMA = [5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35, 38, 41, 44];
export function efDe(soma, peso) {
  if (peso === null || peso === undefined) return null;
  let ri = EF_PESO.findIndex(function (m) { return peso <= m; });
  if (ri < 0) ri = EF_PESO.length - 1;
  let ci = EF_SOMA.findIndex(function (m) { return soma <= m; });
  if (ci < 0) ci = EF_SOMA.length - 1;
  const v = ci + ri - 2;
  return v > 0 ? v : 0;
}

// Tabelas IV-3.2.1a (estagio 1) e IV-3.2.1b (estagios seguintes): 1d10 -> faixas 1, 2-3, 4-5, 6-7, 8-9, 10
export const PROFISSOES = ["Guerreiro", "Ladrão", "Sacerdote", "Mago", "Rastreador", "Bardo"];
export const EH_INICIAL = {
  "Guerreiro": [15, 16, 17, 18, 19, 20], "Ladrão": [9, 10, 11, 12, 13, 14], "Sacerdote": [9, 10, 11, 12, 13, 14],
  "Mago": [3, 4, 5, 6, 7, 8], "Rastreador": [12, 13, 14, 15, 16, 17], "Bardo": [6, 7, 8, 9, 10, 11]
};
export const EH_ESTAGIO = {
  "Guerreiro": [5, 6, 7, 8, 9, 10], "Ladrão": [3, 4, 5, 6, 7, 8], "Sacerdote": [3, 4, 5, 6, 7, 8],
  "Mago": [1, 2, 3, 4, 5, 6], "Rastreador": [4, 5, 6, 7, 8, 9], "Bardo": [2, 3, 4, 5, 6, 7]
};
export function faixaD10(n) { return n <= 1 ? 0 : (n <= 3 ? 1 : (n <= 5 ? 2 : (n <= 7 ? 3 : (n <= 9 ? 4 : 5)))); }
export function achaProfissao(texto) {
  const t = String(texto || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  const radicais = {"Guerreiro": "guerr", "Ladrão": "ladr", "Sacerdote": "sacer", "Mago": "mag", "Rastreador": "rastr", "Bardo": "bard"};
  for (const p of PROFISSOES) {
    if (t.indexOf(radicais[p]) === 0) return p;
  }
  return null;
}

// Tabela IV-7.1: Defesa por armadura e Agilidade (2-12, 13-15, 16-17, 18-19, 20-21, 22-24, 25-27, 28-29); escudo +1
const DEF_AGI = [12, 15, 17, 19, 21, 24, 27, 29];
const DEF_TAB = {
  "Nenhuma": [1, 2, 3, 4, 5, 6, 7, 8],
  "Couro leve": [2, 3, 4, 5, 6, 7, 8, 8],
  "Couro rígido": [9, 10, 11, 12, 13, 14, 15, 15],
  "Cota de malha parcial": [10, 11, 12, 13, 14, 15, 15, 15],
  "Cota de malha completa": [16, 17, 18, 19, 20, 20, 21, 21],
  "Couraça parcial": [17, 18, 19, 20, 20, 21, 21, 21]
};
// devolve {consciente, inconsciente}; inconsciente = como se a Agilidade fosse 2 a 12
export function defesaDe(armadura, agilidade, escudo) {
  const linha = DEF_TAB[armadura] || DEF_TAB["Nenhuma"];
  let ci = DEF_AGI.findIndex(function (m) { return agilidade <= m; });
  if (ci < 0) ci = DEF_AGI.length - 1;
  const bonus = escudo && escudo !== "Nenhum" ? 1 : 0;
  return {consciente: linha[ci] + bonus, inconsciente: linha[0] + bonus};
}

// Tabela V-5.2: Karma por estagio conforme a Aura (2-8, 9-12, 13-15, 16-17, 18-19, 20, 21)
export function karmaDe(aura, estagio) {
  const base = aura <= 8 ? 0 : (aura <= 12 ? 0.5 : (aura <= 15 ? 1 : (aura <= 17 ? 2 : (aura <= 19 ? 3 : (aura === 20 ? 4 : 5)))));
  return Math.ceil(base * estagio);
}


// Tabela de Resistencia: o valor depende so da diferenca (Forca do Ataque - Forca da Defesa); resultado de 2 a 20
const RESIST = {"-13": 3, "-12": 3, "-11": 4, "-10": 4, "-9": 5, "-8": 5, "-7": 6, "-6": 6, "-5": 7, "-4": 7, "-3": 8, "-2": 9, "-1": 10,
  "0": 11, "1": 12, "2": 13, "3": 14, "4": 15, "5": 15, "6": 16, "7": 16, "8": 17, "9": 17, "10": 18, "11": 18, "12": 19, "13": 19};
export function resistenciaDe(ataque, defesa) {
  const a = Math.max(1, Math.min(20, Math.round(ataque)));
  const d = Math.max(1, Math.min(20, Math.round(defesa)));
  const dif = a - d;
  if (dif <= -14) return 2;
  if (dif >= 14) return 20;
  return RESIST[String(dif)];
}


// ---------- Evolucao (capitulo VII) e grupos de armas (tabelas IV-8.1a e IV-8.1b) ----------
// Tabela VII-3: PE minimo de cada estagio (1 a 20)
export const PE_MINIMO = [0, 11, 21, 31, 46, 61, 76, 96, 116, 136, 166, 196, 226, 266, 306, 356, 406, 466, 526, 596];
export function estagioPorPE(pe) {
  let e = 1;
  for (let i = 0; i < PE_MINIMO.length; i++) { if (pe >= PE_MINIMO[i]) e = i + 1; }
  return e;
}

// Tabela IV-8.1a: pontos de combate por estagio, por profissao
export const PONTOS_COMBATE = {"Guerreiro": 7, "Ladrão": 3, "Sacerdote": 3, "Mago": 1, "Rastreador": 5, "Bardo": 2};

// Tabela IV-8.1b: grupos, custo por nivel; cada arma tem Forca minima e o uso por faixa de altura (97, 135, 155, 180 e 200 cm)
export const ALTURAS_ARMAS = [97, 135, 155, 180, 200];
export const GRUPOS_ARMAS = {Cl: {nome: "corte leve", custo: 1}, El: {nome: "esmagamento leve", custo: 1}, CmM: {nome: "corte médio (machados)", custo: 2},
  CmE: {nome: "corte médio (espadas)", custo: 2}, Em: {nome: "esmagamento médio", custo: 2}, PmL: {nome: "penetração média (lanças)", custo: 2},
  PmA: {nome: "penetração média (arcos)", custo: 2}, Cp: {nome: "corte pesado", custo: 3}, Ep: {nome: "esmagamento pesado", custo: 3}, Pp: {nome: "penetração pesada", custo: 3}};
export const ARMA_INFO = {
  "Faca": {grupo: "Cl", forca: 2, maos: ["1m", "1m", "1m", "1m", "1m"]},
  "Punhal": {grupo: "Cl", forca: 3, maos: ["1m", "1m", "1m", "1m", "1m"]},
  "Cajado": {grupo: "El", forca: 4, maos: ["2m", "2m", "2m", "2m", "2m"]},
  "Porrete": {grupo: "El", forca: 5, maos: ["1m", "1m", "1m", "1m", "1m"]},
  "Machado": {grupo: "CmM", forca: 8, maos: ["1m", "1m", "1m", "1m", "1m"]},
  "Machado de guerra": {grupo: "CmM", forca: 11, maos: ["X", "2m", "2m", "2m", "1m"]},
  "Gládio": {grupo: "CmE", forca: 5, maos: ["1m", "1m", "1m", "1m", "1m"]},
  "Espada": {grupo: "CmE", forca: 8, maos: ["2m", "1m", "1m", "1m", "1m"]},
  "Clava": {grupo: "Em", forca: 8, maos: ["2m", "1m", "1m", "1m", "1m"]},
  "Maça": {grupo: "Em", forca: 9, maos: ["2m", "1m", "1m", "1m", "1m"]},
  "Martelo de guerra": {grupo: "Em", forca: 8, maos: ["1m", "1m", "1m", "1m", "1m"]},
  "Lança leve": {grupo: "PmL", forca: 7, maos: ["2m", "1m", "1m", "1m", "1m"]},
  "Lança pesada": {grupo: "PmL", forca: 10, maos: ["2m", "2m", "1m", "1m", "1m"]},
  "Arco simples": {grupo: "PmA", forca: 6, maos: ["2m", "2m", "2m", "2m", "2m"]},
  "Arco composto": {grupo: "PmA", forca: 9, maos: ["X", "X", "2m", "2m", "2m"]},
  "Espada de mão e meia (uma mão)": {grupo: "Cp", forca: 13, maos: ["X", "1m", "1m", "1m", "1m"]},
  "Espada de mão e meia (duas mãos)": {grupo: "Cp", forca: 13, maos: ["X", "2m", "2m", "2m", "2m"]},
  "Montante": {grupo: "Cp", forca: 15, maos: ["X", "X", "2m", "2m", "2m"]},
  "Maça de armas": {grupo: "Ep", forca: 13, maos: ["2m", "1m", "1m", "1m", "1m"]},
  "Mangual": {grupo: "Ep", forca: 16, maos: ["X", "X", "2m", "2m", "1m"]},
  "Lança de cavalaria": {grupo: "Pp", forca: 15, maos: ["X", "X", "1m", "1m", "1m"]}
};
// "1m" uma mao, "2m" duas maos, "X" nao pode usar; altura abaixo de 97 cm: nao pode usar nenhuma arma da tabela
export function maoDaArma(nome, alturaCm) {
  const info = ARMA_INFO[nome];
  if (!info || alturaCm === null || alturaCm === undefined) return null;
  let idx = -1;
  for (let i = 0; i < ALTURAS_ARMAS.length; i++) { if (alturaCm >= ALTURAS_ARMAS[i]) idx = i; }
  return idx < 0 ? "X" : info.maos[idx];
}


// ---------- Tabelas de criacao e de jogo (capitulos II, IV, V, XI e XIII) ----------
// Tabela II-8: altura (cm) e peso (kg) por resultado de 2d10 (2 a 20), na ordem [altura, peso]
export const ALTURA_PESO = {"Humanos": [[150, 58], [152, 60], [155, 61], [157, 63], [160, 64], [162, 66], [165, 68], [169, 70], [174, 74], [177, 77], [182, 81], [186, 85], [190, 88], [193, 92], [195, 95], [199, 97], [201, 103], [204, 106], [208, 110]], "Pequeninos": [[96, 17], [100, 19], [102, 20], [104, 21], [106, 22], [107, 23], [109, 24], [111, 25], [113, 27], [114, 30], [117, 32], [119, 34], [122, 37], [124, 39], [127, 41], [129, 43], [132, 46], [134, 48], [136, 50]], "Anões": [[120, 34], [123, 36], [125, 37], [127, 39], [130, 41], [133, 43], [135, 46], [136, 48], [138, 50], [139, 53], [140, 55], [142, 57], [143, 59], [144, 62], [146, 64], [148, 66], [150, 68], [151, 69], [154, 70]], "Elfos": [[137, 32], [141, 34], [144, 37], [148, 39], [150, 41], [152, 43], [156, 46], [158, 48], [160, 50], [163, 53], [164, 55], [165, 57], [168, 59], [170, 62], [173, 64], [177, 67], [179, 70], [183, 73], [186, 76]], "Meio-elfos": [[139, 44], [143, 49], [147, 54], [150, 58], [155, 61], [158, 63], [160, 64], [163, 67], [165, 68], [168, 69], [173, 71], [175, 74], [178, 77], [181, 80], [183, 82], [186, 85], [188, 87], [190, 88], [191, 90]]};
export function alturaPesoDe(raca, rolagem) {
  const chave = raca.indexOf("Elfos") === 0 ? "Elfos" : raca;
  const t = ALTURA_PESO[chave];
  return t ? t[Math.max(2, Math.min(20, rolagem)) - 2] : null;
}
// Tabela II-9.9: classe social por raca e resultado de 2d10 (2 a 20)
export const CLASSE_SOCIAL = {"Humanos": ["Ex-escravos", "Ex-escravos", "Ex-escravos", "Ex-servos", "Ex-servos", "Livre", "Livre", "Livre", "Livre", "Peq. comerciante", "Peq. comerciante", "Artífice", "Artífice", "Grd. comerciante", "Grd. comerciante", "Baixa nobreza", "Baixa nobreza", "Baixa nobreza", "Alta nobreza"], "Pequeninos": ["Ex-escravos", "Livre", "Livre", "Livre", "Livre", "Livre", "Livre", "Livre", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Artífice", "Artífice", "Artífice", "Grd. comerciante", "Baixa nobreza", "Baixa nobreza", "Baixa nobreza"], "Anões": ["Livre", "Livre", "Livre", "Livre", "Livre", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Artífice", "Artífice", "Artífice", "Artífice", "Grd. comerciante", "Grd. comerciante", "Baixa nobreza", "Baixa nobreza", "Baixa nobreza", "Alta nobreza"], "Elfos Florestais": ["Livre", "Livre", "Livre", "Livre", "Livre", "Livre", "Livre", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Grd. comerciante", "Grd. comerciante", "Artífice", "Baixa nobreza", "Baixa nobreza", "Baixa nobreza", "Alta nobreza"], "Elfos Dourados": ["Livre", "Livre", "Livre", "Livre", "Livre", "Livre", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Artífice", "Grd. comerciante", "Grd. comerciante", "Baixa nobreza", "Baixa nobreza", "Baixa nobreza", "Baixa nobreza", "Alta nobreza", "Alta nobreza"], "Meio-elfos": ["Ex-escravos", "Livre", "Livre", "Livre", "Livre", "Livre", "Livre", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Peq. comerciante", "Artífice", "Artífice", "Grd. comerciante", "Grd. comerciante", "Baixa nobreza", "Baixa nobreza", "Baixa nobreza", "Alta nobreza"]};
export function classeSocialDe(raca, rolagem) {
  const t = CLASSE_SOCIAL[raca];
  return t ? t[Math.max(2, Math.min(20, rolagem)) - 2] : null;
}
// Tabelas V-9.3.1 e V-9.4.1: chance de entrar em uma Ordem (Sacerdote) ou Colegio (Mago) em 1d10, por estagio
export function chanceIngresso(estagio) {
  if (estagio >= 5) return {auto: true, max: 10};
  return {auto: false, max: [0, 1, 4, 7][Math.max(1, estagio) - 1]};
}
// Tabela IV-6: multiplicador da Velocidade Base por faixa de carga (null = nao pode)
export const MOVIMENTO = [
  {faixa: "Pouco carregado", andando: 1, fundo: 3, curta: 6},
  {faixa: "Medianamente carregado", andando: 1, fundo: 2, curta: 3},
  {faixa: "Muito carregado", andando: 1 / 2, fundo: 1, curta: null},
  {faixa: "Absurdamente carregado", andando: 1 / 3, fundo: null, curta: null}
];
export const TEMPO_MOVIMENTO = {andando: "8 horas", fundo: "40 rodadas (10 minutos)", curta: "2 rodadas (30 segundos)"};
// Tabela IV-8.4: alcance (m) das armas que podem ser usadas a distancia; qualquer arma ataca ate 2 m
export const ALCANCE_ARMAS = {"Machado": 25, "Martelo de guerra": 20, "Punhal": 20, "Lança leve": 40, "Arco simples": 120, "Arco composto": 200};
// Tabela IV-12.1: combate desarmado (dano maximo 4; a Agilidade nao soma; o dano recebe o ajuste de Forca)
ARMAS["Combate desarmado"] = [0, -3, -6, 4];
export const SEM_AGILIDADE = ["Combate desarmado"];
// Tabela XIII-7: dificuldade da reacao de criaturas pelo Carisma do personagem, e coluna de cada atitude inicial
export const REACOES = {"Agressivo": -7, "Hostil": -3, "Neutro": 0, "Amistoso": 9, "Amigável": 20};
export function nivelPorCarisma(c) { return c >= 20 ? 0 : (c >= 17 ? 1 : (c >= 13 ? 2 : (c >= 9 ? 3 : (c >= 5 ? 4 : 5)))); }
// Moral (cap. XIII, item 6): dificuldade-base pela situacao e modificadores em niveis
export const SITUACOES_MORAL = [
  "Perdas leves (menos de 5% fora de combate), inimigo claramente inferior", "Perdas médias (5% a 20%)", "Perdas médias, inimigo superior",
  "Perdas pesadas (20% a 50%), inimigo igual ou superior", "Perdas pesadas, inimigo claramente superior", "Sendo esmagado (mais de 50% de perdas), sem chance de vitória"];
export const MODIFICADORES_MORAL = [["Inimigo odiado", -2], ["Defendendo o território natal ou covil", -1], ["Rendição é morte certa", -3], ["Desmotivado", 1]];
// Quedas (cap. XI, item 5): atenuacao pela cor do teste de Acrobacias (metros) e critico pela altura
export const ATENUACAO_QUEDA = {V: 2, B: 0, Y: -2, L: -4, R: -6, A: -8, C: -10};
export const CRITICO_QUEDA = [
  [0, 3, "Nenhum crítico é causado."], [4, 7, "Torção de um pé, faz mancar por 2 dias."], [8, 11, "Quebra de um braço, sorteie qual. Cura em 3 semanas."],
  [12, 15, "Quebra de uma perna, sorteie qual. Cura em 1 mês."], [16, 19, "Quebra das duas pernas, um mês de cama."],
  [20, 24, "Quebra de uma perna e um braço. Fica inconsciente por uma hora."], [25, 29, "Hemorragia interna, cura por magia ou morte em 1 dia."],
  [30, 34, "Quebra da bacia, inconsciente por 3 dias. Cura em 6 meses."], [35, 39, "Ficou paraplégico, inconsciente por 3 dias."],
  [40, 50, "Ficou tetraplégico, coma por uma semana."], [51, 9999, "Morte instantânea."]];
export function criticoDeQueda(altura) {
  for (const r of CRITICO_QUEDA) { if (altura >= r[0] && altura <= r[1]) return r[2]; }
  return CRITICO_QUEDA[0][2];
}
