import { docsHabilidades, docsArmas, docsArmaduras, docsRacas, docsProfissoes, docsEquipamentos } from "./dados.mjs";
import { EH_INICIAL, EH_ESTAGIO } from "./tabelas.mjs";
import { docsMagias } from "./magias.mjs";

export const PACKS = [
  {nome: "tagmar-habilidades", label: "Tagmar 1ª - Habilidades", docs: docsHabilidades},
  {nome: "tagmar-armas", label: "Tagmar 1ª - Armas", docs: docsArmas},
  {nome: "tagmar-armaduras", label: "Tagmar 1ª - Armaduras, escudos e elmos", docs: docsArmaduras},
  {nome: "tagmar-racas", label: "Tagmar 1ª - Raças", docs: docsRacas},
  {nome: "tagmar-equipamentos", label: "Tagmar 1ª - Equipamentos e preços", docs: docsEquipamentos},
  {nome: "tagmar-magias", label: "Tagmar 1ª - Magias", docs: docsMagias},
  {nome: "tagmar-profissoes", label: "Tagmar 1ª - Profissões", docs: function () { return docsProfissoes(EH_INICIAL, EH_ESTAGIO); }}
];

// Política conservadora: a sincronização padrão NUNCA altera documentos existentes.
// Atualizações de descrições vazias exigem opção explícita do Mestre.
// Descrições não vazias, inclusive as originalmente geradas pelo sistema,
// podem ter sido editadas e portanto nunca são substituídas automaticamente.
export async function diagnosticarCompendios() {
  const resultado = [];
  for (const p of PACKS) {
    const pack = game.packs.get("world." + p.nome);
    const esperados = p.docs();
    const nomes = pack ? new Set((await pack.getIndex()).map(e => e.name)) : new Set();
    resultado.push({colecao: p.nome, esperado: esperados.length, presente: nomes.size,
      faltantes: esperados.filter(d => !nomes.has(d.name)).map(d => d.name)});
  }
  return resultado;
}

export async function popularCompendios({atualizarDescricoesVazias = false} = {}) {
  if (!game.user?.isGM) throw new Error("Apenas o Mestre pode sincronizar os compêndios.");
  let criados = 0;
  for (const p of PACKS) {
    let pack = game.packs.get("world." + p.nome);
    if (!pack) {
      pack = await foundry.documents.collections.CompendiumCollection.createCompendium({
        name: p.nome, label: p.label, type: "Item"
      });
    }
    if (atualizarDescricoesVazias && (p.nome === "tagmar-magias" || p.nome === "tagmar-habilidades")) {
      const indice = await pack.getIndex();
      const referencia = new Map(p.docs().map(d => [d.name, d.system.descricao]));
      for (const entrada of indice) {
        if (!referencia.has(entrada.name)) continue;
        const doc = await pack.getDocument(entrada._id);
        const anterior = String(doc.system?.descricao ?? "").trim();
        if (!anterior) {
          await doc.update({"system.descricao": referencia.get(entrada.name)});
        }
      }
    }
    const existentes = new Set((await pack.getIndex()).map(e => e.name));
    const novos = p.docs().filter(d => !existentes.has(d.name));
    if (novos.length) {
      await Item.createDocuments(novos, {pack: pack.collection});
      criados += novos.length;
    }
  }
  return criados;
}
