import { CRIATURAS } from "./criaturas-dados.mjs";
function paraAtor(c, pastas) {
  const dados = {
    name: c.nome,
    type: "criatura",
    system: {
      secao: c.secao, estagio: c.estagio, defesa: c.defesa,
      ef: {value: c.energiaFisica, max: c.energiaFisica},
      eh: {value: c.energiaHeroica, max: c.energiaHeroica},
      absorcao: {total: c.energiaFisicaArmadura === null ? 0 : c.energiaFisicaArmadura - c.energiaFisica, restante: null},
      resistenciaFisica: c.resistenciaFisica, resistenciaMagia: c.resistenciaMagia, moral: c.moral,
      ataques: c.ataques.map(function (a) { return {tipo: a.tipo, ataque: a.ataque, dano: a.dano || []}; }),
      notas: c.observacoes.join(" ")
    }
  };
  if (pastas[c.secao]) dados.folder = pastas[c.secao];
  return dados;
}

// cria (se faltar) o compendio de criaturas do mundo e acrescenta so as que ainda nao existem
export async function criarCompendioCriaturas() {
  const nome = "tagmar-criaturas";
  let pack = game.packs.get("world." + nome);
  if (!pack) {
    pack = await foundry.documents.collections.CompendiumCollection.createCompendium({name: nome, label: "Tagmar 1ª - Criaturas", type: "Actor"});
  }
  const indice = await pack.getIndex();
  const existentes = new Set();
  for (const e of indice) existentes.add(e.name);
  const pastas = {};
  if (existentes.size === 0) {
    try {
      const secoes = Array.from(new Set(CRIATURAS.map(function (c) { return c.secao; })));
      for (const s of secoes) {
        const pasta = await Folder.create({name: s, type: "Actor"}, {pack: pack.collection});
        pastas[s] = pasta.id;
      }
    } catch (e) {
      console.warn(ID + " | não foi possível criar as pastas do compêndio; seguindo sem pastas", e);
    }
  }
  const novos = CRIATURAS.filter(function (c) { return !existentes.has(c.nome); }).map(function (c) { return paraAtor(c, pastas); });
  if (novos.length) await Actor.createDocuments(novos, {pack: pack.collection});
  return novos.length;
}

