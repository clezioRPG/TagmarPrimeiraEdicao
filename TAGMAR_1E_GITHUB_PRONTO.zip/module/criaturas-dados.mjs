// Dados das criaturas do Tagmar 1a edicao (1991, capitulo XIII): numeros digitalizados das tabelas do livro.
export const CRIATURAS = [
 {
  "nome": "Cão comum",
  "secao": "Animais Domésticos",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 8,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8,
     -5,
     -6,
     -7,
     -8,
     -9,
     -10
    ],
    "dano": [
     10,
     8,
     6,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Cão de raça \"Alão\"",
  "secao": "Animais Domésticos",
  "estagio": 2,
  "defesa": 2,
  "energiaFisica": 11,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 10,
  "resistenciaFisica": 2,
  "resistenciaMagia": 2,
  "moral": 4,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Pônei",
  "secao": "Animais Domésticos",
  "estagio": 2,
  "defesa": 2,
  "energiaFisica": 25,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 3,
  "resistenciaMagia": 2,
  "moral": 0,
  "ataques": [
   {
    "tipo": "Coice",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Cavalo comum",
  "secao": "Animais Domésticos",
  "estagio": 3,
  "defesa": 2,
  "energiaFisica": 40,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 4,
  "resistenciaMagia": 3,
  "moral": 0,
  "ataques": [
   {
    "tipo": "Coice",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   },
   {
    "tipo": "Mordida",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     11,
     9,
     7,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Cavalo de guerra leve",
  "secao": "Animais Domésticos",
  "estagio": 4,
  "defesa": 2,
  "energiaFisica": 45,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 20,
  "resistenciaFisica": 5,
  "resistenciaMagia": 4,
  "moral": 6,
  "ataques": [
   {
    "tipo": "Coice",
    "ataque": [
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   },
   {
    "tipo": "Mordida",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     12,
     10,
     8,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Cavalo de guerra pesado",
  "secao": "Animais Domésticos",
  "estagio": 5,
  "defesa": 2,
  "energiaFisica": 50,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 25,
  "resistenciaFisica": 6,
  "resistenciaMagia": 5,
  "moral": 8,
  "ataques": [
   {
    "tipo": "Coice",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     24,
     18,
     12,
     6
    ]
   },
   {
    "tipo": "Mordida",
    "ataque": [
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     13,
     11,
     9,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Jaguatirica ou Lince",
  "secao": "Animais Selvagens",
  "estagio": 3,
  "defesa": 8,
  "energiaFisica": 12,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 30,
  "resistenciaFisica": 4,
  "resistenciaMagia": 3,
  "moral": 3,
  "ataques": [
   {
    "tipo": "Patada",
    "ataque": [
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   },
   {
    "tipo": "Mordida",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Leopardo ou Onça pintada",
  "secao": "Animais Selvagens",
  "estagio": 5,
  "defesa": 6,
  "energiaFisica": 30,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 40,
  "resistenciaFisica": 6,
  "resistenciaMagia": 5,
  "moral": 5,
  "ataques": [
   {
    "tipo": "Patada",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     19,
     15,
     11,
     7
    ]
   },
   {
    "tipo": "Mordida",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Leão ou Tigre",
  "secao": "Animais Selvagens",
  "estagio": 7,
  "defesa": 5,
  "energiaFisica": 35,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 40,
  "resistenciaFisica": 8,
  "resistenciaMagia": 7,
  "moral": 9,
  "ataques": [
   {
    "tipo": "Patada",
    "ataque": [
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     14,
     12,
     10,
     8
    ]
   },
   {
    "tipo": "Mordida",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     29,
     23,
     17,
     11
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Lobo",
  "secao": "Animais Selvagens",
  "estagio": 3,
  "defesa": 5,
  "energiaFisica": 9,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 15,
  "resistenciaFisica": 3,
  "resistenciaMagia": 3,
  "moral": 3,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     12,
     10,
     8,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Javali",
  "secao": "Animais Selvagens",
  "estagio": 4,
  "defesa": 5,
  "energiaFisica": 35,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 10,
  "resistenciaFisica": 6,
  "resistenciaMagia": 4,
  "moral": null,
  "ataques": [
   {
    "tipo": "Presas",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     15,
     12,
     9,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Urso",
  "secao": "Animais Selvagens",
  "estagio": 9,
  "defesa": 1,
  "energiaFisica": 50,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 40,
  "resistenciaFisica": 10,
  "resistenciaMagia": 9,
  "moral": 9,
  "ataques": [
   {
    "tipo": "Patada",
    "ataque": [
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     30,
     24,
     18,
     12
    ]
   },
   {
    "tipo": "Mordida",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     22,
     18,
     14,
     10
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Gigante da colina",
  "secao": "Raças Gigantes",
  "estagio": 11,
  "defesa": 9,
  "energiaFisica": 65,
  "energiaFisicaArmadura": 71,
  "energiaHeroica": 44,
  "resistenciaFisica": 13,
  "resistenciaMagia": 11,
  "moral": 11,
  "ataques": [
   {
    "tipo": "Porrete",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     6,
     5,
     4,
     3,
     2,
     1
    ],
    "dano": [
     22,
     18,
     14,
     10
    ]
   },
   {
    "tipo": "Rochas",
    "ataque": [
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     9,
     8,
     7,
     6,
     5,
     4
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Gigante da colina líder",
  "secao": "Raças Gigantes",
  "estagio": 14,
  "defesa": 10,
  "energiaFisica": 70,
  "energiaFisicaArmadura": 76,
  "energiaHeroica": 70,
  "resistenciaFisica": 16,
  "resistenciaMagia": 14,
  "moral": 17,
  "ataques": [
   {
    "tipo": "Clava",
    "ataque": [
     16,
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     9,
     8,
     7,
     6,
     5,
     4
    ],
    "dano": [
     27,
     22,
     17,
     12
    ]
   },
   {
    "tipo": "Rochas",
    "ataque": [
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     12,
     11,
     10,
     9,
     8,
     7
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Gigante do gelo",
  "secao": "Raças Gigantes",
  "estagio": 14,
  "defesa": 9,
  "energiaFisica": 75,
  "energiaFisicaArmadura": 81,
  "energiaHeroica": 54,
  "resistenciaFisica": 17,
  "resistenciaMagia": 14,
  "moral": 14,
  "ataques": [
   {
    "tipo": "Machado",
    "ataque": [
     16,
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     10,
     9,
     8,
     7,
     6,
     5
    ],
    "dano": [
     31,
     25,
     19,
     13
    ]
   },
   {
    "tipo": "Rochas",
    "ataque": [
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     12,
     11,
     10,
     9,
     8,
     7
    ],
    "dano": [
     24,
     18,
     12,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Gigante do gelo líder",
  "secao": "Raças Gigantes",
  "estagio": 17,
  "defesa": 10,
  "energiaFisica": 85,
  "energiaFisicaArmadura": 91,
  "energiaHeroica": 85,
  "resistenciaFisica": 20,
  "resistenciaMagia": 17,
  "moral": 20,
  "ataques": [
   {
    "tipo": "Machado de guerra",
    "ataque": [
     18,
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     20,
     19,
     18,
     17,
     16,
     15,
     14,
     18,
     17,
     16,
     15,
     14,
     13
    ],
    "dano": [
     36,
     29,
     22,
     15
    ]
   },
   {
    "tipo": "Rochas",
    "ataque": [
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     10,
     18,
     17,
     16,
     15,
     14,
     13,
     12,
     15,
     14,
     13,
     12,
     11,
     10
    ],
    "dano": [
     24,
     18,
     12,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Gigante do fogo",
  "secao": "Raças Gigantes",
  "estagio": 17,
  "defesa": 10,
  "energiaFisica": 80,
  "energiaFisicaArmadura": 89,
  "energiaHeroica": 68,
  "resistenciaFisica": 21,
  "resistenciaMagia": 17,
  "moral": 17,
  "ataques": [
   {
    "tipo": "Espada",
    "ataque": [
     20,
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     14,
     13,
     12,
     11,
     10,
     9
    ],
    "dano": [
     38,
     31,
     24,
     17
    ]
   },
   {
    "tipo": "Rochas",
    "ataque": [
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     10,
     18,
     17,
     16,
     15,
     14,
     13,
     12,
     15,
     14,
     13,
     12,
     11,
     10
    ],
    "dano": [
     24,
     18,
     12,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Gigante do fogo líder",
  "secao": "Raças Gigantes",
  "estagio": 20,
  "defesa": 17,
  "energiaFisica": 95,
  "energiaFisicaArmadura": 110,
  "energiaHeroica": 100,
  "resistenciaFisica": 24,
  "resistenciaMagia": 20,
  "moral": 23,
  "ataques": [
   {
    "tipo": "Montante",
    "ataque": [
     20,
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     22,
     21,
     20,
     19,
     18,
     17,
     16,
     25,
     24,
     23,
     22,
     21,
     20
    ],
    "dano": [
     44,
     36,
     28,
     20
    ]
   },
   {
    "tipo": "Rochas",
    "ataque": [
     20,
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     21,
     20,
     19,
     18,
     17,
     16,
     15,
     18,
     17,
     16,
     15,
     14,
     13
    ],
    "dano": [
     28,
     21,
     14,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo florestal",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 11,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 5,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 1,
  "ataques": [
   {
    "tipo": "Punhal",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7,
     -4,
     -5,
     -6,
     -7,
     -8,
     -9
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo florestal soldado",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 10,
  "energiaFisica": 12,
  "energiaFisicaArmadura": 18,
  "energiaHeroica": 8,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 3,
  "ataques": [
   {
    "tipo": "Arco composto",
    "ataque": [
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   },
   {
    "tipo": "Espada",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo florestal capitão",
  "secao": "Raças Civilizadas",
  "estagio": 5,
  "defesa": 10,
  "energiaFisica": 14,
  "energiaFisicaArmadura": 21,
  "energiaHeroica": 40,
  "resistenciaFisica": 6,
  "resistenciaMagia": 5,
  "moral": 7,
  "ataques": [
   {
    "tipo": "Arco composto",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     4,
     3,
     2,
     1,
     0,
     -1
    ],
    "dano": [
     21,
     16,
     11,
     6
    ]
   },
   {
    "tipo": "Espada",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     3,
     2,
     1,
     0,
     -1,
     -2
    ],
    "dano": [
     21,
     16,
     11,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo florestal mestre de armas",
  "secao": "Raças Civilizadas",
  "estagio": 9,
  "defesa": 11,
  "energiaFisica": 13,
  "energiaFisicaArmadura": 21,
  "energiaHeroica": 75,
  "resistenciaFisica": 10,
  "resistenciaMagia": 9,
  "moral": 14,
  "ataques": [
   {
    "tipo": "Arco composto",
    "ataque": [
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     9,
     8,
     7,
     6,
     5,
     4
    ],
    "dano": [
     22,
     17,
     12,
     7
    ]
   },
   {
    "tipo": "Espada",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     8,
     7,
     6,
     5,
     4,
     3
    ],
    "dano": [
     22,
     17,
     12,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo florestal mago menor",
  "secao": "Raças Civilizadas",
  "estagio": 2,
  "defesa": 1,
  "energiaFisica": 11,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 8,
  "resistenciaFisica": 1,
  "resistenciaMagia": 4,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Punhal",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7,
     -4,
     -5,
     -6,
     -7,
     -8,
     -9
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   },
   {
    "tipo": "Cajado",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo florestal mago maior",
  "secao": "Raças Civilizadas",
  "estagio": 6,
  "defesa": 1,
  "energiaFisica": 11,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 25,
  "resistenciaFisica": 5,
  "resistenciaMagia": 9,
  "moral": 7,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   },
   {
    "tipo": "Punhal",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo florestal sacerdote",
  "secao": "Raças Civilizadas",
  "estagio": 3,
  "defesa": 9,
  "energiaFisica": 11,
  "energiaFisicaArmadura": 17,
  "energiaHeroica": 12,
  "resistenciaFisica": 3,
  "resistenciaMagia": 5,
  "moral": 3,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   },
   {
    "tipo": "Lança leve",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo florestal ladrão",
  "secao": "Raças Civilizadas",
  "estagio": 4,
  "defesa": 3,
  "energiaFisica": 11,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 20,
  "resistenciaFisica": 4,
  "resistenciaMagia": 4,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Gládio",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     1,
     0,
     -1,
     -2,
     -3,
     -4
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   },
   {
    "tipo": "Arco simples",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     3,
     2,
     1,
     0,
     -1,
     -2
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo florestal da nobreza",
  "secao": "Raças Civilizadas",
  "estagio": 7,
  "defesa": 12,
  "energiaFisica": 12,
  "energiaFisicaArmadura": 23,
  "energiaHeroica": 40,
  "resistenciaFisica": 7,
  "resistenciaMagia": 7,
  "moral": 9,
  "ataques": [
   {
    "tipo": "Espada",
    "ataque": [
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     6,
     5,
     4,
     3,
     2,
     1
    ],
    "dano": [
     21,
     16,
     11,
     6
    ]
   },
   {
    "tipo": "Arco composto",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     7,
     6,
     5,
     4,
     3,
     2
    ],
    "dano": [
     21,
     16,
     11,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo dourado",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 10,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 8,
  "resistenciaFisica": 0,
  "resistenciaMagia": 2,
  "moral": 1,
  "ataques": [
   {
    "tipo": "Punhal",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7,
     -4,
     -5,
     -6,
     -7,
     -8,
     -9
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo dourado mago menor",
  "secao": "Raças Civilizadas",
  "estagio": 3,
  "defesa": 1,
  "energiaFisica": 10,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 10,
  "resistenciaFisica": 2,
  "resistenciaMagia": 8,
  "moral": 4,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   },
   {
    "tipo": "Punhal",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7,
     -4,
     -5,
     -6,
     -7,
     -8,
     -9
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo dourado mago médio",
  "secao": "Raças Civilizadas",
  "estagio": 6,
  "defesa": 1,
  "energiaFisica": 10,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 20,
  "resistenciaFisica": 5,
  "resistenciaMagia": 9,
  "moral": 7,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   },
   {
    "tipo": "Espada",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo dourado mago maior",
  "secao": "Raças Civilizadas",
  "estagio": 10,
  "defesa": 2,
  "energiaFisica": 10,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 40,
  "resistenciaFisica": 9,
  "resistenciaMagia": 14,
  "moral": 13,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   },
   {
    "tipo": "Espada",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elfo dourado guerreiro",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 11,
  "energiaFisica": 11,
  "energiaFisicaArmadura": 20,
  "energiaHeroica": 10,
  "resistenciaFisica": 1,
  "resistenciaMagia": 2,
  "moral": 4,
  "ataques": [
   {
    "tipo": "Arco composto",
    "ataque": [
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   },
   {
    "tipo": "Espada",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Anão",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 12,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 8,
  "resistenciaFisica": 2,
  "resistenciaMagia": 1,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Gládio",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Anão guerreiro",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 9,
  "energiaFisica": 13,
  "energiaFisicaArmadura": 20,
  "energiaHeroica": 10,
  "resistenciaFisica": 2,
  "resistenciaMagia": 1,
  "moral": 4,
  "ataques": [
   {
    "tipo": "Martelo de guerra",
    "ataque": [
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     18,
     14,
     10,
     6
    ]
   },
   {
    "tipo": "Machado de guerra",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     22,
     17,
     12,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Anão capitão",
  "secao": "Raças Civilizadas",
  "estagio": 6,
  "defesa": 11,
  "energiaFisica": 14,
  "energiaFisicaArmadura": 25,
  "energiaHeroica": 50,
  "resistenciaFisica": 7,
  "resistenciaMagia": 6,
  "moral": 10,
  "ataques": [
   {
    "tipo": "Machado de guerra",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     8,
     7,
     6,
     5,
     4,
     3
    ],
    "dano": [
     23,
     18,
     13,
     8
    ]
   },
   {
    "tipo": "Martelo de guerra",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     6,
     5,
     4,
     3,
     2,
     1
    ],
    "dano": [
     19,
     15,
     11,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Anão mestre de armas",
  "secao": "Raças Civilizadas",
  "estagio": 10,
  "defesa": 11,
  "energiaFisica": 15,
  "energiaFisicaArmadura": 26,
  "energiaHeroica": 85,
  "resistenciaFisica": 12,
  "resistenciaMagia": 10,
  "moral": 14,
  "ataques": [
   {
    "tipo": "Gládio",
    "ataque": [
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     7,
     6,
     5,
     4,
     3,
     2
    ],
    "dano": [
     19,
     15,
     11,
     7
    ]
   },
   {
    "tipo": "Mangual",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     15,
     14,
     13,
     12,
     11,
     10
    ],
    "dano": [
     27,
     21,
     15,
     9
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Anão da nobreza",
  "secao": "Raças Civilizadas",
  "estagio": 7,
  "defesa": 11,
  "energiaFisica": 13,
  "energiaFisicaArmadura": 27,
  "energiaHeroica": 50,
  "resistenciaFisica": 7,
  "resistenciaMagia": 7,
  "moral": 12,
  "ataques": [
   {
    "tipo": "Machado",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     3,
     2,
     1,
     0,
     -1,
     -2
    ],
    "dano": [
     18,
     14,
     10,
     6
    ]
   },
   {
    "tipo": "Gládio",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     3,
     2,
     1,
     0,
     -1,
     -2
    ],
    "dano": [
     18,
     14,
     10,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Anão sacerdote menor",
  "secao": "Raças Civilizadas",
  "estagio": 2,
  "defesa": 9,
  "energiaFisica": 12,
  "energiaFisicaArmadura": 21,
  "energiaHeroica": 12,
  "resistenciaFisica": 2,
  "resistenciaMagia": 3,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   },
   {
    "tipo": "Martelo de guerra",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     1,
     0,
     -1,
     -2,
     -3,
     -4
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Anão sacerdote maior",
  "secao": "Raças Civilizadas",
  "estagio": 6,
  "defesa": 10,
  "energiaFisica": 12,
  "energiaFisicaArmadura": 22,
  "energiaHeroica": 35,
  "resistenciaFisica": 6,
  "resistenciaMagia": 9,
  "moral": 7,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     13,
     10,
     7,
     4
    ]
   },
   {
    "tipo": "Martelo de guerra",
    "ataque": [
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     17,
     13,
     9,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Pequenino",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 2,
  "energiaFisica": 7,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 0,
  "ataques": [
   {
    "tipo": "Punhal",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Pequenino guerreiro",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 3,
  "energiaFisica": 9,
  "energiaFisicaArmadura": 12,
  "energiaHeroica": 0,
  "resistenciaFisica": 2,
  "resistenciaMagia": 1,
  "moral": 1,
  "ataques": [
   {
    "tipo": "Arco simples",
    "ataque": [
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   },
   {
    "tipo": "Lança leve",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Pequenino capitão",
  "secao": "Raças Civilizadas",
  "estagio": 4,
  "defesa": 12,
  "energiaFisica": 9,
  "energiaFisicaArmadura": 18,
  "energiaHeroica": 20,
  "resistenciaFisica": 7,
  "resistenciaMagia": 4,
  "moral": 5,
  "ataques": [
   {
    "tipo": "Arco simples",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     4,
     3,
     2,
     1,
     0,
     -1
    ],
    "dano": [
     17,
     13,
     9,
     5
    ]
   },
   {
    "tipo": "Gládio",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     17,
     13,
     9,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Pequenino ladrão menor",
  "secao": "Raças Civilizadas",
  "estagio": 2,
  "defesa": 3,
  "energiaFisica": 7,
  "energiaFisicaArmadura": 10,
  "energiaHeroica": 12,
  "resistenciaFisica": 2,
  "resistenciaMagia": 2,
  "moral": 1,
  "ataques": [
   {
    "tipo": "Arco simples",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     1,
     0,
     -1,
     -2,
     -3,
     -4
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   },
   {
    "tipo": "Punhal",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Pequenino ladrão maior",
  "secao": "Raças Civilizadas",
  "estagio": 8,
  "defesa": 11,
  "energiaFisica": 7,
  "energiaFisicaArmadura": 13,
  "energiaHeroica": 40,
  "resistenciaFisica": 8,
  "resistenciaMagia": 7,
  "moral": 7,
  "ataques": [
   {
    "tipo": "Arco simples",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     7,
     6,
     5,
     4,
     3,
     2
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   },
   {
    "tipo": "Gládio",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     3,
     2,
     1,
     0,
     -1,
     -2
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Pequenino sacerdote",
  "secao": "Raças Civilizadas",
  "estagio": 2,
  "defesa": 3,
  "energiaFisica": 7,
  "energiaFisicaArmadura": 10,
  "energiaHeroica": 10,
  "resistenciaFisica": 2,
  "resistenciaMagia": 3,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   },
   {
    "tipo": "Maça",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     1,
     0,
     -1,
     -2,
     -3,
     -4
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Mercador",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 13,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 1,
  "ataques": [
   {
    "tipo": "Gládio",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Ladrão barato",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 2,
  "energiaFisica": 13,
  "energiaFisicaArmadura": 16,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": -1,
  "ataques": [
   {
    "tipo": "Punhal",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7,
     -4,
     -5,
     -6,
     -7,
     -8,
     -9
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Mercenário",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 10,
  "energiaFisica": 14,
  "energiaFisicaArmadura": 21,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Machado",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     17,
     13,
     9,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Tenente",
  "secao": "Raças Civilizadas",
  "estagio": 3,
  "defesa": 10,
  "energiaFisica": 14,
  "energiaFisicaArmadura": 25,
  "energiaHeroica": 20,
  "resistenciaFisica": 4,
  "resistenciaMagia": 3,
  "moral": 4,
  "ataques": [
   {
    "tipo": "Espada",
    "ataque": [
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     21,
     16,
     11,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Capitão",
  "secao": "Raças Civilizadas",
  "estagio": 5,
  "defesa": 10,
  "energiaFisica": 14,
  "energiaFisicaArmadura": 26,
  "energiaHeroica": 35,
  "resistenciaFisica": 7,
  "resistenciaMagia": 5,
  "moral": 7,
  "ataques": [
   {
    "tipo": "Espada",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     21,
     16,
     11,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Cidadão comum",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 13,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 0,
  "ataques": [
   {
    "tipo": "Porrete",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -4,
     -5,
     -6,
     -7,
     -8,
     -9
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Sábio",
  "secao": "Raças Civilizadas",
  "estagio": 4,
  "defesa": 1,
  "energiaFisica": 12,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 15,
  "resistenciaFisica": 4,
  "resistenciaMagia": 4,
  "moral": 7,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Bárbaros",
  "secao": "Raças Civilizadas",
  "estagio": 2,
  "defesa": 9,
  "energiaFisica": 14,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 8,
  "resistenciaFisica": 3,
  "resistenciaMagia": 2,
  "moral": 6,
  "ataques": [
   {
    "tipo": "Machado",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     17,
     13,
     9,
     5
    ]
   },
   {
    "tipo": "Lança leve",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     17,
     13,
     9,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Criança",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 6,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": -1,
  "ataques": [],
  "observacoes": [
   "Não ataca (sem tabela de ataque)."
  ]
 },
 {
  "nome": "Dona de casa",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 13,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": -1,
  "ataques": [
   {
    "tipo": "Faca",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8,
     -5,
     -6,
     -7,
     -8,
     -9,
     -10
    ],
    "dano": [
     8,
     6,
     4,
     2
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Sacerdote",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 2,
  "energiaFisica": 13,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 2,
  "moral": 4,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Peregrino",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 13,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -3,
     -4,
     -5,
     -6,
     -7,
     -8
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Nobre",
  "secao": "Raças Civilizadas",
  "estagio": 6,
  "defesa": 12,
  "energiaFisica": 14,
  "energiaFisicaArmadura": 30,
  "energiaHeroica": 20,
  "resistenciaFisica": 6,
  "resistenciaMagia": 6,
  "moral": 8,
  "ataques": [
   {
    "tipo": "Espada",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     4,
     3,
     2,
     1,
     0,
     -1
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Mendigo",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 12,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 0,
  "ataques": [
   {
    "tipo": "Porrete",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -4,
     -5,
     -6,
     -7,
     -8,
     -9
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Marinheiro",
  "secao": "Raças Civilizadas",
  "estagio": 1,
  "defesa": 2,
  "energiaFisica": 13,
  "energiaFisicaArmadura": 16,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 3,
  "ataques": [
   {
    "tipo": "Punhal",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7,
     -4,
     -5,
     -6,
     -7,
     -8,
     -9
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Orco comum",
  "secao": "Raças Selvagens",
  "estagio": 1,
  "defesa": 2,
  "energiaFisica": 14,
  "energiaFisicaArmadura": 17,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 1,
  "ataques": [
   {
    "tipo": "Lança leve",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Orco capitão",
  "secao": "Raças Selvagens",
  "estagio": 5,
  "defesa": 9,
  "energiaFisica": 16,
  "energiaFisicaArmadura": 22,
  "energiaHeroica": 25,
  "resistenciaFisica": 6,
  "resistenciaMagia": 5,
  "moral": 6,
  "ataques": [
   {
    "tipo": "Espada",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     21,
     16,
     11,
     6
    ]
   },
   {
    "tipo": "Machado",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     1,
     0,
     -1,
     -2,
     -3,
     -4
    ],
    "dano": [
     17,
     13,
     9,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Orco comandante",
  "secao": "Raças Selvagens",
  "estagio": 7,
  "defesa": 11,
  "energiaFisica": 16,
  "energiaFisicaArmadura": 25,
  "energiaHeroica": 35,
  "resistenciaFisica": 8,
  "resistenciaMagia": 7,
  "moral": 9,
  "ataques": [
   {
    "tipo": "Montante",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     12,
     11,
     10,
     9,
     8,
     7
    ],
    "dano": [
     26,
     20,
     14,
     8
    ]
   },
   {
    "tipo": "Punhal",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     14,
     11,
     8,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Orco mestre de armas",
  "secao": "Raças Selvagens",
  "estagio": 10,
  "defesa": 18,
  "energiaFisica": 18,
  "energiaFisicaArmadura": 30,
  "energiaHeroica": 50,
  "resistenciaFisica": 12,
  "resistenciaMagia": 10,
  "moral": 13,
  "ataques": [
   {
    "tipo": "Espada",
    "ataque": [
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     8,
     7,
     6,
     5,
     4,
     3
    ],
    "dano": [
     23,
     18,
     13,
     8
    ]
   },
   {
    "tipo": "Mangual",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     15,
     14,
     13,
     12,
     11,
     10
    ],
    "dano": [
     27,
     21,
     15,
     9
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Orco rei",
  "secao": "Raças Selvagens",
  "estagio": 11,
  "defesa": 18,
  "energiaFisica": 18,
  "energiaFisicaArmadura": 33,
  "energiaHeroica": 60,
  "resistenciaFisica": 13,
  "resistenciaMagia": 1,
  "moral": 15,
  "ataques": [
   {
    "tipo": "Montante",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     18,
     17,
     16,
     15,
     14,
     13
    ],
    "dano": [
     27,
     21,
     15,
     9
    ]
   },
   {
    "tipo": "Lança pesada",
    "ataque": [
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     10,
     9,
     8,
     7,
     6,
     5
    ],
    "dano": [
     23,
     18,
     13,
     8
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Orco ladrão",
  "secao": "Raças Selvagens",
  "estagio": 3,
  "defesa": 3,
  "energiaFisica": 12,
  "energiaFisicaArmadura": 15,
  "energiaHeroica": 9,
  "resistenciaFisica": 3,
  "resistenciaMagia": 3,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Gládio",
    "ataque": [
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Orco sacerdote",
  "secao": "Raças Selvagens",
  "estagio": 1,
  "defesa": 9,
  "energiaFisica": 13,
  "energiaFisicaArmadura": 19,
  "energiaHeroica": 4,
  "resistenciaFisica": 1,
  "resistenciaMagia": 2,
  "moral": 1,
  "ataques": [
   {
    "tipo": "Lança pesada",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Orco sumo sacerdote",
  "secao": "Raças Selvagens",
  "estagio": 6,
  "defesa": 9,
  "energiaFisica": 13,
  "energiaFisicaArmadura": 22,
  "energiaHeroica": 24,
  "resistenciaFisica": 6,
  "resistenciaMagia": 8,
  "moral": 7,
  "ataques": [
   {
    "tipo": "Cajado",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     13,
     10,
     7,
     4
    ]
   },
   {
    "tipo": "Lança pesada",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     3,
     2,
     1,
     0,
     -1,
     -2
    ],
    "dano": [
     21,
     16,
     11,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Orco fêmea",
  "secao": "Raças Selvagens",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 11,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 0,
  "ataques": [
   {
    "tipo": "Punhal",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7,
     -4,
     -5,
     -6,
     -7,
     -8,
     -9
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Orco filhote",
  "secao": "Raças Selvagens",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 6,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": -1,
  "ataques": [],
  "observacoes": [
   "Não ataca (sem tabela de ataque)."
  ]
 },
 {
  "nome": "Orco campeão",
  "secao": "Raças Selvagens",
  "estagio": 10,
  "defesa": 19,
  "energiaFisica": 18,
  "energiaFisicaArmadura": 30,
  "energiaHeroica": 50,
  "resistenciaFisica": 13,
  "resistenciaMagia": 10,
  "moral": 13,
  "ataques": [
   {
    "tipo": "Mangual",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     15,
     14,
     13,
     12,
     11,
     10
    ],
    "dano": [
     27,
     21,
     15,
     9
    ]
   },
   {
    "tipo": "Machado",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     7,
     6,
     5,
     4,
     3,
     2
    ],
    "dano": [
     19,
     15,
     11,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Ogro",
  "secao": "Raças Selvagens",
  "estagio": 5,
  "defesa": 9,
  "energiaFisica": 25,
  "energiaFisicaArmadura": 31,
  "energiaHeroica": 20,
  "resistenciaFisica": 5,
  "resistenciaMagia": 5,
  "moral": 7,
  "ataques": [
   {
    "tipo": "Clava",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     20,
     16,
     12,
     8
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Ogro líder",
  "secao": "Raças Selvagens",
  "estagio": 8,
  "defesa": 10,
  "energiaFisica": 28,
  "energiaFisicaArmadura": 34,
  "energiaHeroica": 32,
  "resistenciaFisica": 9,
  "resistenciaMagia": 8,
  "moral": 15,
  "ataques": [
   {
    "tipo": "Machado de guerra",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     9,
     8,
     7,
     6,
     5,
     4
    ],
    "dano": [
     25,
     20,
     15,
     10
    ]
   },
   {
    "tipo": "Lança pesada",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     25,
     20,
     15,
     10
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Ogro fêmea",
  "secao": "Raças Selvagens",
  "estagio": 3,
  "defesa": 1,
  "energiaFisica": 22,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 3,
  "resistenciaMagia": 3,
  "moral": 3,
  "ataques": [
   {
    "tipo": "Porrete",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     16,
     13,
     10,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Ogro filhote",
  "secao": "Raças Selvagens",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 14,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 1,
  "moral": 1,
  "ataques": [],
  "observacoes": [
   "Não ataca (sem tabela de ataque)."
  ]
 },
 {
  "nome": "Trol",
  "secao": "Raças Selvagens",
  "estagio": 9,
  "defesa": 9,
  "energiaFisica": 35,
  "energiaFisicaArmadura": 38,
  "energiaHeroica": 36,
  "resistenciaFisica": 10,
  "resistenciaMagia": 8,
  "moral": 10,
  "ataques": [
   {
    "tipo": "Porrete",
    "ataque": [
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     4,
     3,
     2,
     1,
     0,
     -1
    ],
    "dano": [
     21,
     17,
     13,
     9
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Trol líder",
  "secao": "Raças Selvagens",
  "estagio": 11,
  "defesa": 9,
  "energiaFisica": 40,
  "energiaFisicaArmadura": 46,
  "energiaHeroica": 55,
  "resistenciaFisica": 12,
  "resistenciaMagia": 10,
  "moral": 13,
  "ataques": [
   {
    "tipo": "Clava",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     6,
     5,
     4,
     3,
     2,
     1
    ],
    "dano": [
     26,
     21,
     16,
     11
    ]
   },
   {
    "tipo": "Machado de guerra",
    "ataque": [
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     12,
     11,
     10,
     9,
     8,
     7
    ],
    "dano": [
     30,
     24,
     18,
     12
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Trol fêmea",
  "secao": "Raças Selvagens",
  "estagio": 5,
  "defesa": 1,
  "energiaFisica": 35,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 5,
  "resistenciaMagia": 5,
  "moral": 5,
  "ataques": [
   {
    "tipo": "Porrete",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     20,
     16,
     12,
     8
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Trol filhote",
  "secao": "Raças Selvagens",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 20,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 1,
  "resistenciaMagia": 0,
  "moral": 1,
  "ataques": [],
  "observacoes": [
   "Não ataca (sem tabela de ataque)."
  ]
 },
 {
  "nome": "Aranha gigante",
  "secao": "Criaturas Místicas",
  "estagio": 4,
  "defesa": 3,
  "energiaFisica": 16,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 12,
  "resistenciaFisica": 4,
  "resistenciaMagia": 4,
  "moral": 3,
  "ataques": [
   {
    "tipo": "Picada",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     24,
     19,
     14,
     9
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Unicórnio",
  "secao": "Criaturas Místicas",
  "estagio": 9,
  "defesa": 6,
  "energiaFisica": 50,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 50,
  "resistenciaFisica": 11,
  "resistenciaMagia": 13,
  "moral": 18,
  "ataques": [
   {
    "tipo": "Cascos",
    "ataque": [
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     7,
     6,
     5,
     4,
     3,
     2
    ],
    "dano": [
     24,
     18,
     12,
     6
    ]
   },
   {
    "tipo": "Chifre",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     7,
     6,
     5,
     4,
     3,
     2
    ],
    "dano": [
     24,
     19,
     14,
     9
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Grifo",
  "secao": "Criaturas Místicas",
  "estagio": 7,
  "defesa": 3,
  "energiaFisica": 50,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 40,
  "resistenciaFisica": 8,
  "resistenciaMagia": 7,
  "moral": 11,
  "ataques": [
   {
    "tipo": "Garra",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     27,
     21,
     15,
     9
    ]
   },
   {
    "tipo": "Mordida",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     24,
     19,
     14,
     9
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Gárgula",
  "secao": "Criaturas Místicas",
  "estagio": 5,
  "defesa": 16,
  "energiaFisica": 50,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 14,
  "resistenciaMagia": 15,
  "moral": 8,
  "ataques": [
   {
    "tipo": "Garras",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     0,
     -1,
     -2,
     -3,
     -4,
     -5
    ],
    "dano": [
     20,
     17,
     14,
     11
    ]
   },
   {
    "tipo": "Cauda",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     3,
     2,
     1,
     0,
     -1,
     -2
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Sátiro",
  "secao": "Criaturas Místicas",
  "estagio": 8,
  "defesa": 4,
  "energiaFisica": 13,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 50,
  "resistenciaFisica": 10,
  "resistenciaMagia": 11,
  "moral": 8,
  "ataques": [
   {
    "tipo": "Punhal",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     4,
     3,
     2,
     1,
     0,
     -1
    ],
    "dano": [
     13,
     10,
     7,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Pégaso",
  "secao": "Criaturas Místicas",
  "estagio": 8,
  "defesa": 6,
  "energiaFisica": 50,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 50,
  "resistenciaFisica": 9,
  "resistenciaMagia": 9,
  "moral": 18,
  "ataques": [
   {
    "tipo": "Casco",
    "ataque": [
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     22,
     17,
     12,
     7
    ]
   },
   {
    "tipo": "Mordida",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     18,
     14,
     10,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Centauro",
  "secao": "Criaturas Místicas",
  "estagio": 7,
  "defesa": 2,
  "energiaFisica": 50,
  "energiaFisicaArmadura": 54,
  "energiaHeroica": 35,
  "resistenciaFisica": 9,
  "resistenciaMagia": 7,
  "moral": 10,
  "ataques": [
   {
    "tipo": "Arco composto",
    "ataque": [
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     22,
     17,
     12,
     7
    ]
   },
   {
    "tipo": "Clava",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     18,
     14,
     10,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Minotauro",
  "secao": "Criaturas Místicas",
  "estagio": 10,
  "defesa": 10,
  "energiaFisica": 20,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 120,
  "resistenciaFisica": 13,
  "resistenciaMagia": 11,
  "moral": 15,
  "ataques": [
   {
    "tipo": "Chifres",
    "ataque": [
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     15,
     12,
     9,
     6
    ]
   },
   {
    "tipo": "Machado de guerra",
    "ataque": [
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     11,
     10,
     9,
     8,
     7,
     6
    ],
    "dano": [
     28,
     22,
     16,
     10
    ]
   },
   {
    "tipo": "Mordida",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     16,
     13,
     10,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Dragonete",
  "secao": "Dragões",
  "estagio": 10,
  "defesa": 11,
  "energiaFisica": 105,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 50,
  "resistenciaFisica": 12,
  "resistenciaMagia": 11,
  "moral": 15,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     9,
     8,
     7,
     6,
     5,
     4
    ],
    "dano": [
     31,
     24,
     17,
     10
    ]
   },
   {
    "tipo": "Garras",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     6,
     5,
     4,
     3,
     2,
     1
    ],
    "dano": [
     27,
     21,
     15,
     9
    ]
   },
   {
    "tipo": "Cauda",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     8,
     7,
     6,
     5,
     4,
     3
    ],
    "dano": [
     19,
     15,
     11,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Salamandra",
  "secao": "Dragões",
  "estagio": 9,
  "defesa": 11,
  "energiaFisica": 100,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 50,
  "resistenciaFisica": 10,
  "resistenciaMagia": 9,
  "moral": 13,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     8,
     7,
     6,
     5,
     4,
     3
    ],
    "dano": [
     32,
     24,
     16,
     8
    ]
   },
   {
    "tipo": "Cauda",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     7,
     6,
     5,
     4,
     3,
     2
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   },
   {
    "tipo": "Hálito flamejante",
    "ataque": [
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     11,
     10,
     9,
     8,
     7,
     6
    ],
    "dano": [
     26,
     20,
     12,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Dragão do Gelo Jovem",
  "secao": "Dragões",
  "estagio": 13,
  "defesa": 18,
  "energiaFisica": 140,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 75,
  "resistenciaFisica": 16,
  "resistenciaMagia": 16,
  "moral": 18,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     12,
     11,
     10,
     9,
     8,
     7
    ],
    "dano": [
     36,
     28,
     20,
     12
    ]
   },
   {
    "tipo": "Garras",
    "ataque": [
     16,
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     9,
     8,
     7,
     6,
     5,
     4
    ],
    "dano": [
     28,
     22,
     16,
     10
    ]
   },
   {
    "tipo": "Cauda",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     11,
     10,
     9,
     8,
     7,
     6
    ],
    "dano": [
     24,
     19,
     14,
     9
    ]
   },
   {
    "tipo": "Hálito congelante",
    "ataque": [
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     15,
     14,
     13,
     12,
     11,
     10
    ],
    "dano": [
     28,
     22,
     16,
     10
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Dragão do Gelo Adulto",
  "secao": "Dragões",
  "estagio": 19,
  "defesa": 20,
  "energiaFisica": 170,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 95,
  "resistenciaFisica": 23,
  "resistenciaMagia": 23,
  "moral": 28,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     20,
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     18,
     17,
     16,
     15,
     14,
     13
    ],
    "dano": [
     42,
     34,
     26,
     18
    ]
   },
   {
    "tipo": "Garras",
    "ataque": [
     22,
     21,
     20,
     19,
     18,
     17,
     16,
     15,
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     15,
     14,
     13,
     12,
     11,
     10
    ],
    "dano": [
     34,
     27,
     20,
     13
    ]
   },
   {
    "tipo": "Cauda",
    "ataque": [
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     12,
     20,
     19,
     18,
     17,
     16,
     15,
     14,
     17,
     16,
     15,
     14,
     13,
     12
    ],
    "dano": [
     30,
     24,
     18,
     12
    ]
   },
   {
    "tipo": "Hálito congelante",
    "ataque": [
     21,
     20,
     19,
     18,
     17,
     16,
     15,
     14,
     21,
     20,
     19,
     18,
     17,
     16,
     15,
     21,
     20,
     19,
     18,
     17,
     16
    ],
    "dano": [
     32,
     25,
     18,
     11
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Dragão do Fogo Jovem",
  "secao": "Dragões",
  "estagio": 16,
  "defesa": 18,
  "energiaFisica": 180,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 85,
  "resistenciaFisica": 19,
  "resistenciaMagia": 19,
  "moral": 24,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     18,
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     16,
     15,
     14,
     13,
     12,
     11
    ],
    "dano": [
     40,
     32,
     24,
     16
    ]
   },
   {
    "tipo": "Garras",
    "ataque": [
     20,
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     13,
     12,
     11,
     10,
     9,
     8
    ],
    "dano": [
     32,
     26,
     20,
     14
    ]
   },
   {
    "tipo": "Cauda",
    "ataque": [
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     10,
     18,
     17,
     16,
     15,
     14,
     13,
     12,
     15,
     14,
     13,
     12,
     11,
     10
    ],
    "dano": [
     28,
     23,
     18,
     13
    ]
   },
   {
    "tipo": "Hálito flamejante",
    "ataque": [
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     12,
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     19,
     18,
     17,
     16,
     15,
     14
    ],
    "dano": [
     32,
     26,
     20,
     14
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Dragão do Fogo Adulto",
  "secao": "Dragões",
  "estagio": 25,
  "defesa": 21,
  "energiaFisica": 200,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 110,
  "resistenciaFisica": 30,
  "resistenciaMagia": 30,
  "moral": 38,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     27,
     26,
     25,
     24,
     23,
     22,
     21,
     20,
     26,
     25,
     24,
     23,
     22,
     21,
     20,
     25,
     24,
     23,
     22,
     21,
     20
    ],
    "dano": [
     50,
     40,
     30,
     20
    ]
   },
   {
    "tipo": "Garras",
    "ataque": [
     29,
     28,
     27,
     26,
     25,
     24,
     23,
     22,
     26,
     25,
     24,
     23,
     22,
     21,
     20,
     22,
     21,
     20,
     19,
     18,
     17
    ],
    "dano": [
     42,
     34,
     26,
     18
    ]
   },
   {
    "tipo": "Cauda",
    "ataque": [
     26,
     25,
     24,
     23,
     22,
     21,
     20,
     19,
     27,
     26,
     25,
     24,
     23,
     22,
     21,
     24,
     23,
     22,
     21,
     20,
     19
    ],
    "dano": [
     38,
     31,
     24,
     17
    ]
   },
   {
    "tipo": "Hálito flamejante",
    "ataque": [
     28,
     27,
     26,
     25,
     24,
     23,
     22,
     21,
     28,
     27,
     26,
     25,
     24,
     23,
     22,
     28,
     27,
     26,
     25,
     24,
     23
    ],
    "dano": [
     38,
     30,
     22,
     14
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental do fogo menor",
  "secao": "Elementais",
  "estagio": 2,
  "defesa": 3,
  "energiaFisica": 4,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 20,
  "resistenciaFisica": 2,
  "resistenciaMagia": 2,
  "moral": 8,
  "ataques": [
   {
    "tipo": "Toque",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     4,
     3,
     2,
     1,
     0,
     -1
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental do fogo fraco",
  "secao": "Elementais",
  "estagio": 6,
  "defesa": 4,
  "energiaFisica": 8,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 60,
  "resistenciaFisica": 6,
  "resistenciaMagia": 6,
  "moral": 12,
  "ataques": [
   {
    "tipo": "Toque",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     8,
     7,
     6,
     5,
     4,
     3
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental do fogo médio",
  "secao": "Elementais",
  "estagio": 10,
  "defesa": 5,
  "energiaFisica": 12,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 100,
  "resistenciaFisica": 10,
  "resistenciaMagia": 10,
  "moral": 16,
  "ataques": [
   {
    "tipo": "Toque",
    "ataque": [
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     12,
     11,
     10,
     9,
     8,
     7
    ],
    "dano": [
     24,
     18,
     12,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental do fogo forte",
  "secao": "Elementais",
  "estagio": 16,
  "defesa": 6,
  "energiaFisica": 16,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 160,
  "resistenciaFisica": 16,
  "resistenciaMagia": 16,
  "moral": 22,
  "ataques": [
   {
    "tipo": "Toque",
    "ataque": [
     18,
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     18,
     17,
     16,
     15,
     14,
     13,
     12,
     18,
     17,
     16,
     15,
     14,
     13
    ],
    "dano": [
     28,
     21,
     14,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental da água menor",
  "secao": "Elementais",
  "estagio": 2,
  "defesa": 4,
  "energiaFisica": 20,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 6,
  "resistenciaFisica": 4,
  "resistenciaMagia": 2,
  "moral": 8,
  "ataques": [
   {
    "tipo": "Punhos",
    "ataque": [
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     4,
     3,
     2,
     1,
     0,
     -1
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   },
   {
    "tipo": "Jato",
    "ataque": [
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     10,
     9,
     8,
     7,
     6,
     5
    ],
    "dano": null
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental da água fraco",
  "secao": "Elementais",
  "estagio": 6,
  "defesa": 5,
  "energiaFisica": 30,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 18,
  "resistenciaFisica": 8,
  "resistenciaMagia": 6,
  "moral": 12,
  "ataques": [
   {
    "tipo": "Punhos",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     8,
     7,
     6,
     5,
     4,
     3
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   },
   {
    "tipo": "Jato",
    "ataque": [
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     14,
     13,
     12,
     11,
     10,
     9
    ],
    "dano": null
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental da água médio",
  "secao": "Elementais",
  "estagio": 10,
  "defesa": 6,
  "energiaFisica": 40,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 30,
  "resistenciaFisica": 12,
  "resistenciaMagia": 10,
  "moral": 16,
  "ataques": [
   {
    "tipo": "Punhos",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     12,
     11,
     10,
     9,
     8,
     7
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   },
   {
    "tipo": "Jato",
    "ataque": [
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     16,
     15,
     14,
     13,
     12,
     11,
     10,
     18,
     17,
     16,
     15,
     14,
     13
    ],
    "dano": null
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental da água forte",
  "secao": "Elementais",
  "estagio": 16,
  "defesa": 7,
  "energiaFisica": 60,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 42,
  "resistenciaFisica": 18,
  "resistenciaMagia": 16,
  "moral": 22,
  "ataques": [
   {
    "tipo": "Punhos",
    "ataque": [
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     18,
     17,
     16,
     15,
     14,
     13
    ],
    "dano": [
     24,
     18,
     12,
     6
    ]
   },
   {
    "tipo": "Jato",
    "ataque": [
     20,
     19,
     18,
     17,
     16,
     15,
     14,
     13,
     22,
     21,
     20,
     19,
     18,
     17,
     16,
     24,
     23,
     22,
     21,
     20,
     19
    ],
    "dano": null
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental da terra menor",
  "secao": "Elementais",
  "estagio": 2,
  "defesa": 17,
  "energiaFisica": 30,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 4,
  "resistenciaFisica": 6,
  "resistenciaMagia": 1,
  "moral": 20,
  "ataques": [
   {
    "tipo": "Punhos",
    "ataque": [
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     4,
     3,
     2,
     1,
     0,
     -1
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental da terra fraco",
  "secao": "Elementais",
  "estagio": 6,
  "defesa": 17,
  "energiaFisica": 50,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 8,
  "resistenciaFisica": 10,
  "resistenciaMagia": 5,
  "moral": 20,
  "ataques": [
   {
    "tipo": "Punhos",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     8,
     7,
     6,
     5,
     4,
     3
    ],
    "dano": [
     24,
     18,
     12,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental da terra médio",
  "secao": "Elementais",
  "estagio": 10,
  "defesa": 18,
  "energiaFisica": 70,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 12,
  "resistenciaFisica": 14,
  "resistenciaMagia": 9,
  "moral": 20,
  "ataques": [
   {
    "tipo": "Punhos",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     12,
     11,
     10,
     9,
     8,
     7
    ],
    "dano": [
     32,
     24,
     16,
     8
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental da terra forte",
  "secao": "Elementais",
  "estagio": 16,
  "defesa": 18,
  "energiaFisica": 100,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 10,
  "resistenciaFisica": 20,
  "resistenciaMagia": 15,
  "moral": 20,
  "ataques": [
   {
    "tipo": "Punhos",
    "ataque": [
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     18,
     17,
     16,
     15,
     14,
     13
    ],
    "dano": [
     40,
     30,
     20,
     10
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Elemental do ar menor",
  "secao": "Elementais",
  "estagio": 2,
  "defesa": 6,
  "energiaFisica": 1,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 20,
  "resistenciaFisica": 0,
  "resistenciaMagia": 6,
  "moral": 3,
  "ataques": [],
  "observacoes": [
   "Ver descrição no livro (sem tabela de ataque)."
  ]
 },
 {
  "nome": "Elemental do ar fraco",
  "secao": "Elementais",
  "estagio": 6,
  "defesa": 7,
  "energiaFisica": 2,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 60,
  "resistenciaFisica": 4,
  "resistenciaMagia": 10,
  "moral": 7,
  "ataques": [],
  "observacoes": [
   "Ver descrição no livro (sem tabela de ataque)."
  ]
 },
 {
  "nome": "Elemental do ar médio",
  "secao": "Elementais",
  "estagio": 10,
  "defesa": 8,
  "energiaFisica": 4,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 100,
  "resistenciaFisica": 8,
  "resistenciaMagia": 14,
  "moral": 11,
  "ataques": [],
  "observacoes": [
   "Ver descrição no livro (sem tabela de ataque)."
  ]
 },
 {
  "nome": "Elemental do ar forte",
  "secao": "Elementais",
  "estagio": 16,
  "defesa": 6,
  "energiaFisica": 8,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 160,
  "resistenciaFisica": 14,
  "resistenciaMagia": 20,
  "moral": 17,
  "ataques": [],
  "observacoes": [
   "Ver descrição no livro (sem tabela de ataque)."
  ]
 },
 {
  "nome": "Enviado menor",
  "secao": "Criaturas Divinas",
  "estagio": 1,
  "defesa": 3,
  "energiaFisica": 8,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 15,
  "resistenciaFisica": 2,
  "resistenciaMagia": 2,
  "moral": 5,
  "ataques": [
   {
    "tipo": "Garras",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     13,
     10,
     7,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Enviado tipo I",
  "secao": "Criaturas Divinas",
  "estagio": 3,
  "defesa": 11,
  "energiaFisica": 20,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 20,
  "resistenciaFisica": 6,
  "resistenciaMagia": 8,
  "moral": 10,
  "ataques": [
   {
    "tipo": "Bastão de luz",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     20,
     16,
     12,
     8
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Enviado tipo II",
  "secao": "Criaturas Divinas",
  "estagio": 7,
  "defesa": 18,
  "energiaFisica": 20,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 40,
  "resistenciaFisica": 12,
  "resistenciaMagia": 12,
  "moral": 15,
  "ataques": [
   {
    "tipo": "Bastão de luz",
    "ataque": [
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     7,
     6,
     5,
     4,
     3,
     2
    ],
    "dano": [
     22,
     17,
     12,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Enviado tipo III",
  "secao": "Criaturas Divinas",
  "estagio": 12,
  "defesa": 19,
  "energiaFisica": 20,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 120,
  "resistenciaFisica": 17,
  "resistenciaMagia": 20,
  "moral": 25,
  "ataques": [
   {
    "tipo": "Bastão de luz",
    "ataque": [
     18,
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     14,
     13,
     12,
     11,
     10,
     9
    ],
    "dano": [
     34,
     27,
     20,
     13
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Demônio menor",
  "secao": "Demônios",
  "estagio": 1,
  "defesa": 2,
  "energiaFisica": 10,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 15,
  "resistenciaFisica": 2,
  "resistenciaMagia": 2,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     13,
     10,
     7,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Demônio tipo I",
  "secao": "Demônios",
  "estagio": 3,
  "defesa": 9,
  "energiaFisica": 22,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 18,
  "resistenciaFisica": 4,
  "resistenciaMagia": 4,
  "moral": 15,
  "ataques": [
   {
    "tipo": "Garras",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     2,
     1,
     0,
     -1,
     -2,
     -3
    ],
    "dano": [
     19,
     15,
     11,
     7
    ]
   },
   {
    "tipo": "Hálito flamejante",
    "ataque": [
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     -2,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     5,
     4,
     3,
     2,
     1,
     0
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Demônio tipo II",
  "secao": "Demônios",
  "estagio": 7,
  "defesa": 12,
  "energiaFisica": 25,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 35,
  "resistenciaFisica": 8,
  "resistenciaMagia": 13,
  "moral": 17,
  "ataques": [
   {
    "tipo": "Toque",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     9,
     8,
     7,
     6,
     5,
     4
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   },
   {
    "tipo": "Chamas infernais",
    "ataque": [
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     7,
     6,
     5,
     4,
     3,
     2
    ],
    "dano": [
     22,
     17,
     12,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Demônio tipo III",
  "secao": "Demônios",
  "estagio": 12,
  "defesa": 18,
  "energiaFisica": 55,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 100,
  "resistenciaFisica": 17,
  "resistenciaMagia": 20,
  "moral": 25,
  "ataques": [
   {
    "tipo": "Garras",
    "ataque": [
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     12,
     11,
     10,
     9,
     8,
     7
    ],
    "dano": [
     32,
     24,
     16,
     8
    ]
   },
   {
    "tipo": "Chamas infernais",
    "ataque": [
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     10,
     16,
     15,
     14,
     13,
     12,
     11,
     10,
     13,
     12,
     11,
     10,
     9,
     8
    ],
    "dano": [
     29,
     23,
     17,
     11
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Esqueleto",
  "secao": "Mortos-vivos",
  "estagio": 1,
  "defesa": 1,
  "energiaFisica": 5,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": -5,
  "resistenciaMagia": 1,
  "moral": null,
  "ataques": [
   {
    "tipo": "Lança leve",
    "ataque": [
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -2,
     -3,
     -4,
     -5,
     -6,
     -7
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Zumbi comum",
  "secao": "Mortos-vivos",
  "estagio": 2,
  "defesa": 1,
  "energiaFisica": 15,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 0,
  "resistenciaFisica": 0,
  "resistenciaMagia": 2,
  "moral": null,
  "ataques": [
   {
    "tipo": "Garras",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6,
     -1,
     -2,
     -3,
     -4,
     -5,
     -6
    ],
    "dano": [
     12,
     9,
     6,
     3
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Zumbi consciente",
  "secao": "Mortos-vivos",
  "estagio": 4,
  "defesa": 2,
  "energiaFisica": 15,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 25,
  "resistenciaFisica": 4,
  "resistenciaMagia": 5,
  "moral": 8,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     0,
     5,
     4,
     3,
     2,
     1,
     0,
     -1,
     4,
     3,
     2,
     1,
     0,
     -1
    ],
    "dano": [
     15,
     12,
     9,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Carniçal",
  "secao": "Mortos-vivos",
  "estagio": 6,
  "defesa": 10,
  "energiaFisica": 17,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 30,
  "resistenciaFisica": 6,
  "resistenciaMagia": 6,
  "moral": 10,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     6,
     5,
     4,
     3,
     2,
     1
    ],
    "dano": [
     20,
     15,
     10,
     5
    ]
   },
   {
    "tipo": "Garra",
    "ataque": [
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     6,
     5,
     4,
     3,
     2,
     1
    ],
    "dano": [
     16,
     13,
     10,
     7
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Sombra menor",
  "secao": "Mortos-vivos",
  "estagio": 3,
  "defesa": 5,
  "energiaFisica": 14,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 12,
  "resistenciaFisica": 1,
  "resistenciaMagia": 5,
  "moral": 2,
  "ataques": [
   {
    "tipo": "Toque",
    "ataque": [
     2,
     1,
     0,
     -1,
     -2,
     -3,
     -4,
     -5,
     3,
     2,
     1,
     0,
     -1,
     -2,
     -3,
     4,
     3,
     2,
     1,
     0,
     -1
    ],
    "dano": [
     16,
     12,
     8,
     4
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Sombra maior",
  "secao": "Mortos-vivos",
  "estagio": 7,
  "defesa": 6,
  "energiaFisica": 18,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 35,
  "resistenciaFisica": 7,
  "resistenciaMagia": 9,
  "moral": 12,
  "ataques": [
   {
    "tipo": "Toque",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     10,
     9,
     8,
     7,
     6,
     5
    ],
    "dano": [
     24,
     18,
     12,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Espectro menor",
  "secao": "Mortos-vivos",
  "estagio": 8,
  "defesa": 6,
  "energiaFisica": 3,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 45,
  "resistenciaFisica": 8,
  "resistenciaMagia": 10,
  "moral": 15,
  "ataques": [
   {
    "tipo": "Toque",
    "ataque": [
     8,
     7,
     6,
     5,
     4,
     3,
     2,
     1,
     9,
     8,
     7,
     6,
     5,
     4,
     3,
     10,
     9,
     8,
     7,
     6,
     5
    ],
    "dano": [
     24,
     18,
     12,
     6
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Espectro maior",
  "secao": "Mortos-vivos",
  "estagio": 12,
  "defesa": 7,
  "energiaFisica": 15,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 120,
  "resistenciaFisica": 12,
  "resistenciaMagia": 16,
  "moral": 20,
  "ataques": [
   {
    "tipo": "Toque",
    "ataque": [
     13,
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     14,
     13,
     12,
     11,
     10,
     9,
     8,
     15,
     14,
     13,
     12,
     11,
     10
    ],
    "dano": [
     32,
     24,
     16,
     8
    ]
   }
  ],
  "observacoes": []
 },
 {
  "nome": "Vampiro (forma de Humano)",
  "secao": "Mortos-vivos",
  "estagio": 12,
  "defesa": 5,
  "energiaFisica": 20,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 140,
  "resistenciaFisica": 15,
  "resistenciaMagia": 16,
  "moral": 20,
  "ataques": [
   {
    "tipo": "Garras",
    "ataque": [
     17,
     16,
     15,
     14,
     13,
     12,
     11,
     10,
     15,
     14,
     13,
     12,
     11,
     10,
     9,
     14,
     13,
     12,
     11,
     10,
     9
    ],
    "dano": [
     17,
     14,
     11,
     8
    ]
   }
  ],
  "observacoes": [
   "Mesmo vampiro em três formas; Estágio, Energia e Resistências são comuns às formas."
  ]
 },
 {
  "nome": "Vampiro (forma de Lobo)",
  "secao": "Mortos-vivos",
  "estagio": 12,
  "defesa": 6,
  "energiaFisica": 20,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 140,
  "resistenciaFisica": 15,
  "resistenciaMagia": 16,
  "moral": 20,
  "ataques": [
   {
    "tipo": "Mordida",
    "ataque": [
     12,
     11,
     10,
     9,
     8,
     7,
     6,
     5,
     10,
     9,
     8,
     7,
     6,
     5,
     4,
     7,
     6,
     5,
     4,
     3,
     2
    ],
    "dano": [
     13,
     11,
     9,
     7
    ]
   }
  ],
  "observacoes": [
   "Mesmo vampiro em três formas; Estágio, Energia e Resistências são comuns às formas."
  ]
 },
 {
  "nome": "Vampiro (forma de morcego)",
  "secao": "Mortos-vivos",
  "estagio": 12,
  "defesa": 6,
  "energiaFisica": 20,
  "energiaFisicaArmadura": null,
  "energiaHeroica": 140,
  "resistenciaFisica": 15,
  "resistenciaMagia": 16,
  "moral": 20,
  "ataques": [],
  "observacoes": [
   "Não ataca (sem tabela de ataque).",
   "Mesmo vampiro em três formas; Estágio, Energia e Resistências são comuns às formas."
  ]
 }
];

export const ERRATAS = [
 {
  "criatura": "Anão sacerdote maior",
  "campo": "dano Cajado",
  "impresso": [
   13,
   10,
   6,
   4
  ],
  "usado": [
   13,
   10,
   7,
   4
  ],
  "motivo": "progressão do livro (cai 3 por cor)"
 },
 {
  "criatura": "Gárgula",
  "campo": "dano Garras",
  "impresso": [
   21,
   17,
   14,
   11
  ],
  "usado": [
   20,
   17,
   14,
   11
  ],
  "motivo": "progressão do livro (cai 3 por cor)"
 },
 {
  "criatura": "Dragão do Fogo Jovem",
  "campo": "dano Hálito flamejante",
  "impresso": [
   32,
   26,
   20,
   24
  ],
  "usado": [
   32,
   26,
   20,
   14
  ],
  "motivo": "progressão do livro (cai 6 por cor)"
 },
 {
  "criatura": "Dragão do Fogo Adulto",
  "campo": "dano Garras",
  "impresso": [
   42,
   34,
   23,
   28
  ],
  "usado": [
   42,
   34,
   26,
   18
  ],
  "motivo": "progressão do livro (cai 8 por cor)"
 },
 {
  "criatura": "Dragão do Fogo Adulto",
  "campo": "dano Cauda",
  "impresso": [
   23,
   31,
   24,
   17
  ],
  "usado": [
   38,
   31,
   24,
   17
  ],
  "motivo": "progressão do livro (cai 7 por cor)"
 },
 {
  "criatura": "Salamandra",
  "campo": "dano Hálito flamejante",
  "impresso": [
   26,
   20,
   12,
   6
  ],
  "usado": [
   26,
   20,
   12,
   6
  ],
  "motivo": "não segue a progressão do livro; mantido como impresso (pode ser 24/18/12/6 ou 26/20/14/8)"
 },
 {
  "criatura": "Elfo florestal capitão",
  "campo": "ataque Arco composto (defesas 14 e 15)",
  "impresso": "… 3 4 5",
  "usado": "… 3 2 1",
  "motivo": "sequência impressa com erro; usada a progressão da tabela"
 },
 {
  "criatura": "Orco campeão",
  "campo": "ataque Mangual (defesas 9 a 21)",
  "impresso": "-12…-6 e -15…-10",
  "usado": "12…6 e 15…10",
  "motivo": "sinais de menos impressos por engano; igual ao Mangual do Orco mestre de armas"
 },
 {
  "criatura": "Sombra maior",
  "campo": "ataque Toque (defesas 19 a 21)",
  "impresso": "10 9 8 6 5 4",
  "usado": "10 9 8 7 6 5",
  "motivo": "número 7 omitido na impressão"
 },
 {
  "criatura": "Mercenário",
  "campo": "dano Machado",
  "impresso": "161/13/9/5",
  "usado": "17/13/9/5",
  "motivo": "valor ilegível na digitalização; 17 segue a progressão"
 },
 {
  "criatura": "Orco rei",
  "campo": "Resistência à Magia",
  "impresso": "1",
  "usado": "1",
  "motivo": "mantido como impresso (possível erro de impressão)"
 },
 {
  "criatura": "Elemental da terra forte",
  "campo": "Energia Heróica",
  "impresso": "10",
  "usado": "10",
  "motivo": "mantido como impresso (a sequência da série sugere 16)"
 },
 {
  "criatura": "Elemental do ar forte",
  "campo": "Defesa e Energia Física",
  "impresso": "6 e 8",
  "usado": "6 e 8",
  "motivo": "mantidos como impressos (a sequência da série sugere 9 e 16)"
 },
 {
  "criatura": "Espectro menor",
  "campo": "Energia Física",
  "impresso": "3",
  "usado": "3",
  "motivo": "mantido como impresso"
 }
];
