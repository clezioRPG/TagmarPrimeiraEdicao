import { validarEvocacao } from "./validacoes.mjs";
import { MAGIAS, MISTICOS, pontosMagiaEstagio } from "./magias.mjs";
import { PONTOS_GRUPO, GRUPOS, achaRaca } from "./dados.mjs";
import { MONETARIO, QUANTIDADES, gerarMagico, gerarMonetario, quantidadeMagicos } from "./tesouros.mjs";
import { DINHEIRO_INICIAL, achaClasseSocial, EQUIPAMENTOS, MERCADO, aMoedas, textoMoedas, totalCobre } from "./equipamentos.mjs";
import { COLS, CRIT, FALHA, ARMAS, COR, CHAVE, NIVEIS, valorContraDefesa, danoBase, minimoParaSucesso, badge, resistenciaDe, alturaPesoDe, classeSocialDe, chanceIngresso, REACOES, nivelPorCarisma, SITUACOES_MORAL, MODIFICADORES_MORAL, ATENUACAO_QUEDA, criticoDeQueda, SEM_AGILIDADE, PE_MINIMO, PONTOS_COMBATE, karmaDe, PROFISSOES, EH_INICIAL, EH_ESTAGIO, faixaD10, achaProfissao } from "./tabelas.mjs";

const TIPOS_CRIT = [["corte", "Corte"], ["esmagamento", "Esmagamento"], ["penetracao", "Penetração"], ["garras", "Garras (animais)"], ["magia", "Magia (ataque energético)"]];

function dv2() { return foundry.applications.api.DialogV2; }
// caixa de mensagem do chat (o modulo de tema pergaminho estiliza esta classe)
function caixa(html) { return '<div class="tg-msg">' + html + '</div>'; }
function grade(inner) { return '<div style="display:grid;grid-template-columns:auto 1fr;gap:6px 10px;align-items:center">' + inner + '</div>'; }
function num(nome, valor, extra) { return '<input type="number" name="' + nome + '" value="' + valor + '" ' + (extra || "") + ' style="width:100%">'; }
function sel(nome, opcoes, escolhido) {
  let h = '<select name="' + nome + '" style="width:100%">';
  for (const o of opcoes) { h += '<option value="' + o[0] + '"' + (String(o[0]) === String(escolhido) ? " selected" : "") + '>' + o[1] + '</option>'; }
  return h + '</select>';
}
async function perguntar(titulo, html, rotulo, ler) {
  return dv2().prompt({
    window: {title: titulo},
    classes: ["tagmar1e-dialogo"],
    content: html,
    ok: {label: rotulo, callback: function (ev, button) { return ler(button.form.elements); }},
    rejectClose: false
  });
}
function pctDoTexto(texto, regex) {
  const m = texto.match(regex);
  return m ? Number(m[1]) : null;
}
async function rolarNaColuna(actor, col, flavor) {
  const roll = await new Roll("1d20").evaluate();
  const n = roll.total;
  const letra = COLS[String(col)][n - 1];
  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({actor: actor}),
    flavor: flavor + "<br>Coluna <b>" + col + "</b>: " + badge(letra, n)
  });
  return {n: n, letra: letra};
}

// Integracao opcional com o alvo selecionado pelo jogador no Foundry.
// Nao altera o alvo nem concede permissao para editar sua ficha.
export function alvoDeCombate(alvos) {
  const selecionados = Array.from(alvos ?? []);
  if (selecionados.length !== 1) return null;
  const token = selecionados[0];
  const alvo = token?.actor;
  const defesa = Number(alvo?.system?.defesa);
  if (!Number.isFinite(defesa)) return null;
  return {nome: String(token?.name || alvo?.name || "Alvo"), defesa: Math.max(1, Math.min(21, Math.round(defesa)))};
}
function alvoSelecionado() { return alvoDeCombate(game.user?.targets); }
// Resultado temporário por cliente: nunca grava dano sem confirmação do usuário.
let ultimoDanoDeAtaque = null;
function registrarDanoDoAtaque(alvo, valor, tipo, origem) {
  const token = Array.from(game.user?.targets ?? [])[0];
  if (!alvo || !token || !Number.isFinite(valor) || valor < 0) {
    ultimoDanoDeAtaque = null;
    return;
  }
  ultimoDanoDeAtaque = {tokenId: token.id, actorUuid: token.actor?.uuid,
    valor: Math.round(valor), tipo, origem};
}
export function sugestaoDanoParaAlvo(token) {
  const r = ultimoDanoDeAtaque;
  return r && token?.id === r.tokenId && token.actor?.uuid === r.actorUuid ? {...r} : null;
}

// ATAQUE: coluna = nivel + ajuste de Agilidade + valor da arma contra a Defesa (+ extra)
export async function atacar(actor, idx) {
  const s = actor.system;
  const arma = s.armas[idx];
  if (!arma || !ARMAS[arma.nome]) { ui.notifications.warn("Escolha uma arma da lista na ficha."); return; }
  const nivelArma = arma.nivelEfetivo ?? arma.nivel ?? 0;
  const alvo = alvoSelecionado();
  const html = grade(
    '<label>Defesa do alvo</label>' + num("defesa", alvo?.defesa ?? 10, 'min="1" max="21"') +
    '<label>Ajuste extra</label>' + num("extra", 0) +
    '<label>Treino na arma</label>' + sel("treino", [["nivel", "Com nível no grupo"], ["sem", "Sem nível (coluna -7, sem Agilidade)"]], nivelArma > 0 || SEM_AGILIDADE.indexOf(arma.nome) >= 0 ? "nivel" : "sem") +
    '<label>Tipo de crítico</label>' + sel("tipo", TIPOS_CRIT, "corte"));
  const d = await perguntar("Ataque: " + arma.nome, html, "Atacar", function (f) {
    return {defesa: Number(f.defesa.value), extra: Number(f.extra.value), tipo: f.tipo.value, treino: f.treino.value};
  });
  if (!d || !Number.isFinite(d.defesa) || !Number.isFinite(d.extra)) return;

  const aAgi = s.caracteristicas.agilidade.ajuste;
  const aFor = s.caracteristicas.forca.ajuste;
  const defAv = Math.max(1, Math.min(21, Math.round(d.defesa)));
  const aviso = defAv !== d.defesa ? " (Defesa limitada a " + defAv + ")" : "";
  const vArma = valorContraDefesa(arma.nome, defAv);
  const semAgi = SEM_AGILIDADE.indexOf(arma.nome) >= 0;
  const aAgiUso = semAgi ? 0 : aAgi;
  const semNivel = d.treino === "sem";
  const bruta = semNivel ? Math.round(-7 + d.extra) : Math.round(nivelArma + aAgiUso + vArma + d.extra);   // item 12.2: arma sem nivel = coluna -7, sem ajuste de Agilidade
  const col = Math.max(-7, Math.min(20, bruta));
  const avCol = col !== bruta ? " (coluna limitada de " + bruta + ")" : "";
  const dano = function (pct) { return danoBase(arma.nome, pct) + aFor; };
  const resumo = "<b>" + actor.name + "</b> ataca com <b>" + arma.nome + "</b>" + (alvo ? " contra <b>" + foundry.utils.escapeHTML(alvo.nome) + "</b>" : "") + " vs Defesa " + defAv + aviso +
    (semNivel ? "<br>Sem nível na arma: coluna -7 + " + d.extra + " (extra) = <b>" + col + "</b>" + avCol : "<br>Coluna: " + nivelArma + " (nível) + " + aAgiUso + " (Agi) + " + vArma + " (arma) + " + d.extra + " (extra) = <b>" + col + "</b>" + avCol) +
    "<br>Ajuste de Força: " + aFor;

  const r1 = await rolarNaColuna(actor, col, resumo);
  const c1 = COR[r1.letra];
  let msg;
  let danoSugerido = null;
  let tipoSugerido = "normal";
  if (c1.pct > 0) {
    danoSugerido = dano(c1.pct);
    msg = "<b>" + c1.txt + "</b>: dano <b>" + dano(c1.pct) + "</b> (na Energia Heróica; quando ela acabar, na Física, descontando a absorção da armadura)";
  } else if (r1.letra === "B") {
    msg = "<b>Errou o golpe.</b>";
  } else {
    const ehCrit = r1.letra === "C";
    const r2 = await rolarNaColuna(actor, col, ehCrit ? "<b>Crítico</b> (" + d.tipo + ")" : "<b>Falha</b>");
    const tabela = ehCrit ? CRIT[d.tipo] : FALHA;
    const efeito = tabela[CHAVE[r2.letra]];
    if (ehCrit) {
      const p = pctDoTexto(efeito, /^(\d+)% de dano/);
      if (p) { danoSugerido = dano(p); tipoSugerido = "critico"; }
      const txt = p ? "<br><b>Dano: " + dano(p) + "</b> direto na Energia Física, ignorando a armadura." : "";
      msg = "<b>CRÍTICO (" + d.tipo + "):</b> " + efeito + txt;
    } else {
      const p = pctDoTexto(efeito, /(\d+)% de dano em si/);
      const txt = p ? "<br><b>Você sofre " + dano(p) + " de dano.</b>" : "";
      msg = "<b>FALHA:</b> " + efeito + txt;
    }
  }
  registrarDanoDoAtaque(alvo, danoSugerido, tipoSugerido, actor.name + " — " + arma.nome);
  await ChatMessage.create({speaker: ChatMessage.getSpeaker({actor: actor}), content: caixa(msg + (danoSugerido !== null && alvo ? "<br><i>Dano disponível em ‘Dano no alvo’ para confirmação.</i>" : ""))});
}

// HABILIDADE: sucesso = d20 >= menor numero da cor de dificuldade na coluna (Total da habilidade)
export async function testarHabilidade(actor, idx) {
  const hab = actor.system.habilidades[idx];
  if (!hab) return;
  const niveis = NIVEIS.map(function (n, i) { return [i, n.nome]; });
  const html = grade(
    '<label>Dificuldade</label>' + sel("nivel", niveis, 2) +
    '<label>Tentativa nº</label>' + num("tent", 1, 'min="1"') +
    '<label>Ajudantes com nível (+1 cada)</label>' + num("ajud", 0, 'min="0"') +
    '<label>Ajuste extra</label>' + num("adj", 0));
  const d = await perguntar("Habilidade: " + (hab.nome || "sem nome"), html, "Rolar d20", function (f) {
    return {nivel: Number(f.nivel.value), tent: Math.max(1, Number(f.tent.value)), adj: Number(f.adj.value), ajud: Math.max(0, Number(f.ajud.value))};
  });
  if (!d || ![d.nivel, d.tent, d.adj, d.ajud].every(Number.isFinite)) return;

  const bruta = Math.round(hab.total + d.adj + d.ajud);   // ação conjunta: +1 por ajudante com nível (item 6.2)
  const col = Math.max(-7, Math.min(20, bruta));
  const avCol = col !== bruta ? " (coluna limitada de " + bruta + ")" : "";
  const idxNivel = d.nivel + 2 * (d.tent - 1);
  const speaker = ChatMessage.getSpeaker({actor: actor});
  if (idxNivel >= NIVEIS.length) {
    await ChatMessage.create({speaker: speaker, content: caixa("<b>Impossível.</b> Depois de tantas tentativas a dificuldade passou do Absurdo: nenhum dado é rolado e a ação falha.")});
    return;
  }
  const nivel = NIVEIS[idxNivel];
  const minimo = minimoParaSucesso(col, nivel.cor);
  const roll = await new Roll("1d20").evaluate();
  const n = roll.total;
  const letra = COLS[String(col)][n - 1];
  const ok = letra !== "V" && minimo !== null && n >= minimo;
  const cabeca = "<b>" + actor.name + "</b> - " + (hab.nome || "habilidade") + " (coluna <b>" + col + "</b>" + avCol + ")" +
    "<br>Dificuldade: <b>" + nivel.nome + "</b> (" + COR[nivel.cor].nome + "), tentativa " + d.tent +
    "<br>Precisa de <b>" + (minimo === null ? "nenhum resultado serve" : minimo + " ou mais") + "</b> no d20";
  await roll.toMessage({speaker: speaker, flavor: cabeca + "<br>Rolou: " + badge(letra, n)});
  let msg;
  if (letra === "V") msg = "<b>FALHA</b> (verde). Algo terrível ou embaraçoso pode acontecer, a critério do Mestre.";
  else if (ok) msg = "<b>SUCESSO!</b>";
  else msg = "<b>Fracasso.</b> Se tentar de novo, a dificuldade sobe 2 níveis (próxima tentativa: nº " + (d.tent + 1) + ").";
  await ChatMessage.create({speaker: speaker, content: caixa(msg)});
}

// Dano direcionado: exige um unico alvo e permissao real para alterar seu Actor.
// O valor e o tipo sao sempre confirmados na janela antes de qualquer atualizacao.
export async function aplicarDanoNoAlvo() {
  const tokens = Array.from(game.user?.targets ?? []);
  if (tokens.length !== 1) {
    ui.notifications.warn("Marque exatamente um token como alvo antes de aplicar dano.");
    return;
  }
  const actor = tokens[0]?.actor;
  if (!actor) { ui.notifications.warn("O token selecionado nao possui personagem ou criatura."); return; }
  if (!actor.isOwner) {
    ui.notifications.warn("Voce nao tem permissao para alterar a energia deste alvo. Solicite ao Mestre.");
    return;
  }
  const sugestao = sugestaoDanoParaAlvo(tokens[0]);
  await aplicarDano(actor, sugestao);
}

// DANO: normal tira da EH (o excesso some); com EH zerada vai na EF e a armadura absorve primeiro; critico vai direto na EF
export async function aplicarDano(actor, sugestao = null) {
  if (!actor?.isOwner) { ui.notifications.warn("Sem permissao para aplicar dano neste personagem."); return; }
  const s = actor.system;
  const html = grade(
    (sugestao ? '<p style="grid-column:1/-1">Último ataque: <b>' + foundry.utils.escapeHTML(sugestao.origem) + '</b>. Confira o valor antes de aplicar.</p>' : '') +
    '<label>Dano recebido</label>' + num("dano", sugestao?.valor ?? 0, 'min="0"') +
    '<label>Tipo do golpe</label>' + sel("tipo", [["normal", "Normal"], ["critico", "Crítico (direto na EF)"]], sugestao?.tipo ?? "normal"));
  const d = await perguntar("Aplicar dano em " + actor.name, html, "Aplicar", function (f) {
    return {dano: Number(f.dano.value), tipo: f.tipo.value};
  });
  if (!d || !Number.isFinite(d.dano) || d.dano < 0 || !["normal", "critico"].includes(d.tipo)) return;

  const dano = Math.max(0, Math.round(d.dano));
  let eh = s.eh.value, ef = s.ef.value, abs = s.absorcaoAtual;
  const total = s.absorcaoTotal;
  const linhas = [];
  if (d.tipo === "critico") {
    ef -= dano;
    linhas.push("Crítico: <b>" + dano + "</b> direto na EF, ignorando a armadura (ela não perde absorção).");
  } else if (eh > 0) {
    const perdido = Math.min(eh, dano);
    eh = Math.max(0, eh - dano);
    linhas.push("<b>" + perdido + "</b> de dano na Energia Heróica." + (dano > perdido ? " O excesso (" + (dano - perdido) + ") desaparece." : ""));
    if (eh === 0) linhas.push("EH zerada: os próximos golpes vão na Energia Física.");
  } else {
    const absorvido = Math.min(abs, dano);
    abs -= absorvido;
    const passou = dano - absorvido;
    ef -= passou;
    linhas.push("EH já zerada. Armadura absorveu <b>" + absorvido + "</b> e <b>" + passou + "</b> foi na EF.");
  }
  let estado = "";
  if (ef < -7) estado = "<br><b>MORTE imediata</b> (EF abaixo de -7).";
  else if (ef <= 0) estado = "<br><b>Inconsciente</b> (EF entre 0 e -7): morre em 1 hora sem cuidados médicos (Medicina, dificuldade média).";
  if (!actor.isOwner) { ui.notifications.warn("Permissao de edicao perdida; dano nao aplicado."); return; }
  await actor.update({"system.eh.value": eh, "system.ef.value": ef, "system.absorcao.restante": abs});
  if (sugestao && ultimoDanoDeAtaque?.actorUuid === actor.uuid) ultimoDanoDeAtaque = null;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({actor: actor}),
    content: caixa("<b>" + actor.name + "</b><br>" + linhas.join("<br>") + "<br>Agora: <b>EH " + eh + "</b> | <b>EF " + ef + "</b> | <b>Absorção " + abs + "</b> de " + total + estado)
  });
}

// ENERGIA HEROICA: 1d10 na tabela da profissao (IV-3.2.1a no estagio 1, IV-3.2.1b nos seguintes) + ajuste de Fisico
export async function rolarEH(actor) {
  const s = actor.system;
  const padrao = achaProfissao(s.profissao) || "Guerreiro";
  const html = grade(
    '<label>Profissão</label>' + sel("prof", PROFISSOES.map(function (p) { return [p, p]; }), padrao) +
    '<label>Rolagem</label>' + sel("tipo", [["inicial", "Estágio 1 (EH inicial)"], ["novo", "Novo estágio (soma à EH atual)"]], s.estagio > 1 ? "novo" : "inicial"));
  const d = await perguntar("Energia Heróica de " + actor.name, html, "Rolar 1d10", function (f) {
    return {prof: f.prof.value, tipo: f.tipo.value};
  });
  if (!d || !EH_INICIAL[d.prof]) return;
  const roll = await new Roll("1d10").evaluate();
  const n = roll.total;
  const tabela = d.tipo === "inicial" ? EH_INICIAL : EH_ESTAGIO;
  const base = tabela[d.prof][faixaD10(n)];
  const aFis = s.caracteristicas.fisico.ajuste;
  const ganho = base + aFis;
  let max, atual;
  if (d.tipo === "inicial") { max = ganho; atual = ganho; }
  else { max = s.eh.max + ganho; atual = s.eh.value + ganho; }
  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({actor: actor}),
    flavor: "<b>" + actor.name + "</b> - Energia Heróica (" + d.prof + ", " + (d.tipo === "inicial" ? "estágio 1" : "novo estágio") + ")" +
      "<br>1d10 = <b>" + n + "</b> → tabela " + base + " + ajuste de Físico " + aFis + " = <b>" + ganho + "</b>"
  });
  await actor.update({"system.eh.max": max, "system.eh.value": atual});
  await ChatMessage.create({speaker: ChatMessage.getSpeaker({actor: actor}), content: caixa("EH máxima agora: <b>" + max + "</b>")});
}

// tipo de critico sugerido pelo nome do ataque (o jogador pode trocar na janela)
export function critPadrao(tipo) {
  const t = String(tipo || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  if (/garra|patada/.test(t)) return "garras";
  if (/toque|halito|chamas|jato|bastao/.test(t)) return "magia";
  if (/espada|machado|gladio|faca|montante/.test(t)) return "corte";
  if (/lanca|arco|punhal|presas|chifre|picada|mordida/.test(t)) return "penetracao";
  return "esmagamento";
}

// ATAQUE DE CRIATURA: a coluna vem direto da tabela da criatura (Ataque x Defesa) e o dano das 4 porcentagens
export async function atacarCriatura(actor, idx) {
  const s = actor.system;
  const ata = s.ataques[idx];
  if (!ata || ata.ataque.length !== 21) { ui.notifications.warn("Este ataque precisa de 21 valores de Ataque x Defesa."); return; }
  const alvo = alvoSelecionado();
  const html = grade(
    '<label>Defesa do alvo</label>' + num("defesa", alvo?.defesa ?? 10, 'min="1" max="21"') +
    '<label>Ajuste extra</label>' + num("extra", 0) +
    '<label>Tipo de crítico</label>' + sel("tipo", TIPOS_CRIT, critPadrao(ata.tipo)));
  const d = await perguntar("Ataque: " + actor.name + " (" + ata.tipo + ")", html, "Atacar", function (f) {
    return {defesa: Number(f.defesa.value), extra: Number(f.extra.value), tipo: f.tipo.value};
  });
  if (!d || !Number.isFinite(d.defesa) || !Number.isFinite(d.extra)) return;

  const defAv = Math.max(1, Math.min(21, Math.round(d.defesa)));
  const aviso = defAv !== d.defesa ? " (Defesa limitada a " + defAv + ")" : "";
  const base = ata.ataque[defAv - 1];
  const bruta = Math.round(base + d.extra);
  const col = Math.max(-7, Math.min(20, bruta));
  const avCol = col !== bruta ? " (coluna limitada de " + bruta + ")" : "";
  const dano = function (pct) {
    if (ata.dano.length !== 4) return null;
    return ata.dano[[100, 75, 50, 25].indexOf(pct)];
  };
  const txtDano = function (pct) { const v = dano(pct); return v === null ? "dano especial (veja a descrição)" : String(v); };
  const resumo = "<b>" + actor.name + "</b> ataca com <b>" + ata.tipo + "</b>" + (alvo ? " contra <b>" + foundry.utils.escapeHTML(alvo.nome) + "</b>" : "") + " vs Defesa " + defAv + aviso +
    "<br>Coluna: " + base + " (tabela) + " + d.extra + " (extra) = <b>" + col + "</b>" + avCol;

  const r1 = await rolarNaColuna(actor, col, resumo);
  const c1 = COR[r1.letra];
  let msg;
  let danoSugerido = null;
  let tipoSugerido = "normal";
  if (c1.pct > 0) {
    danoSugerido = dano(c1.pct);
    msg = "<b>" + c1.txt + "</b>: dano <b>" + txtDano(c1.pct) + "</b> (na Energia Heróica; quando ela acabar, na Física, descontando a absorção da armadura)";
  } else if (r1.letra === "B") {
    msg = "<b>Errou o golpe.</b>";
  } else {
    const ehCrit = r1.letra === "C";
    const r2 = await rolarNaColuna(actor, col, ehCrit ? "<b>Crítico</b> (" + d.tipo + ")" : "<b>Falha</b>");
    const tabela = ehCrit ? CRIT[d.tipo] : FALHA;
    const efeito = tabela[CHAVE[r2.letra]];
    if (ehCrit) {
      const p = pctDoTexto(efeito, /^(\d+)% de dano/);
      if (p) { danoSugerido = dano(p); tipoSugerido = "critico"; }
      const txt = p ? "<br><b>Dano: " + txtDano(p) + "</b> direto na Energia Física, ignorando a armadura." : "";
      msg = "<b>CRÍTICO (" + d.tipo + "):</b> " + efeito + txt;
    } else {
      const p = pctDoTexto(efeito, /(\d+)% de dano em si/);
      const txt = p ? "<br><b>Sofre " + txtDano(p) + " de dano.</b>" : "";
      msg = "<b>FALHA:</b> " + efeito + txt;
    }
  }
  registrarDanoDoAtaque(alvo, danoSugerido, tipoSugerido, actor.name + " — " + ata.tipo);
  await ChatMessage.create({speaker: ChatMessage.getSpeaker({actor: actor}), content: caixa(msg + (danoSugerido !== null && alvo ? "<br><i>Dano disponível em ‘Dano no alvo’ para confirmação.</i>" : ""))});
}

// MAGIA: gasta Karma (Forca do Ataque = Karma gasto, no maximo o Estagio) e, nas magias de ataque fisico, ataca na coluna igual ao nivel
export async function evocarMagia(actor, idx) {
  const s = actor.system;
  const m = s.magias[idx];
  const dados = m ? MAGIAS[m.nome] : null;
  if (!m || !dados) { ui.notifications.warn("Escolha uma magia da lista na ficha."); return; }
  const possiveis = dados.dificuldades.filter(function (d) { return d <= m.nivel; });
  const padrao = possiveis.length ? possiveis[0] : 1;
  const info = dados.dificuldades.length ? "Efeitos (dificuldades): " + dados.dificuldades.join(", ") : "Veja os efeitos no livro";
  const html = '<p style="margin:0 0 6px"><b>' + m.nome + '</b> nível ' + m.nivel + '. ' + info + '. Karma: ' + s.karma.value + ' de ' + s.karmaMax + '.</p>' + grade(
    '<label>Dificuldade do efeito</label>' + num("dif", padrao, 'min="1" max="10"') +
    '<label>Karma a gastar (mín. = dificuldade)</label>' + num("karma", padrao, 'min="1"'));
  const d = await perguntar("Evocar: " + m.nome, html, "Evocar", function (f) {
    return {dif: Number(f.dif.value), karma: Number(f.karma.value)};
  });
  if (!d || !Number.isFinite(d.dif) || !Number.isFinite(d.karma)) return;
  const dif = d.dif;
  const gasto = d.karma;
  const speaker = ChatMessage.getSpeaker({actor: actor});
  const erroEvocacao = validarEvocacao({dificuldades: dados.dificuldades, nivel: m.nivel,
    dificuldade: dif, gasto, karma: s.karma.value, estagio: s.estagio});
  if (erroEvocacao) { ui.notifications.warn(erroEvocacao); return; }
  // A janela pode permanecer aberta enquanto outra evocação gasta Karma.
  // Reconfere o estado real antes de subtrair recursos.
  const atual = actor.system;
  const magiaAtual = atual.magias[idx];
  if (!magiaAtual || magiaAtual.nome !== m.nome) { ui.notifications.warn("A magia mudou durante a confirmação; tente novamente."); return; }
  const erroAtual = validarEvocacao({dificuldades: dados.dificuldades, nivel: magiaAtual.nivel,
    dificuldade: dif, gasto, karma: atual.karma.value, estagio: atual.estagio});
  if (erroAtual) { ui.notifications.warn(erroAtual); return; }
  const karmaRestante = atual.karma.value - gasto;
  await actor.update({"system.karma.value": karmaRestante});
  const cab = "<b>" + actor.name + "</b> evoca <b>" + m.nome + "</b> (efeito " + dif + ")<br>Evocação: " + dados.evocacao + " | Alcance: " + dados.alcance + " | Duração: " + dados.duracao +
    "<br>Karma gasto: <b>" + gasto + "</b> (Karma restante: " + karmaRestante + ") | <b>Força do Ataque: " + gasto + "</b>";
  const ef = dados.ataque.find(function (a) { return a.dificuldade === dif; });
  if (!dados.ataque.length || !ef) {
    await ChatMessage.create({speaker: speaker, content: caixa(cab + "<br>Efeito não catalogado como ataque físico nesta base. Consulte o texto da magia na 1ª Edição antes de determinar se cabe Resistência à Magia, outro teste ou nenhum teste. Força do Ataque: " + gasto + ".")});
    return;
  }
  // ataque fisico: resolvido na Tabela de Resolucao com coluna = nivel na magia; a vitima nao tem Resistencia a Magia
  const col = Math.max(-7, Math.min(20, m.nivel));
  const r1 = await rolarNaColuna(actor, col, cab + "<br>Ataque físico: coluna = nível na magia (" + m.nivel + "); dano máximo do efeito: " + ef.danoMaximo);
  const c1 = COR[r1.letra];
  const dano = function (pct) { return Math.round(ef.danoMaximo * pct / 100); };
  let msg;
  if (c1.pct > 0) msg = "<b>" + c1.txt + "</b>: dano <b>" + dano(c1.pct) + "</b> (na Energia Heróica; quando ela acabar, na Física, descontando a absorção da armadura)";
  else if (r1.letra === "B") msg = "<b>Errou o alvo.</b>";
  else {
    const ehCrit = r1.letra === "C";
    const r2 = await rolarNaColuna(actor, col, ehCrit ? "<b>Crítico</b> (magia)" : "<b>Falha</b>");
    const efeito = (ehCrit ? CRIT.magia : FALHA)[CHAVE[r2.letra]];
    if (ehCrit) {
      const p = pctDoTexto(efeito, /^(\d+)% de dano/);
      msg = "<b>CRÍTICO (magia):</b> " + efeito + (p ? "<br><b>Dano: " + dano(p) + "</b> direto na Energia Física, ignorando a armadura." : "");
    } else {
      const p = pctDoTexto(efeito, /(\d+)% de dano em si/);
      msg = "<b>FALHA:</b> " + efeito + (p ? "<br><b>Sofre " + dano(p) + " de dano.</b>" : "");
    }
  }
  await ChatMessage.create({speaker: speaker, content: caixa(msg)});
}

// RESISTENCIA: 1d20 contra o numero da Tabela de Resistencia (Forca do Ataque x Forca da Defesa); maior ou igual = resistiu
export async function testarResistencia(actor) {
  const s = actor.system;
  const def = {magia: s.resistenciaMagia, fisica: s.resistenciaFisica};
  const html = grade(
    '<label>Tipo</label>' + sel("tipo", [["magia", "Resistência à Magia (" + def.magia + ")"], ["fisica", "Resistência Física (" + def.fisica + ")"]], "magia") +
    '<label>Força do Ataque</label>' + num("atq", 5, 'min="1"'));
  const d = await perguntar("Testar resistência de " + actor.name, html, "Rolar d20", function (f) {
    return {tipo: f.tipo.value, atq: Number(f.atq.value)};
  });
  if (!d || !Number.isFinite(d.atq)) return;
  const forcaDef = def[d.tipo];
  const necessario = resistenciaDe(d.atq, forcaDef);
  const roll = await new Roll("1d20").evaluate();
  const n = roll.total;
  const resistiu = n >= necessario;
  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({actor: actor}),
    flavor: "<b>" + actor.name + "</b> tenta resistir (" + (d.tipo === "magia" ? "à Magia" : "Física") + ")<br>Força do Ataque " + d.atq + " x Força da Defesa " + forcaDef + " → precisa de <b>" + necessario + " ou mais</b>"
  });
  await ChatMessage.create({speaker: ChatMessage.getSpeaker({actor: actor}), content: caixa(
    "Rolou <b>" + n + "</b>: " + (resistiu ? "<b>RESISTIU</b> — a magia não surte efeito." : "<b>NÃO RESISTIU</b> — o efeito atinge a vítima."))});
}

// SUBIR DE ESTAGIO (capitulo VII, item 5): confere os PE, muda o Estagio e mostra o passo a passo com os numeros do novo Estagio
export async function subirEstagio(actor) {
  const s = actor.system;
  const novo = s.estagio + 1;
  if (novo > PE_MINIMO.length) { ui.notifications.warn("A tabela de experiência do livro vai até o Estágio " + PE_MINIMO.length + "."); return; }
  const minimo = PE_MINIMO[novo - 1];
  if (s.pe < minimo) {
    const sim = await dv2().confirm({
      window: {title: "Subir de Estágio"}, classes: ["tagmar1e-dialogo"],
      content: "<p>Os PE (" + s.pe + ") ainda não chegam ao mínimo do Estágio " + novo + " (" + minimo + "). Subir mesmo assim?</p>",
      rejectClose: false
    });
    if (!sim) return;
  }
  const car = s.caracteristicas;
  const prof = achaProfissao(s.profissao);
  const antes = {karma: s.karmaMax, rf: s.resistenciaFisica, rm: s.resistenciaMagia};
  const aFis = car.fisico.ajuste, aAura = car.aura.ajuste;
  // Congela os pontos dos estágios anteriores quando ainda não há histórico.
  // Para fichas legadas, os valores anteriores são reconstruídos pelo Intelecto atual
  // (não é possível recuperar atributos históricos não armazenados).
  const historicoAnterior = Array.from(s.historicoPontosMagia ?? []);
  let historicoNovo = historicoAnterior.slice(0, s.estagio);
  if (MISTICOS.indexOf(prof) >= 0 && historicoNovo.length < s.estagio) {
    for (let e = historicoNovo.length + 1; e <= s.estagio; e++) {
      const ganhoAntigo = pontosMagiaEstagio(car.intelecto.final, e);
      if (ganhoAntigo === null) break;
      historicoNovo.push(ganhoAntigo);
    }
  }
  const ganhoNovo = MISTICOS.indexOf(prof) >= 0 ? pontosMagiaEstagio(car.intelecto.final, novo) : null;
  if (ganhoNovo !== null && historicoNovo.length === s.estagio) historicoNovo.push(ganhoNovo);
  // Preserva créditos de habilidades já recebidos, inclusive se a profissão mudar.
  // Para personagens legados, os estágios anteriores são estimados pela profissão atual.
  const historicoHabAnterior = Array.from(s.historicoPontosHabilidades ?? []);
  const historicoHabNovo = historicoHabAnterior.slice(0, s.estagio).map(e =>
    Object.fromEntries(Object.keys(GRUPOS).map(g => [g, Number(e?.[g]) || 0]))
  );
  if (prof && historicoHabNovo.length < s.estagio) {
    for (let e = historicoHabNovo.length; e < s.estagio; e++) {
      historicoHabNovo.push(Object.fromEntries(Object.keys(GRUPOS).map(g => [g, PONTOS_GRUPO[prof][g]])));
    }
  }
  if (prof && historicoHabNovo.length === s.estagio) {
    historicoHabNovo.push(Object.fromEntries(Object.keys(GRUPOS).map(g => [g, PONTOS_GRUPO[prof][g]])));
  }
  await actor.update({"system.estagio": novo, "system.historicoPontosMagia": historicoNovo,
    "system.historicoPontosHabilidades": historicoHabNovo});
  const linhas = ["<b>" + actor.name + "</b> passou para o <b>Estágio " + novo + "</b>."];
  if (prof) {
    const pts = PONTOS_GRUPO[prof];
    linhas.push("<b>Habilidades</b>: receba " + Object.keys(pts).map(function (g) { return GRUPOS[g] + " " + pts[g]; }).join(", ") + " pontos (o que sobrar fica acumulado; o nível não passa do Estágio).");
    if (historicoHabAnterior.length < s.estagio) linhas.push("<b>Aviso de migração (habilidades)</b>: créditos anteriores reconstruídos pela profissão atual. Confira personagens que mudaram de profissão ou receberam créditos especiais.");
    linhas.push("<b>Combate</b>: receba " + PONTOS_COMBATE[prof] + (PONTOS_COMBATE[prof] === 1 ? " ponto" : " pontos") + " para comprar ou melhorar grupos de armas (o nível do grupo não passa do Estágio).");
    if (MISTICOS.indexOf(prof) >= 0) {
      if (ganhoNovo === null) linhas.push("<b>Magia</b>: o estágio " + novo + " não está coberto pela tabela V-9.5a cadastrada. Consulte a regra original/Mestre e registre os pontos manualmente; o sistema não inventará um valor.");
      else linhas.push("<b>Magia</b>: receba " + ganhoNovo + " pontos (Intelecto " + car.intelecto.final + ") para comprar magias ou subir seus níveis. Valor registrado no histórico.");
      if (historicoAnterior.length < s.estagio) linhas.push("<b>Aviso de migração</b>: pontos de magia dos estágios anteriores reconstruídos pelo Intelecto atual; confira fichas cujo Intelecto mudou.");
    }
    if (prof === "Mago" || prof === "Sacerdote") linhas.push("Se ainda não é de " + (prof === "Mago" ? "um Colégio" : "uma Ordem") + ", veja a chance de ser aceito (capítulo V, item " + (prof === "Mago" ? "9.4.1" : "9.3.1") + ").");
  } else {
    linhas.push("Informe a profissão na ficha para ver os pontos de habilidade, combate e magia deste Estágio.");
  }
  const karmaNovo = karmaDe(car.aura.final, novo);
  linhas.push("<b>Energia Heróica</b>: role a EH deste Estágio agora (a janela abre em seguida).");
  linhas.push("<b>Resistência Física</b>: " + antes.rf + " → " + (novo + aFis) + " | <b>Resistência à Magia</b>: " + antes.rm + " → " + (novo + aAura) + " | <b>Karma máximo</b>: " + antes.karma + " → " + karmaNovo);
  linhas.push("Depois de comprar habilidades e armas, confira a tabela de armas e o dano na ficha; os totais já são recalculados.");
  await ChatMessage.create({speaker: ChatMessage.getSpeaker({actor: actor}), content: caixa(linhas.join("<br>"))});
  await rolarEH(actor);
}

// ---------- Criacao do personagem ----------
async function rolar2d10(actor, flavor) {
  const roll = await new Roll("2d10").evaluate();
  await roll.toMessage({speaker: ChatMessage.getSpeaker({actor: actor}), flavor: flavor});
  return roll.total;
}

// Tabela II-8: 2d10 -> altura (cm) e peso (kg) da raca
export async function sortearAlturaPeso(actor) {
  const raca = achaRaca(actor.system.raca);
  if (!raca) { ui.notifications.warn("Informe a raça (Humanos, Pequeninos, Anões, Elfos Florestais, Elfos Dourados ou Meio-elfos) para sortear altura e peso."); return; }
  const total = await rolar2d10(actor, "<b>" + actor.name + "</b> - altura e peso (" + raca + ")");
  const ap = alturaPesoDe(raca, total);
  await actor.update({"system.altura": String(ap[0]), "system.peso": String(ap[1])});
  await ChatMessage.create({speaker: ChatMessage.getSpeaker({actor: actor}), content: caixa("2d10 = <b>" + total + "</b>: altura <b>" + ap[0] + " cm</b> e peso <b>" + ap[1] + " kg</b> (gravados na ficha).")});
}

// Tabela II-9.9: 2d10 -> classe social da raca
export async function sortearClasseSocial(actor) {
  const raca = achaRaca(actor.system.raca);
  if (!raca) { ui.notifications.warn("Informe a raça para sortear a classe social."); return; }
  const total = await rolar2d10(actor, "<b>" + actor.name + "</b> - classe social (" + raca + ")");
  const classe = classeSocialDe(raca, total);
  await actor.update({"system.classeSocial": classe});
  await ChatMessage.create({speaker: ChatMessage.getSpeaker({actor: actor}), content: caixa("2d10 = <b>" + total + "</b>: classe social <b>" + classe + "</b> (gravada na ficha).")});
}

// Tabelas V-9.3.1 e V-9.4.1: chance em 1d10 de entrar em uma Ordem (Sacerdote) ou Colegio (Mago)
export async function pedirIngresso(actor) {
  const s = actor.system;
  const prof = achaProfissao(s.profissao);
  if (prof !== "Sacerdote" && prof !== "Mago") { ui.notifications.warn("Só Sacerdotes entram em Ordens e só Magos entram em Colégios."); return; }
  if (s.ordem) { ui.notifications.warn("O personagem já pertence a: " + s.ordem + " (só se pode pertencer a uma Ordem)."); return; }
  const opcoes = prof === "Sacerdote" ? ["Ordem Guerreira", "Ordem Espiritual"] : ["Colégio das Ilusões", "Colégio Elemental", "Colégio Necromântico"];
  const chance = chanceIngresso(s.estagio);
  const resumo = chance.auto ? "Estágio " + s.estagio + ": a entrada é automática." : (chance.max === 0 ? "No Estágio 1 ainda não há chance de ser convidado." : "Estágio " + s.estagio + ": entra se tirar de 1 a " + chance.max + " em 1d10.");
  const html = '<p style="margin:0 0 6px">' + resumo + '</p>' + grade('<label>' + (prof === "Sacerdote" ? "Ordem" : "Colégio") + '</label>' + sel("alvo", opcoes.map(function (o) { return [o, o]; }), opcoes[0]));
  const d = await perguntar("Entrar em " + (prof === "Sacerdote" ? "uma Ordem" : "um Colégio"), html, chance.max === 0 ? "Ok" : (chance.auto ? "Entrar" : "Rolar 1d10"), function (f) { return {alvo: f.alvo.value}; });
  if (!d || chance.max === 0) return;
  const speaker = ChatMessage.getSpeaker({actor: actor});
  let entrou = chance.auto;
  if (!chance.auto) {
    const roll = await new Roll("1d10").evaluate();
    entrou = roll.total <= chance.max;
    await roll.toMessage({speaker: speaker, flavor: "<b>" + actor.name + "</b> tenta entrar em <b>" + d.alvo + "</b>: precisa de " + chance.max + " ou menos"});
  }
  if (entrou) {
    await actor.update({"system.ordem": d.alvo});
    const voto = d.alvo === "Ordem Espiritual" ? " Voto da Ordem Espiritual: não vestir armaduras nem elmos e não usar escudos." : "";
    await ChatMessage.create({speaker: speaker, content: caixa("<b>Aceito!</b> " + actor.name + " passa a pertencer a <b>" + d.alvo + "</b> e pode comprar magias da lista da organização." + voto)});
  } else {
    await ChatMessage.create({speaker: speaker, content: caixa("<b>Não foi convidado desta vez.</b> A chance volta a aparecer ao subir de Estágio.")});
  }
}

// ---------- Jogo ----------
// Quedas (cap. XI, item 5): 1 ponto de dano na EF a cada 2 m; Acrobacias atenua; critico pela altura
export async function queda(actor) {
  const s = actor.system;
  const acro = s.habilidades ? s.habilidades.find(function (h) { return h.nome === "Acrobacias"; }) : null;
  const html = grade(
    '<label>Altura da queda (m)</label>' + num("alt", 4, 'min="0"') +
    '<label>Salto</label>' + sel("int", [["nao", "Queda involuntária"], ["sim", "Salto intencional (2 m a menos)"]], "nao") +
    '<label>Acrobacias</label>' + sel("acro", [["sim", acro ? "Testar (total " + acro.total + ")" : "Testar sem nível (coluna -7 + Agilidade)"], ["nao", "Não atenuar"]], "sim"));
  const d = await perguntar("Queda de " + actor.name, html, "Cair", function (f) { return {alt: Number(f.alt.value), intencional: f.int.value === "sim", acro: f.acro.value === "sim"}; });
  if (!d || !Number.isFinite(d.alt) || d.alt < 0) return;
  let h = d.alt - (d.intencional ? 2 : 0);
  const speaker = ChatMessage.getSpeaker({actor: actor});
  let nota = "Queda de " + d.alt + " m" + (d.intencional ? " (intencional: conta " + (d.alt - 2) + " m)" : "");
  if (d.acro) {
    const col = Math.max(-7, Math.min(20, acro ? acro.total : -7 + s.caracteristicas.agilidade.ajuste));
    const r = await rolarNaColuna(actor, col, "<b>" + actor.name + "</b> tenta atenuar a queda com Acrobacias");
    const mod = ATENUACAO_QUEDA[r.letra];
    h += mod;
    nota += "<br>Acrobacias: " + COR[r.letra].nome + " (" + (mod > 0 ? "+" : "") + mod + " m)";
  }
  h = Math.max(0, h);
  const dano = Math.floor(h / 2);
  await actor.update({"system.ef.value": s.ef.value - dano});
  await ChatMessage.create({speaker: speaker, content: caixa(nota + "<br>Altura para o dano: <b>" + h + " m</b> → <b>" + dano + "</b> de dano direto na Energia Física (a Heróica não protege).<br><b>Crítico de queda:</b> " + criticoDeQueda(h))});
}

// Reacao de criaturas (cap. XIII, item 7): coluna da atitude, dificuldade pelo Carisma do personagem
const TEXTO_REACAO = {
  "Agressivo": ["Ataca na hora e com ferocidade.", "Só ameaça e provoca; respondidas, as provocações viram luta. Persuasão pode ajudar a escapar."],
  "Hostil": ["Inicia a luta.", "Vai embora, ainda atento aos jogadores; provocação séria leva à luta. Persuasão é possível."],
  "Neutro": ["Ignora o personagem, tenta se livrar dele ou se sente ofendido.", "Passa a encarar o personagem de modo favorável."],
  "Amistoso": ["Trata bem, mas nega favores com delicadeza e se afasta assim que pode.", "Companheirismo e boas intenções; pedidos só são atendidos com bom uso de Persuasão."],
  "Amigável": ["Faz o possível para ajudar; pedidos fora do normal pedem Persuasão.", "Apoio entusiasmado e toda a ajuda possível."]
};
export async function reacaoCriatura(actor) {
  const s = actor.system;
  const carisma = s.caracteristicas ? s.caracteristicas.carisma.final : 11;
  const html = grade(
    '<label>Atitude inicial</label>' + sel("atitude", Object.keys(REACOES).map(function (k) { return [k, k + " (coluna " + (REACOES[k] > 0 ? "+" : "") + REACOES[k] + ")"]; }), "Neutro") +
    '<label>Ajuste extra</label>' + num("extra", 0));
  const d = await perguntar("Reação das criaturas: " + actor.name, html, "Rolar d20", function (f) { return {atitude: f.atitude.value, extra: Number(f.extra.value)}; });
  if (!d || !Number.isFinite(d.extra)) return;
  const nivel = NIVEIS[nivelPorCarisma(carisma)];
  const col = Math.max(-7, Math.min(20, REACOES[d.atitude] + d.extra));
  const minimo = minimoParaSucesso(col, nivel.cor);
  const roll = await new Roll("1d20").evaluate();
  const n = roll.total;
  const letra = COLS[String(col)][n - 1];
  const ok = letra !== "V" && minimo !== null && n >= minimo;
  await roll.toMessage({speaker: ChatMessage.getSpeaker({actor: actor}), flavor: "<b>" + actor.name + "</b> (Carisma " + carisma + ": " + nivel.nome + ") - atitude " + d.atitude + ", coluna <b>" + col + "</b><br>Precisa de <b>" + (minimo === null ? "nenhum resultado serve" : minimo + " ou mais") + "</b><br>Rolou: " + badge(letra, n)});
  const t = TEXTO_REACAO[d.atitude];
  await ChatMessage.create({speaker: ChatMessage.getSpeaker({actor: actor}), content: caixa("<b>Reação " + (ok ? "positiva" : "negativa") + "</b> (" + d.atitude + "): " + (ok ? t[1] : t[0]))});
}

// Moral das criaturas (cap. XIII, item 6): a coluna e o Moral da criatura; a dificuldade vem da situacao e dos modificadores
export async function testarMoral(actor) {
  const s = actor.system;
  if (s.moral === null || s.moral === undefined) { ui.notifications.warn("Esta criatura não tem Moral na tabela (veja a descrição no livro)."); return; }
  let mods = "";
  for (let i = 0; i < MODIFICADORES_MORAL.length; i++) {
    const m = MODIFICADORES_MORAL[i];
    mods += '<label><input type="checkbox" name="mod' + i + '"> ' + m[0] + ' (' + (m[1] > 0 ? "+" : "") + m[1] + ' nível)</label>';
  }
  const html = grade(
    '<label>Situação</label>' + sel("sit", SITUACOES_MORAL.map(function (t, i) { return [i, NIVEIS[i].nome + ": " + t]; }), 1) +
    '<label>Liderança (soma à coluna)</label>' + num("lider", 0)) + '<div style="margin-top:6px;display:grid;gap:2px">' + mods + '</div>';
  const d = await perguntar("Teste de Moral: " + actor.name, html, "Rolar d20", function (f) {
    let soma = 0;
    for (let i = 0; i < MODIFICADORES_MORAL.length; i++) { if (f["mod" + i].checked) soma += MODIFICADORES_MORAL[i][1]; }
    return {sit: Number(f.sit.value), lider: Number(f.lider.value), mods: soma};
  });
  if (!d || ![d.sit, d.lider, d.mods].every(Number.isFinite)) return;
  const idx = Math.max(0, d.sit + d.mods);
  const speaker = ChatMessage.getSpeaker({actor: actor});
  if (idx >= NIVEIS.length) {
    await ChatMessage.create({speaker: speaker, content: caixa("<b>" + actor.name + "</b>: com os modificadores a dificuldade passa do Absurdo. <b>Foge ou se rende</b> sem rolar.")});
    return;
  }
  const nivel = NIVEIS[idx];
  const col = Math.max(-7, Math.min(20, s.moral + d.lider));
  const minimo = minimoParaSucesso(col, nivel.cor);
  const roll = await new Roll("1d20").evaluate();
  const n = roll.total;
  const letra = COLS[String(col)][n - 1];
  const ok = letra !== "V" && minimo !== null && n >= minimo;
  await roll.toMessage({speaker: speaker, flavor: "<b>" + actor.name + "</b> - Moral (coluna <b>" + col + "</b>)<br>Dificuldade: <b>" + nivel.nome + "</b> (" + COR[nivel.cor].nome + ")<br>Precisa de <b>" + (minimo === null ? "nenhum resultado serve" : minimo + " ou mais") + "</b><br>Rolou: " + badge(letra, n)});
  await ChatMessage.create({speaker: speaker, content: caixa(ok ? "<b>Mantém o moral</b> e continua no combate." : "<b>Falhou no Moral:</b> foge ou se rende, conforme a situação.")});
}

// ---------- Pertences (capitulo VI) ----------
// Tabela VI-3: dinheiro inicial pela classe social
export async function dinheiroInicial(actor) {
  const classe = achaClasseSocial(actor.system.classeSocial);
  if (!classe) { ui.notifications.warn("Informe ou sorteie a classe social (Ex-escravos, Ex-servos, Livre, Pequeno comerciante, Artífice, Grande comerciante, Baixa nobreza ou Alta nobreza)."); return; }
  const m = DINHEIRO_INICIAL[classe];
  await actor.update({"system.dinheiro.mo": m.mo, "system.dinheiro.mp": m.mp, "system.dinheiro.mc": m.mc});
  await ChatMessage.create({speaker: ChatMessage.getSpeaker({actor: actor}), content: caixa("<b>" + actor.name + "</b>: dinheiro inicial de <b>" + classe + "</b>: " + textoMoedas(m) + " (1 m.o. = 10 m.p. = 100 m.c.).")});
}

// Compra no mercado: o preco da tabela vezes a variacao do mercado (Normal x1, Dificil x2, Absurda x5)
export async function comprar(actor) {
  const s = actor.system;
  const grupos = {};
  for (const n of Object.keys(EQUIPAMENTOS)) { (grupos[EQUIPAMENTOS[n].categoria] = grupos[EQUIPAMENTOS[n].categoria] || []).push(n); }
  let opcoes = "";
  for (const g of Object.keys(grupos)) {
    opcoes += '<optgroup label="' + g + '">';
    for (const n of grupos[g]) opcoes += '<option value="' + n + '">' + n + ' (' + EQUIPAMENTOS[n].precoTxt + ')</option>';
    opcoes += '</optgroup>';
  }
  const html = '<p style="margin:0 0 6px">Você tem: <b>' + textoMoedas(s.dinheiro) + '</b></p>' + grade(
    '<label>Item</label><select name="item" style="width:100%">' + opcoes + '</select>' +
    '<label>Quantidade</label>' + num("qtd", 1, 'min="1"') +
    '<label>Mercado</label>' + sel("mercado", Object.keys(MERCADO).map(function (k) { return [k, k + " (x" + MERCADO[k] + ")"]; }), "Normal"));
  const d = await perguntar("Comprar", html, "Comprar", function (f) { return {item: f.item.value, qtd: Math.max(1, Math.round(Number(f.qtd.value))), mercado: f.mercado.value}; });
  if (!d || !EQUIPAMENTOS[d.item] || !Number.isFinite(d.qtd)) return;
  const e = EQUIPAMENTOS[d.item];
  const custo = e.preco * d.qtd * MERCADO[d.mercado];
  const tem = totalCobre(s.dinheiro);
  const speaker = ChatMessage.getSpeaker({actor: actor});
  if (custo > tem) { ui.notifications.warn("Dinheiro insuficiente: custa " + textoMoedas(aMoedas(custo)) + " e você tem " + textoMoedas(aMoedas(tem)) + "."); return; }
  const resto = aMoedas(tem - custo);
  const linha = "- " + d.qtd + "× " + d.item + (e.conteudo ? " (" + e.conteudo + ")" : "");
  await actor.update({"system.dinheiro.mo": resto.mo, "system.dinheiro.mp": resto.mp, "system.dinheiro.mc": resto.mc, "system.pertences": (s.pertences ? s.pertences + "\n" : "") + linha});
  await ChatMessage.create({speaker: speaker, content: caixa("<b>" + actor.name + "</b> compra " + d.qtd + "× <b>" + d.item + "</b> (mercado " + d.mercado.toLowerCase() + ") por <b>" + textoMoedas(aMoedas(custo)) + "</b>. Restam " + textoMoedas(resto) + ".")});
}

// GERADOR DE TESOUROS para o Mestre (capitulo XIV): monetario pelo tipo (1 a 5) e objetos magicos pela quantidade e pelo tipo
export async function gerarTesouro() {
  const tipos = [1, 2, 3, 4, 5].map(function (t) { return [t, "Tipo " + t]; });
  const html = grade(
    '<label>Tipo do tesouro</label>' + sel("tipo", tipos, 1) +
    '<label>Tesouro monetário</label>' + sel("mon", [["sim", "Sortear moedas"], ["nao", "Não"]], "sim") +
    '<label>Quantidade de mágicos</label>' + sel("qtd", QUANTIDADES.map(function (q, i) { return [i, q]; }).concat([["nenhum", "Nenhum"]]), 2));
  const d = await perguntar("Gerar tesouro", html, "Sortear", function (f) { return {tipo: Number(f.tipo.value), mon: f.mon.value === "sim", qtd: f.qtd.value}; });
  if (!d) return;
  const linhas = ["<b>Tesouro do Tipo " + d.tipo + "</b>"];
  const rolaSinc = function (lados) { return 1 + Math.floor(Math.random() * lados); };
  if (d.mon) {
    const m = MONETARIO[d.tipo][rolaSinc(10) - 1];
    linhas.push("Moedas: <b>" + m[2] + " m.o.</b>, <b>" + m[1] + " m.p.</b> e <b>" + m[0] + " m.c.</b>");
  }
  if (d.qtd !== "nenhum") {
    const q = quantidadeMagicos(Number(d.qtd), rolaSinc);
    linhas.push("Objetos mágicos (" + QUANTIDADES[Number(d.qtd)] + "): " + (q.qtd ? "<b>" + q.qtd + "</b>" : "nenhum"));
    for (let i = 0; i < q.qtd; i++) {
      const o = gerarMagico(d.tipo, rolaSinc);
      linhas.push((i + 1) + ". <b>" + o.categoria + "</b> (1d20 " + o.dado + " + bônus " + o.bonus + " = " + o.total + "): " + o.nome);
    }
  }
  await ChatMessage.create({content: caixa(linhas.join("<br>")), whisper: ChatMessage.getWhisperRecipients ? ChatMessage.getWhisperRecipients("GM").map(function (u) { return u.id; }) : []});
}
