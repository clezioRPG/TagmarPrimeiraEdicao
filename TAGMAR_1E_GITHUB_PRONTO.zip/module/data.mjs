import { totalCreditosHistoricos } from "./validacoes.mjs";
import { ajusteDe, ARMADURAS, ESCUDOS, ELMOS, lerNumero, efDe, defesaDe, karmaDe, achaProfissao, PE_MINIMO, estagioPorPE, PONTOS_COMBATE, ARMA_INFO, GRUPOS_ARMAS, maoDaArma } from "./tabelas.mjs";
import { GRUPOS, HABILIDADES, PONTOS_GRUPO, totalHabilidade } from "./dados.mjs";
import { listasDoPersonagem, custoDaMagia, pontosMagiaTotal } from "./magias.mjs";
import { totalCobre, pontosVestes, PONTOS_ARMAS, PONTOS_EQUIP, faixaDeCarga } from "./equipamentos.mjs";

const f = foundry.data.fields;

export class PersonagemData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const num = (initial = 0, extra = {}) => new f.NumberField({required: true, nullable: false, integer: true, initial: initial, ...extra});
    const txt = (initial = "") => new f.StringField({required: true, blank: true, initial: initial});
    const car = () => new f.SchemaField({inicial: num(10), racial: num(0)});
    const par = () => new f.SchemaField({value: num(0), max: num(0)});
    return {
      raca: txt(), profissao: txt(), estagio: num(1, {min: 1}), idade: txt(), altura: txt(), peso: txt(),
      classeSocial: txt(), deus: txt(), pe: num(0), ordem: txt(),
      dinheiro: new f.SchemaField({mo: num(0, {min: 0}), mp: num(0, {min: 0}), mc: num(0, {min: 0})}),
      carga: new f.SchemaField({armas: txt("leve"), equip: txt("leve")}),
      caracteristicas: new f.SchemaField({
        intelecto: car(), aura: car(), carisma: car(), forca: car(), fisico: car(), agilidade: car()
      }),
      ef: par(), eh: par(), karma: new f.SchemaField({value: num(0)}),
      absorcao: new f.SchemaField({
        armadura: txt("Nenhuma"), escudo: txt("Nenhum"), elmo: txt("Nenhum"),
        restante: new f.NumberField({required: true, nullable: true, integer: true, initial: null})
      }),
      defesaExtra: num(0),
      habilidades: new f.ArrayField(new f.SchemaField({nome: txt("Ações Furtivas"), nivel: num(1)})),
      gruposArmas: new f.SchemaField(Object.fromEntries(Object.keys(GRUPOS_ARMAS).map(g => [g, num(0, {min: 0})]))),
      armas: new f.ArrayField(new f.SchemaField({nome: txt("Espada"), grupo: txt(), alcance: txt(), nivel: num(0)})),
      magias: new f.ArrayField(new f.SchemaField({nome: txt(), nivel: num(0)})),
      // Créditos efetivamente recebidos por estágio. Vazio = personagem legado, sem histórico.
      historicoPontosMagia: new f.ArrayField(num(0, {min: 0})),
      // Créditos de habilidades efetivamente recebidos por estágio, por grupo.
      historicoPontosHabilidades: new f.ArrayField(new f.SchemaField({
        subterfugio: num(0, {min: 0}), manobra: num(0, {min: 0}),
        influencia: num(0, {min: 0}), profissional: num(0, {min: 0}), geral: num(0, {min: 0})
      })),
      pertences: txt()
    };
  }

  // versao 0.2.x guardava "total"; passa a ser "nivel"
  static migrateData(source) {
    if (source && Array.isArray(source.habilidades)) {
      for (const h of source.habilidades) {
        if (h && h.nivel === undefined && h.total !== undefined) h.nivel = h.total;
      }
    }
    return super.migrateData(source);
  }

  prepareDerivedData() {
    for (const c of Object.values(this.caracteristicas)) {
      c.final = c.inicial + c.racial;
      c.ajuste = ajusteDe(c.final);
    }
    this.absorcaoTotal = (ARMADURAS[this.absorcao.armadura] ?? 0) + (ESCUDOS[this.absorcao.escudo] ?? 0) + (ELMOS[this.absorcao.elmo] ?? 0);
    this.absorcaoAtual = this.absorcao.restante === null ? this.absorcaoTotal : this.absorcao.restante;

    // valores calculados pelas tabelas do livro
    const car = this.caracteristicas;
    const peso = lerNumero(this.peso);
    const altura = lerNumero(this.altura);
    const alturaCm = altura === null ? null : (altura < 3 ? altura * 100 : altura);
    this.efTabela = efDe(car.forca.final + car.fisico.final, peso);
    this.velocidadeBase = alturaCm === null ? null : Math.ceil(alturaCm / 10) + car.fisico.ajuste;
    const def = defesaDe(this.absorcao.armadura, car.agilidade.final, this.absorcao.escudo);
    this.defesa = def.consciente + this.defesaExtra;
    this.defesaInconsciente = def.inconsciente + this.defesaExtra;
    this.resistenciaFisica = this.estagio + car.fisico.ajuste;
    this.resistenciaMagia = this.estagio + car.aura.ajuste;
    this.karmaMax = karmaDe(car.aura.final, this.estagio);

    // habilidades: total = nivel + ajuste; pontos gastos (custo x nivel) contra os da profissao (pontos por estagio x estagio)
    const prof = achaProfissao(this.profissao);
    const pts = prof ? PONTOS_GRUPO[prof] : null;
    const resumo = {};
    const historicoHab = Array.from(this.historicoPontosHabilidades ?? []);
    const habCompleto = historicoHab.length >= this.estagio;
    for (const g of Object.keys(GRUPOS)) {
      const totalHistorico = habCompleto ? totalCreditosHistoricos(historicoHab, this.estagio, g) : null;
      const creditos = totalHistorico !== null ? totalHistorico : (pts ? pts[g] * this.estagio : null);
      resumo[g] = {nome: GRUPOS[g], gastos: 0, total: creditos};
    }
    for (const h of this.habilidades) {
      h.total = totalHabilidade(car, h);
      const d = HABILIDADES[h.nome];
      if (d) resumo[d.grupo].gastos += d.custo * h.nivel;
    }
    this.pontosHab = Object.values(resumo);

    // magias: custo por nivel na lista da profissao/ordem; pontos gastos x pontos de magia (Intelecto atual em todos os estagios)
    const listas = listasDoPersonagem(prof, this.ordem);
    let gastosMag = 0;
    for (const m of this.magias) {
      m.custo = custoDaMagia(m.nome, listas);
      if (m.custo !== null) gastosMag += m.custo * m.nivel;
    }
    const historico = Array.from(this.historicoPontosMagia ?? []);
    const historicoCompleto = historico.length >= this.estagio;
    const totalHistoricoMagia = historicoCompleto ? totalCreditosHistoricos(historico, this.estagio) : null;
    const totalMagia = totalHistoricoMagia !== null ? totalHistoricoMagia : pontosMagiaTotal(car.intelecto.final, this.estagio);
    this.pontosMagia = {
      gastos: gastosMag, disponiveis: listas.length ? totalMagia : null,
      origem: totalHistoricoMagia !== null ? "histórico por estágio" : "estimativa com Intelecto atual",
      pendente: listas.length > 0 && totalMagia === null
    };

    // armas: grupo, uso por altura e Forca minima (tabela IV-8.1b); pontos de combate (IV-8.1a): custo do grupo x nivel (o nivel e do grupo)
    const nivelGrupo = {};
    // Niveis por grupo: personagens antigos mantem seus niveis individuais ate compra explicita.
    for (const a of this.armas) {
      const info = ARMA_INFO[a.nome];
      a.grupoCalc = info ? info.grupo : "";
      a.mao = info ? maoDaArma(a.nome, alturaCm) : null;
      a.forcaMin = info ? info.forca : null;
      a.forcaOk = info ? car.forca.final >= info.forca : true;
      if (info) {
        const comprado = this.gruposArmas[info.grupo] || 0;
        a.nivelEfetivo = Math.max(comprado, a.nivel);
        nivelGrupo[info.grupo] = Math.max(nivelGrupo[info.grupo] || 0, a.nivelEfetivo);
      }
    }
    for (const g of Object.keys(this.gruposArmas)) nivelGrupo[g] = Math.max(nivelGrupo[g] || 0, this.gruposArmas[g]);
    this.niveisGrupos = nivelGrupo;
    let gastosCombate = 0;
    for (const g of Object.keys(nivelGrupo)) gastosCombate += GRUPOS_ARMAS[g].custo * nivelGrupo[g];
    this.pontosCombate = {gastos: gastosCombate, disponiveis: prof ? PONTOS_COMBATE[prof] * this.estagio : null};

    // dinheiro e peso carregado (capitulo VI)
    this.dinheiroTotal = totalCobre(this.dinheiro);
    this.pontosVestes = pontosVestes(this.absorcao.armadura, this.absorcao.escudo);
    this.pontosCarga = this.pontosVestes + (PONTOS_ARMAS[this.carga.armas] || 0) + (PONTOS_EQUIP[this.carga.equip] || 0);
    this.faixaCarga = faixaDeCarga(car.forca.final, this.pontosCarga);

    // experiencia: estagio que os PE dao e PE minimo do proximo (tabela VII-3)
    this.estagioPE = estagioPorPE(this.pe);
    this.pePara = this.estagio < PE_MINIMO.length ? PE_MINIMO[this.estagio] : null;
  }
}


// ---------- Itens dos compendios ----------
export class HabilidadeData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      grupo: new f.StringField({required: true, blank: true, initial: "geral"}),
      descricao: new f.StringField({required: true, blank: true, initial: ""}),
      custo: new f.NumberField({required: true, nullable: false, integer: true, initial: 1}),
      caracteristica: new f.StringField({required: true, blank: true, initial: ""})
    };
  }
}
export class ArmaData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const n = (v) => new f.NumberField({required: true, nullable: false, integer: true, initial: v});
    return {danoMaximo: n(16), ajuste1: n(0), ajuste9: n(0), ajuste16: n(0), preco: n(0)};
  }
}
export class ArmaduraData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      categoria: new f.StringField({required: true, blank: false, initial: "armadura"}),
      absorcao: new f.NumberField({required: true, nullable: false, integer: true, initial: 0}),
      preco: new f.NumberField({required: true, nullable: false, integer: true, initial: 0}),
      defesaPorAgilidade: new f.ArrayField(new f.NumberField({required: true, nullable: false, integer: true, initial: 0}))
    };
  }
}
export class RacaData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const n = () => new f.NumberField({required: true, nullable: false, integer: true, initial: 0});
    return {
      intelecto: n(), aura: n(), carisma: n(), forca: n(), fisico: n(), agilidade: n(),
      profissoes: new f.StringField({required: true, blank: true, initial: ""})
    };
  }
}
export class ProfissaoData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const n = () => new f.NumberField({required: true, nullable: false, integer: true, initial: 0});
    return {
      pontos: new f.SchemaField({subterfugio: n(), manobra: n(), influencia: n(), profissional: n(), geral: n()}),
      ehInicial: new f.ArrayField(n()),
      ehEstagio: new f.ArrayField(n())
    };
  }
}


// ---------- Criaturas (capitulo XIII): valores diretos da tabela, sem calculo por tabelas de personagem ----------
export class CriaturaData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const n = (v = 0) => new f.NumberField({required: true, nullable: false, integer: true, initial: v});
    const txt = (v = "") => new f.StringField({required: true, blank: true, initial: v});
    const par = () => new f.SchemaField({value: n(0), max: n(0)});
    return {
      secao: txt(), estagio: n(1), defesa: n(1),
      ef: par(), eh: par(),
      absorcao: new f.SchemaField({total: n(0), restante: new f.NumberField({required: true, nullable: true, integer: true, initial: null})}),
      resistenciaFisica: n(1), resistenciaMagia: n(1),
      moral: new f.NumberField({required: true, nullable: true, integer: true, initial: null}),
      ataques: new f.ArrayField(new f.SchemaField({
        tipo: txt("Ataque"),
        ataque: new f.ArrayField(n(0)),
        dano: new f.ArrayField(n(0))
      })),
      notas: txt()
    };
  }

  prepareDerivedData() {
    this.absorcaoTotal = this.absorcao.total;
    this.absorcaoAtual = this.absorcao.restante === null ? this.absorcao.total : this.absorcao.restante;
  }
}

export class MagiaData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const txt = () => new f.StringField({required: true, blank: true, initial: ""});
    return {
      evocacao: txt(), alcance: txt(), duracao: txt(), descricao: txt(),
      dificuldades: new f.ArrayField(new f.NumberField({required: true, nullable: false, integer: true, initial: 1})),
      ataque: new f.ArrayField(new f.SchemaField({
        dificuldade: new f.NumberField({required: true, nullable: false, integer: true, initial: 1}),
        danoMaximo: new f.NumberField({required: true, nullable: false, integer: true, initial: 0})
      })),
      listas: new f.ArrayField(new f.SchemaField({
        lista: txt(),
        custo: new f.NumberField({required: true, nullable: false, integer: true, initial: 1})
      }))
    };
  }
}

export class EquipamentoData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      categoria: new f.StringField({required: true, blank: true, initial: ""}),
      preco: new f.NumberField({required: true, nullable: false, integer: true, initial: 0}),
      precoTxt: new f.StringField({required: true, blank: true, initial: ""}),
      conteudo: new f.StringField({required: true, blank: true, initial: ""})
    };
  }
}
