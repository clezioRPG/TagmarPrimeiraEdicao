/** Tagmar: remove efetivamente as barras nativas dos tokens (Foundry VTT 14).
 * O desenho do canvas utiliza document.displayBars, não _drawBar em v14.
 * 0 = NONE. Recursos do ator não são alterados.
 */
const SEM_BARRAS = 0;
const TIPOS = new Set(['personagem', 'npc', 'criatura']);

function ehTagmar(token) {
  return token?.actor && TIPOS.has(token.actor.type);
}

export function instalarBarrasCompactas() {
  // Todos os tokens novos, inclusive os criados por arrastar um ator à cena.
  Hooks.on('preCreateToken', (documento, dados) => {
    if (!ehTagmar(documento)) return;
    documento.updateSource({displayBars: SEM_BARRAS, bar1: {attribute: null}, bar2: {attribute: null}});
  });

  // No carregamento, o GM corrige também tokens antigos e protótipos.
  Hooks.once('ready', async () => {
    if (!game.user?.isGM || game.system?.id !== 'tagmar1e') return;
    for (const ator of game.actors.contents) {
      if (!TIPOS.has(ator.type)) continue;
      try {
        const prototipo = ator.prototypeToken;
        if (prototipo && (prototipo.displayBars !== SEM_BARRAS || prototipo.bar1?.attribute || prototipo.bar2?.attribute)) {
          await ator.update({ 'prototypeToken.displayBars': SEM_BARRAS,
            'prototypeToken.bar1.attribute': null, 'prototypeToken.bar2.attribute': null });
        }
      } catch (erro) { console.warn('Tagmar | protótipo sem barras:', ator.name, erro); }
    }
    for (const cena of game.scenes.contents) {
      const alteracoes = cena.tokens.contents.filter(t => ehTagmar(t) &&
        (t.displayBars !== SEM_BARRAS || t.bar1?.attribute || t.bar2?.attribute))
        .map(t => ({_id: t.id, displayBars: SEM_BARRAS,
          'bar1.attribute': null, 'bar2.attribute': null}));
      if (!alteracoes.length) continue;
      try { await cena.updateEmbeddedDocuments('Token', alteracoes); }
      catch (erro) { console.warn('Tagmar | tokens sem barras:', cena.name, erro); }
    }
    // Refaz o desenho da cena ativa após a sincronização dos documentos.
    canvas?.tokens?.placeables?.forEach(t => { if (ehTagmar(t.document)) t.renderFlags?.set({refreshBars: true}); });
  });
}
