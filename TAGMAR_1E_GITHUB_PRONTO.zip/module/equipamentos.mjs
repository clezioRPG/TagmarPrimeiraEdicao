// Capitulo VI (Pertences & Afins): moedas, dinheiro inicial, precos e peso carregado. Tabelas VI-3, VI-5.1a a VI-5.6 e VI-6.

// 1 moeda de ouro (m.o.) = 10 de prata (m.p.) = 100 de cobre (m.c.)
export const VALOR_MOEDA = {mo: 100, mp: 10, mc: 1};
export function precoEmCobre(txt) {
  const m = String(txt).match(/(\d+)\s*m\.\s*([opc])\./i);
  if (!m) return null;
  return Number(m[1]) * VALOR_MOEDA["m" + m[2].toLowerCase()];
}
export function aMoedas(cobre) {
  const c = Math.max(0, Math.round(cobre));
  return {mo: Math.floor(c / 100), mp: Math.floor((c % 100) / 10), mc: c % 10};
}
export function textoMoedas(m) {
  const partes = [];
  if (m.mo) partes.push(m.mo + " m.o.");
  if (m.mp) partes.push(m.mp + " m.p.");
  if (m.mc || !partes.length) partes.push(m.mc + " m.c.");
  return partes.join(" ");
}
export function totalCobre(d) { return d.mo * 100 + d.mp * 10 + d.mc; }

// Tabela VI-3: dinheiro inicial por classe social (cobre, prata, ouro)
export const DINHEIRO_INICIAL = {
  "Ex-escravos": {mc: 10, mp: 4, mo: 0}, "Ex-servos": {mc: 15, mp: 8, mo: 0}, "Livre": {mc: 20, mp: 13, mo: 0},
  "Pequeno comerciante": {mc: 30, mp: 17, mo: 0}, "Artífice": {mc: 40, mp: 21, mo: 1}, "Grande comerciante": {mc: 50, mp: 35, mo: 1},
  "Baixa nobreza": {mc: 60, mp: 40, mo: 2}, "Alta nobreza": {mc: 100, mp: 50, mo: 3}
};
export function achaClasseSocial(texto) {
  const t = String(texto || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  const mapa = [["ex-escrav", "Ex-escravos"], ["ex-serv", "Ex-servos"], ["livre", "Livre"], ["peq", "Pequeno comerciante"], ["artifice", "Artífice"],
    ["grd", "Grande comerciante"], ["grande", "Grande comerciante"], ["baixa", "Baixa nobreza"], ["alta", "Alta nobreza"]];
  for (const m of mapa) { if (t.indexOf(m[0]) === 0) return m[1]; }
  return null;
}

// Tabelas VI-5.1 a VI-5.6: [categoria, nome, preco]
const LISTA = [
  ["Armas", "Faca", "2 m.p."], ["Armas", "Punhal", "5 m.p."], ["Armas", "Cajado", "5 m.c."], ["Armas", "Machado", "1 m.o."], ["Armas", "Machado de guerra", "2 m.o."],
  ["Armas", "Gládio", "12 m.p."], ["Armas", "Espada", "2 m.o."], ["Armas", "Clava", "15 m.c."], ["Armas", "Maça", "15 m.p."], ["Armas", "Martelo de guerra", "11 m.p."],
  ["Armas", "Lança leve", "1 m.p."], ["Armas", "Lança pesada", "8 m.p."], ["Armas", "Arco simples", "1 m.o."], ["Armas", "Arco composto", "2 m.o."],
  ["Armas", "Espada de mão e meia", "3 m.o."], ["Armas", "Montante", "5 m.o."], ["Armas", "Maça de armas", "2 m.o."], ["Armas", "Mangual", "3 m.o."],
  ["Armas", "Lança de cavalaria", "5 m.o."], ["Armas", "Flecha (unidade)", "1 m.c."], ["Armas", "Flecha (dúzia)", "10 m.c."],
  ["Armaduras", "Couro leve", "2 m.p."], ["Armaduras", "Couro rígido", "8 m.p."], ["Armaduras", "Cota de malha parcial", "2 m.o."], ["Armaduras", "Cota de malha completa", "4 m.o."], ["Armaduras", "Couraça parcial", "10 m.o."],
  ["Escudos e elmos", "Escudo pequeno", "2 m.p."], ["Escudos e elmos", "Escudo grande", "15 m.p."], ["Escudos e elmos", "Elmo aberto", "2 m.p."], ["Escudos e elmos", "Elmo fechado", "5 m.p."],
  ["Animais", "Boi", "1 m.o."], ["Animais", "Cão comum", "5 m.p."], ["Animais", "Cão de raça (\"Alão\")", "1 m.o."], ["Animais", "Cavalo comum", "1 m.o."], ["Animais", "Cavalo de carga", "15 m.p."],
  ["Animais", "Cavalo de guerra leve", "3 m.o."], ["Animais", "Cavalo de guerra pesado", "7 m.o."], ["Animais", "Cavalo treinado", "2 m.o."], ["Animais", "Corvo", "2 m.p."],
  ["Animais", "Galinha", "2 m.c."], ["Animais", "Gato", "4 m.c."], ["Animais", "Vaca", "1 m.o."],
  ["Transportes", "Carroça", "12 m.p."], ["Transportes", "Canoa", "8 m.p."], ["Transportes", "Carruagem", "25 m.o."], ["Transportes", "Galera pequena", "60 m.o."], ["Transportes", "Veleiro pequeno", "2 m.o."],
  ["Residências", "Casa confortável", "8 m.o."], ["Residências", "Casa de ofício", "16 m.o."], ["Residências", "Casa grande", "30 m.o."], ["Residências", "Casa simples", "4 m.o."],
  ["Residências", "Castelo pequeno", "2000 m.o."], ["Residências", "Choupana", "16 m.p."], ["Residências", "Tenda", "8 m.p."], ["Residências", "Torreão/forte", "500 m.o."],
  ["Material profissional", "Estojo para Carpinteiros", "4 m.p."], ["Material profissional", "Estojo para Trabalhos Manuais", "13 m.c."],
  ["Material profissional", "Estojo para Trabalho em Metal", "15 m.p."], ["Material profissional", "Material completo para Trabalho em Metais (não transportável)", "4 m.o."],
  ["Miscelâneos", "Símbolo sagrado de madeira", "1 m.c."], ["Miscelâneos", "Símbolo sagrado de ferro", "1 m.p."], ["Miscelâneos", "Símbolo sagrado de prata", "8 m.p."], ["Miscelâneos", "Símbolo sagrado de ouro", "8 m.o."],
  ["Miscelâneos", "Água abençoada", "1 m.p."], ["Miscelâneos", "Caixa metálica", "5 m.p."], ["Miscelâneos", "Baú de madeira", "2 m.p."],
  ["Miscelâneos", "Hospedagem barata", "3 m.c."], ["Miscelâneos", "Hospedagem média", "1 m.p."], ["Miscelâneos", "Hospedagem cara", "3 m.p."],
  ["Miscelâneos", "Odre de vinho comum", "8 m.c."], ["Miscelâneos", "Odre de vinho bom", "1 m.o."], ["Miscelâneos", "Copo de vinho comum", "1 m.c."], ["Miscelâneos", "Copo de vinho bom", "1 m.p."],
  ["Miscelâneos", "Odre", "2 m.c."], ["Miscelâneos", "Ração para uma semana", "3 m.p."], ["Miscelâneos", "Refeição barata", "2 m.c."], ["Miscelâneos", "Refeição média", "5 m.c."], ["Miscelâneos", "Refeição cara", "2 m.p."],
  ["Miscelâneos", "Caneca", "1 m.c."], ["Miscelâneos", "Utensílios de cozinha", "5 m.c."], ["Miscelâneos", "Coleira de couro", "5 m.c."], ["Miscelâneos", "Aljava", "2 m.c."],
  ["Miscelâneos", "Capa", "2 m.c."], ["Miscelâneos", "Manto com capuz", "3 m.c."], ["Miscelâneos", "Cinto", "2 m.c."], ["Miscelâneos", "Par de luvas", "5 m.c."], ["Miscelâneos", "Par de sandálias", "1 m.c."],
  ["Miscelâneos", "Par de botas", "6 m.c."], ["Miscelâneos", "Roupa comum", "5 m.c."], ["Miscelâneos", "Roupa tingida", "6 m.p."], ["Miscelâneos", "10 tochas", "1 m.c."], ["Miscelâneos", "Lanterna", "3 m.p."],
  ["Miscelâneos", "Óleo de lanterna", "12 m.c."], ["Miscelâneos", "Pederneiras", "5 m.c."], ["Miscelâneos", "20 metros de corda", "9 m.c."], ["Miscelâneos", "Gancho", "1 m.p."],
  ["Miscelâneos", "10 pitons para alpinismo", "9 m.c."], ["Miscelâneos", "Mochila de couro", "1 m.c."], ["Miscelâneos", "Saco pequeno", "2 m.c."], ["Miscelâneos", "Saco grande", "3 m.c."],
  ["Miscelâneos", "Pena e tinta", "1 m.p."], ["Miscelâneos", "Pergaminho", "1 m.p."], ["Miscelâneos", "Fechadura simples", "6 m.c."], ["Miscelâneos", "Fechadura normal", "1 m.p."], ["Miscelâneos", "Fechadura complexa", "5 m.p."]
];
// Tabela VI-5.7: pacotes para compras rapidas (itens da lista acima)
export const PACOTES = {
  "Pacote Barato": {preco: "2 m.p. e 3 m.c.", itens: ["Manto com capuz", "Par de botas", "Roupa comum", "10 tochas", "Pederneiras", "20 metros de corda", "Saco grande", "Odre"]},
  "Pacote Médio": {preco: "6 m.p. e 8 m.c.", itens: ["Manto com capuz", "Par de botas", "Par de luvas", "Roupa comum", "10 tochas", "Pederneiras", "20 metros de corda", "Gancho", "Mochila de couro", "Saco pequeno (2)", "Odre", "Símbolo sagrado de ferro"]},
  "Pacote Caro": {preco: "2 m.o. e 3 m.p.", itens: ["Água abençoada", "Manto com capuz", "Par de botas", "Par de luvas", "Roupa tingida", "Lanterna", "Óleo de lanterna", "Pederneiras", "Símbolo sagrado de ferro", "40 metros de corda", "Gancho", "Mochila de couro", "Saco pequeno (2)", "Pergaminho", "Pena e tinta", "Odre"]}
};
export const EQUIPAMENTOS = {};
for (const l of LISTA) EQUIPAMENTOS[l[1]] = {categoria: l[0], preco: precoEmCobre(l[2]), precoTxt: l[2]};
for (const n of Object.keys(PACOTES)) {
  const p = PACOTES[n];
  const m = p.preco.match(/(\d+) m\.(\w)\. e (\d+) m\.(\w)\./);
  EQUIPAMENTOS[n] = {categoria: "Pacotes", preco: precoEmCobre(m[1] + " m." + m[2] + ".") + precoEmCobre(m[3] + " m." + m[4] + "."), precoTxt: p.preco, conteudo: p.itens.join(", ")};
}
// preco das armas pelo nome da tabela de ataque (a espada de mao e meia vale para as duas formas)
export function precoDaArma(nome) {
  const base = nome.replace(/ \((uma mão|duas mãos)\)$/, "");
  return EQUIPAMENTOS[base] ? EQUIPAMENTOS[base].preco : null;
}
// Tabela VI-8 (item 8): variacao de precos pelo estado do mercado
export const MERCADO = {"Normal": 1, "Difícil": 2, "Absurda": 5};

// Peso carregado (item 6): pontos de vestes, armas e equipamento, e Tabela VI-6
export const PONTOS_ARMAS = {leve: 0, media: 1, pesada: 2};
export const PONTOS_EQUIP = {leve: 0, medio: 1, pesado: 3, absurdo: 6};
export function pontosVestes(armadura, escudo) {
  if (armadura === "Cota de malha completa" || armadura === "Couraça parcial") return 4;
  if (armadura === "Couro rígido" || armadura === "Cota de malha parcial") return 2;
  if (armadura === "Couro leve" && escudo && escudo !== "Nenhum") return 2;
  if (escudo && escudo !== "Nenhum") return 2;
  return 0;
}
const CARGA = {   // linhas por Forca (2-6, 7-8, 9-12, 13-16, 17-20, 21+), colunas de 1 a 12 pontos
  0: ["Po", "Me", "Me", "Mu", "Mu", "Ab", "Ab", "Im", "Im", "Im", "Im", "Im"],
  1: ["Po", "Po", "Me", "Me", "Me", "Mu", "Mu", "Ab", "Ab", "Ab", "Im", "Im"],
  2: ["Po", "Po", "Po", "Me", "Me", "Me", "Mu", "Mu", "Mu", "Ab", "Ab", "Im"],
  3: ["Po", "Po", "Po", "Po", "Me", "Me", "Me", "Mu", "Mu", "Mu", "Ab", "Ab"],
  4: ["Po", "Po", "Po", "Po", "Me", "Me", "Me", "Me", "Mu", "Mu", "Mu", "Ab"],
  5: ["Po", "Po", "Po", "Po", "Po", "Me", "Me", "Me", "Me", "Mu", "Mu", "Ab"]
};
export const FAIXAS_CARGA = {Po: "Pouco carregado", Me: "Medianamente carregado", Mu: "Muito carregado", Ab: "Absurdamente carregado", Im: "Impossível de se carregar"};
export function faixaDeCarga(forca, pontos) {
  if (pontos <= 0) return "Po";
  const linha = forca <= 6 ? 0 : (forca <= 8 ? 1 : (forca <= 12 ? 2 : (forca <= 16 ? 3 : (forca <= 20 ? 4 : 5))));
  return CARGA[linha][Math.min(12, pontos) - 1];
}
