import { aplicarDano } from "./rolagens.mjs";

// Janela persistente, exclusiva do Mestre. Nao altera energias sem confirmacao.
const Base = foundry.applications.api.ApplicationV2;
// Marcadores descritivos: nao alteram mecanicas de Tagmar automaticamente.
const CONDICOES = ["Caído", "Atordoado", "Imobilizado", "Inconsciente", "Envenenado", "Sangrando", "Sob efeito mágico", "Outro"];
const EVENTOS = ["createActiveEffect", "updateActiveEffect", "deleteActiveEffect", "updateCombat", "createCombat", "deleteCombat", "createCombatant", "updateCombatant", "deleteCombatant", "updateActor", "updateToken"];
function marcadores(c) {
  const lista = c.getFlag("tagmar1e", "condicoesPainel");
  return Array.isArray(lista) ? lista.filter(x => x && typeof x.nome === "string") : [];
}
// Espelha marcadores informativos em ActiveEffects nativos, sem mudanças mecânicas.
// O vínculo por id evita remover efeitos criados por outros sistemas ou pelo Mestre.
function efeitoDoMarcador(actor, id) {
  return actor?.effects?.find(e => e.getFlag("tagmar1e", "marcadorPainelId") === id);
}
async function criarEfeitoMarcador(combatente, marcador) {
  const actor = combatente.actor;
  if (!actor || !marcador.id) throw new Error("Ator ou marcador inválido para criar efeito.");
  if (efeitoDoMarcador(actor, marcador.id)) return;
  await actor.createEmbeddedDocuments("ActiveEffect", [{
    name: `Tagmar: ${marcador.nome}`,
    img: "icons/svg/aura.svg",
    disabled: false,
    changes: [],
    flags: {tagmar1e: {marcadorPainelId: marcador.id, informativo: true}}
  }]);
}
async function removerEfeitoMarcador(combatente, marcador) {
  const actor = combatente.actor;
  if (!actor) throw new Error("Ator não encontrado para remover efeito.");
  const efeito = efeitoDoMarcador(actor, marcador?.id);
  if (efeito) await actor.deleteEmbeddedDocuments("ActiveEffect", [efeito.id]);
}
function restantes(m, rodada) {
  if (!Number.isInteger(m.duracao) || m.duracao <= 0) return null;
  return Math.max(0, m.duracao - Math.max(0, (Number(rodada) || 0) - (Number(m.inicio) || 0)));
}
let painel = null;

export class TagmarPainelCombate extends Base {
  static DEFAULT_OPTIONS = {
    id: "tagmar1e-painel-combate",
    classes: ["tagmar1e", "tagmar-painel-combate-app"],
    window: { title: "Tagmar · Painel de Combate", resizable: true },
    position: { width: 590, height: 450 }
  };

  constructor(options = {}) {
    super(options);
    this._atualizar = () => { if (this.rendered) this.render(); };
    for (const evento of EVENTOS) {
      Hooks.on(evento, this._atualizar);
    }
  }

  async _renderHTML() {
    const combate = game.combat;
    const escape = v => foundry.utils.escapeHTML(String(v ?? ""));
    const numero = v => Number.isFinite(Number(v)) ? String(v) : "—";
    const participantes = Array.from(combate?.combatants ?? []).filter(c => c.actor);
    const linhas = participantes.map(c => {
      const s = c.actor.system ?? {};
      const atual = combate.combatant?.id === c.id;
      const etiquetas = marcadores(c).map((m, i) => {
        const falta = restantes(m, combate?.round);
        return `<span class="tagmar-condicao ${falta === 0 ? "tagmar-condicao-expirada" : ""}">${escape(m.nome)}${falta === null ? "" : ` (${falta === 0 ? "expirou" : `${falta} rod.`})`} <button type="button" data-action="remover-condicao" data-id="${escape(c.id)}" data-index="${i}" title="Remover marcador">×</button></span>`;
      }).join(" ");
      return `<tr class="${atual ? "tagmar-turno-atual" : ""}"><td>${escape(c.name || c.actor.name)}${atual ? " <strong>◀</strong>" : ""}</td><td>${numero(s.defesa)}</td><td>${numero(s.eh?.value)}</td><td>${numero(s.ef?.value)}</td><td>${numero(s.absorcaoAtual)}</td><td><button type="button" data-action="ficha" data-id="${escape(c.id)}">Ficha</button> <button type="button" data-action="dano" data-id="${escape(c.id)}">Dano</button></td></tr><tr class="tagmar-condicoes-linha"><td colspan="6"><strong>Condições:</strong> ${etiquetas || "Nenhuma"} <span class="tagmar-condicoes-editor"><select data-condicao="${escape(c.id)}" aria-label="Condição">${CONDICOES.map(nome => `<option value="${escape(nome)}">${escape(nome)}</option>`).join("")}</select><input type="number" min="0" max="999" step="1" value="0" data-duracao="${escape(c.id)}" title="Duração em rodadas; zero = indefinida" aria-label="Rodadas"/><button type="button" data-action="adicionar-condicao" data-id="${escape(c.id)}">Adicionar</button></span></td></tr>`;
    }).join("");
    const mensagem = !combate ? "Abra um combate no rastreador de encontros." : !participantes.length ? "O combate não possui participantes com ficha." : "";
    const root = document.createElement("section");
    root.className = "tagmar-painel-combate";
    root.innerHTML = `<header class="tagmar-painel-cabecalho"><div><strong>${escape(combate?.name || "Sem combate ativo")}</strong> · Rodada ${numero(combate?.round)}</div><button type="button" data-action="atualizar">Atualizar</button></header>${mensagem ? `<p>${escape(mensagem)}</p>` : `<div class="tagmar-painel-tabela"><table><thead><tr><th>Participante</th><th>Defesa</th><th>EH</th><th>EF</th><th>Abs.</th><th>Ações</th></tr></thead><tbody>${linhas}</tbody></table></div>`}<p class="tagmar-painel-aviso">Condições são espelhadas como Efeitos Ativos informativos (sem modificadores). Duração 0 = indefinida. Marcadores expirados permanecem visíveis até remoção manual. Dano exige confirmação.</p>`;
    return root;
  }

  _replaceHTML(result, content) {
    content.replaceWith(result);
    this._vincularAcoes(result);
  }

  _insertHTML(result, content) {
    content.append(result);
    this._vincularAcoes(result);
  }

  _vincularAcoes(root) {
    root.addEventListener("click", async event => {
      const botao = event.target.closest("button[data-action]");
      if (!botao) return;
      const acao = botao.dataset.action;
      if (acao === "atualizar") return this.render();
      if (!game.user?.isGM) return ui.notifications.warn("Somente o Mestre pode alterar o combate pelo Painel Tagmar.");
      const combatente = game.combat?.combatants?.get(botao.dataset.id);
      if (!combatente?.actor) return ui.notifications.warn("Participante não encontrado no combate ativo.");
      try {
        if (acao === "adicionar-condicao") {
          const nome = root.querySelector(`select[data-condicao="${CSS.escape(combatente.id)}"]`)?.value;
          const duracao = Number(root.querySelector(`input[data-duracao="${CSS.escape(combatente.id)}"]`)?.value);
          if (!CONDICOES.includes(nome) || !Number.isInteger(duracao) || duracao < 0 || duracao > 999) return ui.notifications.warn("Informe uma condição e uma duração válida (0 a 999).");
          const lista = marcadores(combatente);
          const marcador = {id: foundry.utils.randomID(), nome, duracao, inicio: Number(game.combat?.round) || 0};
          lista.push(marcador);
          await combatente.setFlag("tagmar1e", "condicoesPainel", lista);
          try {
            await criarEfeitoMarcador(combatente, marcador);
          } catch (erro) {
            try { await combatente.setFlag("tagmar1e", "condicoesPainel", lista.filter(m => m.id !== marcador.id)); }
            catch (reversao) { console.error("Tagmar | Falha ao reverter condição após erro de efeito", reversao); }
            throw erro;
          }
          return this.render();
        }
        if (acao === "remover-condicao") {
          const indice = Number(botao.dataset.index);
          const lista = marcadores(combatente);
          if (!Number.isInteger(indice) || indice < 0 || indice >= lista.length) return;
          const [removido] = lista.splice(indice, 1);
          await removerEfeitoMarcador(combatente, removido);
          await combatente.setFlag("tagmar1e", "condicoesPainel", lista);
          return this.render();
        }
        if (acao === "ficha") return combatente.actor.sheet?.render(true);
        if (acao === "dano") return await aplicarDano(combatente.actor);
      } catch (erro) {
        console.error("Tagmar | Erro no painel de combate", erro);
        ui.notifications.error("Falha na ação do painel. Consulte o console F12.");
      }
    });
  }

  async close(options) {
    for (const evento of EVENTOS) Hooks.off(evento, this._atualizar);
    if (painel === this) painel = null;
    return super.close(options);
  }
}

export function abrirPainelCombate() {
  if (!game.user?.isGM) return ui.notifications.warn("O painel de combate é exclusivo do Mestre.");
  if (!painel) painel = new TagmarPainelCombate();
  return painel.render(true);
}

// Atalho integrado ao rastreador, sem substituir os controles nativos.
export function instalarAtalhoPainelCombate() {
  Hooks.on("renderCombatTracker", (_app, elemento) => {
    if (!game.user?.isGM) return;
    const raiz = elemento instanceof HTMLElement ? elemento : elemento?.[0];
    if (!raiz || raiz.querySelector("[data-tagmar-painel]") ) return;
    const botao = document.createElement("button");
    botao.type = "button";
    botao.dataset.tagmarPainel = "";
    botao.className = "tagmar-atalho-painel";
    botao.textContent = "Painel Tagmar";
    botao.title = "Abrir o painel de combate Tagmar";
    botao.addEventListener("click", () => abrirPainelCombate());
    (raiz.querySelector(".combat-tracker-header") || raiz.querySelector("header") || raiz).prepend(botao);
  });
}
