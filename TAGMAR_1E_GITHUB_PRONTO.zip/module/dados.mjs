// Dados do Tagmar 1a edicao (1991) para os compendios e a ficha. Somente numeros e nomes das tabelas do livro.
import { ARMAS, ARMADURAS, ESCUDOS, ELMOS } from "./tabelas.mjs";
import { EQUIPAMENTOS, precoDaArma } from "./equipamentos.mjs";

export const GRUPOS = {subterfugio: "Subterfúgio", manobra: "Manobra", influencia: "Influência", profissional: "Profissional", geral: "Geral"};
export const CARACS = {"": "—", agi: "Agilidade", int: "Intelecto", car: "Carisma", fis: "Físico"};
export const CARAC_CHAVE = {agi: "agilidade", int: "intelecto", car: "carisma", fis: "fisico"};

// Tabela III-3.2b: grupo, custo por nivel e caracteristica que da o ajuste
export const HABILIDADES = {
  "Ações Furtivas": {grupo: "subterfugio", custo: 2, carac: "agi"},
  "Ataque de Surpresa": {grupo: "subterfugio", custo: 1, carac: ""},
  "Destrancar Fechaduras": {grupo: "subterfugio", custo: 1, carac: "agi"},
  "Disfarces": {grupo: "subterfugio", custo: 1, carac: "int"},
  "Furtar Objetos": {grupo: "subterfugio", custo: 1, carac: "agi"},
  "Manusear Armadilhas": {grupo: "subterfugio", custo: 2, carac: "int"},
  "Acrobacias": {grupo: "manobra", custo: 2, carac: "agi"},
  "Escalar Superfícies": {grupo: "manobra", custo: 2, carac: "agi"},
  "Esquiva": {grupo: "manobra", custo: 1, carac: "agi"},
  "Montar Animais": {grupo: "manobra", custo: 1, carac: "agi"},
  "Natação": {grupo: "manobra", custo: 1, carac: "fis"},
  "Canto": {grupo: "influencia", custo: 1, carac: "car"},
  "Comércio": {grupo: "influencia", custo: 2, carac: "car"},
  "Dança": {grupo: "influencia", custo: 1, carac: "agi"},
  "Liderança": {grupo: "influencia", custo: 2, carac: "car"},
  "Música Instrumental": {grupo: "influencia", custo: 1, carac: "agi"},
  "Persuasão": {grupo: "influencia", custo: 2, carac: "car"},
  "Carpintaria": {grupo: "profissional", custo: 1, carac: "agi"},
  "Medicina": {grupo: "profissional", custo: 2, carac: "int"},
  "Navegação": {grupo: "profissional", custo: 1, carac: "int"},
  "Trabalho em Metal": {grupo: "profissional", custo: 2, carac: ""},
  "Trabalhos Manuais": {grupo: "profissional", custo: 1, carac: "agi"},
  "Escrita": {grupo: "geral", custo: 3, carac: "int"},
  "Línguas": {grupo: "geral", custo: 3, carac: "int"},
  "Percepção": {grupo: "geral", custo: 2, carac: "int"},
  "Seguir Trilhas": {grupo: "geral", custo: 2, carac: "int"},
  "Treinar Animais": {grupo: "geral", custo: 1, carac: "int"}
};

// Resumos das habilidades (capitulo III, item 5), escritos com palavras proprias; o texto completo, os exemplos de dificuldade e os casos especiais estao no livro.
export const RESUMOS = {
 "Ações Furtivas": {
  "item": "5.1.1",
  "resumo": "Mover-se e esconder-se sem ser notado, usando silêncio, camuflagem e sombras. Não pode ser tentada em movimento com cota de malha completa ou couraça; ficar parado facilita. Um sucesso aumenta em 2 a dificuldade de quem tenta perceber o personagem. Luz, hora do dia e busca ativa alteram a dificuldade."
 },
 "Ataque de Surpresa": {
  "item": "5.1.2",
  "resumo": "Só vale quando há surpresa, parcial ou completa: o total nesta habilidade é somado à coluna de ataque contra o adversário. Não usa níveis de dificuldade (veja o capítulo IV)."
 },
 "Destrancar Fechaduras": {
  "item": "5.1.3",
  "resumo": "Abre fechaduras, trancas e cadeados que estejam ao alcance e em condições de abrir. Leva de 1 a 10 rodadas e faz barulho. Uma armadilha acoplada e não desarmada dispara de qualquer jeito. A dificuldade vai de Rotineiro (fechadura simples, sem pressa) a Muito Difícil (fechadura complexa sob tensão, como perto de um combate)."
 },
 "Disfarces": {
  "item": "5.1.4",
  "resumo": "Altera a aparência (roupas, cabelo, maquiagem, enchimentos) para não ser reconhecido ou para passar por outra pessoa de tipo físico compatível; o Mestre pode vetar disfarces muito diferentes do corpo real. Imitar uma pessoa específica é difícil de fazer e de manter. Só muda o visual (a voz exige Canto) e quem conhece bem a pessoa pode perceber a farsa."
 },
 "Furtar Objetos": {
  "item": "5.1.5",
  "resumo": "Tirar ou plantar pequenos objetos no corpo ou nas roupas de alguém sem ser notado. Só pode ser usada com armadura de couro rígido ou mais leve. Também serve para pegar objetos deixados em lugares acessíveis, com dificuldade menor."
 },
 "Manusear Armadilhas": {
  "item": "5.1.6",
  "resumo": "Localizar, desarmar, construir ou rearmar armadilhas. Só desarma quem a localizou. A busca é rolada pelo Mestre em segredo, uma vez por armadilha, e o jogador sempre acha que teve sucesso. Fácil para armadilhas óbvias (como as de caça), Médio para mecanismos complexos e Difícil para as intrincadas e bem camufladas."
 },
 "Acrobacias": {
  "item": "5.2.1",
  "resumo": "Saltos, equilibrismo, cambalhotas e malabarismos; muito usada por Bardos. É das habilidades mais afetadas por combate, tipo de superfície e clima. A dificuldade vai de Rotineiro (pequenos movimentos em boas condições) a Absurdo ou Impossível (combater em arame, ou vários fatores externos juntos)."
 },
 "Escalar Superfícies": {
  "item": "5.2.2",
  "resumo": "Escalar superfícies verticais ou quase, naturais ou artificiais. Não pode ser feita com cota de malha completa ou couraça; armadura mais pesada dificulta e pitons, ganchos e cordas facilitam. Cada rolamento vale 10 metros ou fração. A dificuldade depende da quantidade de pontos de apoio."
 },
 "Esquiva": {
  "item": "5.2.3",
  "resumo": "Ao anunciar a esquiva, o personagem fica totalmente na defensiva e não faz outra ação na rodada; não vale se já agiu na rodada. O total na habilidade reduz as colunas de ataque de quem o atacar. Não se esquiva de quem não se vê. Mais detalhes no capítulo IV, item 12.7."
 },
 "Montar Animais": {
  "item": "5.2.4",
  "resumo": "Manobras bruscas e controle de montarias; a base de dificuldade são os equinos, e outros animais (camelo, elefante) são mais difíceis. Sem a habilidade o personagem não faz manobras nem controla o animal em pânico, só é carregado. Tamanho do montador contra o da montaria e animal chucro ou treinado também mudam a dificuldade."
 },
 "Natação": {
  "item": "5.2.5",
  "resumo": "Sobreviver e se deslocar em águas profundas; quem não tem a habilidade não sabe nadar. Não pode ser usada com cota de malha parcial ou mais pesada, e armadura e carga aumentam a dificuldade. Cada rolamento vale 200 metros ou fração. Falhar significa risco de afogamento."
 },
 "Canto": {
  "item": "5.3.1",
  "resumo": "Cantar afinado, com ou sem acompanhamento, e imitar sons: pássaros, outras vozes e pessoas. Imitar uma voz específica exige estudo prévio; sons que pedem volume impossível (rugido de leão) não dá. Faz par com Dança e Música Instrumental. Falha simples: sem o efeito desejado; Verde: consequência séria (como rouquidão)."
 },
 "Comércio": {
  "item": "5.3.2",
  "resumo": "Fazer bons negócios e avaliar mercadorias. O jogador escolhe a dificuldade, que corresponde ao lucro que tenta obter, de Rotineiro (preço justo) a Muito Difícil (lucro de 101 a 200%, ou comprar por 1/4 do valor). Falha catastrófica (Verde): má fama na região e proibição de negociar com a mesma pessoa. Nas avaliações o Mestre rola em segredo."
 },
 "Dança": {
  "item": "5.3.3",
  "resumo": "Dominar formas de dança e aprender estilos novos com um pouco de prática. Alguns rituais exigem dança, e então a dificuldade da dança acompanha a do ritual, modificada pela prática. Falha simples: passo errado; Verde: consequências mais sérias, como uma queda."
 },
 "Liderança": {
  "item": "5.3.4",
  "resumo": "Para quem comanda: o total na habilidade é somado ao moral dos comandados, reduzindo a chance de insubordinação. O Mestre pode explicar ou manter em segredo o moral das criaturas."
 },
 "Música Instrumental": {
  "item": "5.3.5",
  "resumo": "Saber tocar um instrumento à escolha; outro instrumento é outra habilidade. Falha simples: sem o efeito desejado; Verde: dano ao instrumento ou algo parecido. Impossível tocar em combate ou perseguição."
 },
 "Persuasão": {
  "item": "5.3.6",
  "resumo": "Convencer pessoas de um ponto de vista. O jogador diz o que quer e com qual argumento, o Mestre escolhe a dificuldade, e raças diferentes aumentam a dificuldade. Também serve para contar histórias de modo convincente (Bardos). Vai de Rotineiro (óbvio) a Impossível (absurdos completos)."
 },
 "Carpintaria": {
  "item": "5.4.1",
  "resumo": "Fabricar ou reparar objetos de madeira; exige ferramentas adequadas e a dificuldade depende do trabalho e das instalações. O Mestre define o tempo e rola em segredo. Falha simples: o item sai com defeito e não serve; Verde: o item parece pronto mas quebra na primeira tensão forte (só detectável por magia). No reparo, Verde destrói o objeto."
 },
 "Medicina": {
  "item": "5.4.2",
  "resumo": "Tratar ferimentos (1 ponto de EF a cada 8 horas), curar doenças fracas e médias, estabilizar quem está com EF entre 0 e -7 e neutralizar venenos. Local, utensílios, ervas e remédios mudam a dificuldade. Verde numa estabilização mata o paciente na hora."
 },
 "Navegação": {
  "item": "5.4.3",
  "resumo": "Usar as estrelas para estimar a posição (erro de cerca de 500 km no mar) e as direções, e usar mapas para se orientar por mar ou por terra. O tempo influencia, e mapas reduzem bastante a dificuldade."
 },
 "Trabalho em Metal": {
  "item": "5.4.5",
  "resumo": "Fabricar e reparar objetos de metal. A habilidade dá só o conhecimento; é preciso ter instrumentos e material. O livro lista prazos de fabricação e reparo, e a dificuldade cresce com a complexidade (espadas e armaduras de malha completa ou placa estão entre as mais difíceis). Resolução como em Carpintaria."
 },
 "Trabalhos Manuais": {
  "item": "5.4.4",
  "resumo": "Fazer ou consertar objetos que não são de metal nem de madeira (couro, corda, tecido). A rolagem segue a de Carpintaria, inclusive o objeto com defeito em caso de falha."
 },
 "Escrita": {
  "item": "5.5.1",
  "resumo": "Ler e escrever na língua aprendida. Algumas raças, profissões e classes sociais já começam com nível 1. A dificuldade sobe com textos arcaicos, dialetos aparentados ou composições elaboradas. Falha simples: erros ou texto não entendido; Verde: sentido trocado, com consequências a critério do Mestre."
 },
 "Línguas": {
  "item": "5.5.2",
  "resumo": "Falar uma língua além da própria da raça (não dá para ler nem escrever nela). Conversas normais não exigem rolagem; a dificuldade aparece em situações estranhas, como discursos floreados ou encantamentos."
 },
 "Percepção": {
  "item": "5.5.3",
  "resumo": "Notar detalhes de uma situação: passagens secretas, compartimentos escondidos, emboscadas, objetos, mentiras. Em buscas específicas o jogador precisa dizer o que procura. O Mestre escolhe a dificuldade de acordo com a situação e a decisão é final; o livro não traz exemplos."
 },
 "Seguir Trilhas": {
  "item": "5.5.4",
  "resumo": "Seguir rastros de qualquer criatura e, a critério do Mestre, tirar mais informações da trilha com novo rolamento (só se achou a trilha). A dificuldade depende da idade da trilha (de Rotineiro, com menos de 2 horas, até Impossível, com mais de 10 dias), do clima, do terreno e do número de seres."
 },
 "Treinar Animais": {
  "item": "5.5.5",
  "resumo": "Treinar animais: cada ponto de inteligência do animal permite 3 truques, e cada truque leva 4 semanas. A dificuldade depende de o animal ter sido criado em cativeiro ou capturado adulto e de ser herbívoro, onívoro ou carnívoro. Falha simples permite nova tentativa com +2; Verde: o animal nunca aprende aquele truque."
 }
};

// Revisão detalhada de habilidades — capítulo III, páginas impressas 36–37 (1991).
// As faixas abaixo são descrições de dificuldade, não novos modificadores mecânicos.
export const DETALHES_HABILIDADES_1991 = {
 "Carpintaria": {"pagina": 34, "regras": "Fabricar e reparar objetos de madeira requer ferramentas, instalações e tempo definido pelo Mestre. Para fabricação, o Mestre rola secretamente: sucesso conclui a peça; falha normal produz peça defeituosa e inutilizável; Verde produz peça aparentemente pronta que quebra na primeira grande tensão, defeito detectável somente por magia. Em reparos, sucesso conserta; falha normal mantém o defeito e permite nova tentativa; Verde destrói o objeto. As dificuldades variam conforme tarefa e equipamentos.", "dificuldades": {"Rotineiro": "Pequenos consertos, como recolocar pontas de lança ou flecha, calafetar pequeno barco e consertar portas ou móveis.", "Fácil": "Fabricar cajados, setas ou lanças com ferramentas e instalações; fazer reparos mais complexos.", "Médio": "Efetuar reparos usando apenas ferramentas portáteis.", "Difícil": "Efetuar reparos complexos com ferramentas portáteis; construir objetos sem instalações fixas.", "Muito Difícil": "Construir um barco.", "Absurdo": "Executar serviços sem equipamento mínimo, como pregos e martelos."}},
 "Medicina": {"pagina": 35, "regras": "A Medicina permite recuperar um ponto de Energia Física após oito horas de tratamento, curar doenças fracas ou médias em alguns dias conforme a força e o período de cura determinados pelo Mestre, estabilizar pacientes com EF entre 0 e -7 e tentar neutralizar venenos. Condições de atendimento, utensílios, ervas e remédios modificam a dificuldade. Uma falha Verde durante a estabilização mata o paciente imediatamente.", "dificuldades": {"Rotineiro": "Curar 1 ponto de EF após 8 horas de tratamento.", "Fácil": "Curar doenças fracas; estabilizar paciente em condições favoráveis.", "Médio": "Neutralizar veneno na hora em que é usado na vítima; estabilizar paciente em condições desfavoráveis.", "Difícil": "Curar doenças médias.", "Muito Difícil": "Neutralizar venenos potentes que já estejam com efeitos avançados sobre a vítima."}},
 "Navegação": {"pagina": 35, "regras": "Usa a posição das estrelas para determinar direções ou a posição aproximada do viajante; no mar, o erro de posição é de cerca de 500 quilômetros. Pode combinar observação astronômica com mapas para orientar viagens marítimas e terrestres. Condições meteorológicas afetam o resultado; mapas podem reduzir substancialmente a dificuldade.", "dificuldades": {"Rotineiro": "Determinar direções.", "Médio": "Determinar posição.", "Difícil": "Ler mapa de região desconhecida sem marcos geográficos óbvios.", "Muito Difícil": "Ler mapa em língua desconhecida de região desconhecida."}},
 "Trabalhos Manuais": {"pagina": 35, "regras": "Fabrica e repara objetos que não sejam de madeira nem metal, como peças de couro, cordas e tecidos. A resolução segue Carpintaria, inclusive o risco de utensílio aparentemente pronto que quebra após uma falha Verde. Os prazos abaixo são os indicados pelo livro para os trabalhos exemplificados.", "dificuldades": {"Rotineiro": "Empenagem de flechas, capas de pano ou couro, punhos de espadas e outros objetos simples, ou reparos em vestuário; prazo de 4 horas.", "Fácil": "Armadura de couro, vestuário, reparo de sapatos, confecção ou preparação de cordas; reparo de armadura de couro leva 8 horas e fabricação, 24 horas.", "Médio": "Armadura de couro rígido, sapatos, botas e vestuário de couro; prazo de 72 horas.", "Difícil": "Cobertura de selas em couro."}},
 "Trabalho em Metal": {"pagina": 35, "regras": "Permite fabricar e reparar objetos de metal. A habilidade fornece conhecimento, mas não materiais, instrumentos nem instalações; o personagem precisa obtê-los. O Mestre estima prazos de objetos não listados tomando os exemplos como base. Para fabricar ou reparar, usa-se o procedimento de Carpintaria, inclusive suas consequências de falha.", "dificuldades": {"Rotineiro": "Reparar avarias simples com ferramentas adequadas, em armas e armaduras não quebradas após combate; prazo de 4 horas.", "Médio": "Fabricar martelo, maça ou martelo de armas, ou armadura de cota de malha parcial; reparar dano grave em escudo ou armadura que absorveu todo o dano possível; reparos em 24 horas e fabricação em 3 dias.", "Difícil": "Fabricar espadas e adagas ou armaduras de cota de malha completa ou de placa; fazer reparos simples sem ferramentas adequadas; reparos em 8 horas e fabricação em uma semana.", "Absurdo": "Reparar objeto sem dispor de nenhuma ferramenta adequada."}},
 "Escrita": {pagina:36, regras:"Permite ler e escrever na língua aprendida, incluindo cartas, avisos e composições. Algumas raças, profissões e classes sociais começam com nível 1; textos arcaicos, dialetos e composições complexas elevam a dificuldade. Uma falha simples não produz o efeito desejado; resultado Verde pode inverter o sentido e causar consequências.", dificuldades:{"Rotineiro":"Interpretar poema simples ou escrever carta estilisticamente sofisticada.","Fácil":"Ler texto arcaico na própria língua ou redigir carta em linguagem arcaica.","Médio":"Ler texto simples em dialeto aparentado.","Difícil":"Ler texto complexo em dialeto aparentado.","Muito Difícil":"Escrever bom poema ou ler texto antigo em outro dialeto.","Absurdo":"Ler dialeto remotamente aparentado com poucas palavras conhecidas.","Impossível":"Ler ou escrever em língua totalmente desconhecida."}},
 "Línguas": {pagina:36, regras:"Permite falar outra língua, mas não ler nem escrever nela. Conversas comuns não requerem teste; situações incomuns, discursos, dialetos e encantamentos exigem resolução.", dificuldades:{"Rotineiro":"Compreender discurso rápido ou agitado e linguagem carregada de gírias.","Fácil":"Entender discurso floreado ou ritualístico, como encantamento simples.","Médio":"Entender encantamento complexo ou discursar de forma floreada sem erros.","Difícil":"Entender dialeto aparentado ou linguagem arcaica.","Muito Difícil":"Falar dialeto aparentado sem errar.","Absurdo":"Entender dialeto com poucas palavras conhecidas."}},
 "Percepção": {pagina:36, regras:"Perceber detalhes, passagens secretas, compartimentos escondidos, emboscadas, objetos e discrepâncias em relatos. Em busca específica, o jogador declara o que procura. O Mestre determina a dificuldade final; o livro não fixa exemplos de dificuldade para esta habilidade.", dificuldades:{}},
 "Seguir Trilhas": {pagina:37, regras:"Segue rastros de criaturas; depois de encontrar a trilha, o Mestre pode autorizar outro teste para informações adicionais (tipo e quantidade de seres, por exemplo). A escala pressupõe trilha não ocultada e ausência de chuva ou ventos fortes posteriores; terreno e quantidade de criaturas modificam a dificuldade.", dificuldades:{"Rotineiro":"Trilha com menos de 2 horas, não ocultada.","Fácil":"Trilha com menos de 12 horas.","Médio":"Trilha entre 12 e 48 horas.","Difícil":"Trilha entre 2 e 4 dias.","Muito Difícil":"Trilha entre 4 e 7 dias.","Absurdo":"Trilha entre 7 e 10 dias.","Impossível":"Trilha com mais de 10 dias."}},
 "Treinar Animais": {pagina:37, regras:"Cada ponto de Inteligência do animal permite aprender três truques. Cada truque exige quatro semanas de treinamento e um teste ao final. Em falha simples, pode-se tentar novamente com dificuldade aumentada em 2; resultado Verde impede definitivamente o aprendizado daquele truque. Truques podem ser esquecidos se não praticados por muito tempo.", dificuldades:{"Fácil":"Herbívoro ou onívoro criado em cativeiro.","Médio":"Carnívoro criado em cativeiro, ou herbívoro/onívoro capturado adulto.","Absurdo":"Carnívoro capturado adulto."}},
 "Ações Furtivas": {"pagina": 29, "regras": "Permite passar despercebido por silêncio, camuflagem e sombras, parado ou em movimento. Não pode ser utilizada em movimento com cota de malha completa ou couraça; ocultar-se imóvel reduz a dificuldade. Sucesso eleva em dois graus a dificuldade de Percepção de quem procura notar o personagem. Iluminação, horário e busca deliberada modificam o grau.", "dificuldades": {"Rotineiro": "Mata muito fechada, como florestas equatoriais e tropicais, ou interiores repletos de meandros e mobília grande.", "Fácil": "Mata fechada de floresta temperada, becos e vielas sinuosos, casas grandes.", "Médio": "Vegetação rasteira, ruas ou praças vazias, cavernas naturais.", "Difícil": "Desertos, salões e corredores."}},
 "Ataque de Surpresa": {"pagina": 30, "regras": "Utilizável somente quando ocorre surpresa parcial ou completa. Soma-se o total de Ataque de Surpresa à coluna de ataque do personagem contra o adversário surpreendido; os detalhes da surpresa pertencem às regras de combate do capítulo IV. Não há níveis de dificuldade nesta habilidade.", "dificuldades": {}},
 "Destrancar Fechaduras": {"pagina": 30, "regras": "Abre fechaduras, trancas e cadeados acessíveis e em condições de serem abertos. O procedimento leva de uma a dez rodadas e não é silencioso. Se houver armadilha acoplada que não foi desarmada, ela dispara independentemente do sucesso ou fracasso da abertura. A habilidade não abre trancas derretidas ou inacessíveis.", "dificuldades": {"Rotineiro": "Fechadura muito simples, em calma absoluta.", "Fácil": "Fechadura normal.", "Médio": "Fechadura normal sob pressão ou com ferimentos; ou fechadura complexa ou de acesso difícil em calma.", "Difícil": "Fechadura complexa ou de difícil acesso em condições anormais, como a cela de prisão aberta pelo próprio preso.", "Muito Difícil": "Fechadura complexa ou de difícil acesso sob tensão, como perto de um combate.", "Impossível": "Fechadura sem condições de funcionamento ou sem acesso possível."}},
 "Disfarces": {"pagina": 30, "regras": "Modifica a aparência com roupas, cabelo, maquiagem e enchimentos para impedir reconhecimento ou imitar outro indivíduo. O Mestre pode proibir mudanças incompatíveis com o tipo físico. Imitar pessoa específica é mais difícil de criar e manter; a habilidade altera apenas o visual, pois imitar voz exige Canto. Conhecidos da pessoa imitada podem perceber a impostura.", "dificuldades": {"Fácil": "Disfarçar-se para não ser reconhecido.", "Médio": "Disfarçar-se como indivíduo qualquer de outra raça ou do outro sexo.", "Difícil": "Disfarçar-se como indivíduo específico da mesma raça e do mesmo sexo.", "Muito Difícil": "Disfarçar-se como indivíduo de outra raça ou do outro sexo.", "Absurdo": "Disfarçar-se como indivíduo específico de outra raça e/ou sexo.", "Impossível": "Disfarçar-se como criatura de tamanho ou forma incompatível, por exemplo um pequenino como ogro."}},
 "Furtar Objetos": {"pagina": 30, "regras": "Retira ou coloca objetos pequenos no corpo ou nas roupas de outra pessoa sem ser notado. Exige armadura de couro rígido ou mais leve. Pode também furtar objetos deixados em locais acessíveis, como móveis ou balcões; nesses casos o Mestre reduz a dificuldade conforme a situação.", "dificuldades": {"Rotineiro": "Vítima dormindo, embriagada ou em estado semelhante de inconsciência.", "Fácil": "Vítima sóbria, porém desatenta.", "Médio": "Vítima atenta, em área perigosa ou situação equivalente.", "Muito Difícil": "Vítima consciente da presença de ladrões nas redondezas.", "Absurdo": "Vítima protegendo o objeto e atenta ao risco de roubo.", "Impossível": "Vítima identificou o ladrão e suas intenções."}},
 "Manusear Armadilhas": {"pagina": 30, "regras": "Permite localizar, desarmar, construir e rearmar armadilhas. Só pode desarmar a armadilha que o próprio personagem localizou. A procura é rolada secretamente pelo Mestre, uma tentativa por armadilha, e o jogador não vê o resultado; havendo várias, faz-se teste para cada uma. Para desarmar ou tornar inoperante, o Mestre também oculta o resultado, de modo que o personagem não sabe se falhou. As dificuldades indicadas supõem condições ideais; pressão, acesso e outros fatores as alteram. Construir armadilhas complexas pode exigir dias, instalações e Carpintaria, Trabalhos Manuais ou Trabalho em Metal.", "dificuldades": {"Fácil": "Localizar, desarmar, construir ou rearmar armadilhas óbvias, como poços cobertos por folhas, laços e redes de caça.", "Médio": "Realizar as mesmas operações com armadilhas mecânicas mais complexas.", "Difícil": "Localizar, desarmar ou rearmar armadilhas intrincadas e muito bem camufladas."}},
 "Acrobacias": {"pagina": 31, "regras": "Permite saltos mortais, equilíbrio, cambalhotas e malabarismos. O combate, o tipo de superfície, o clima, o tempo e a pressão externa alteram a dificuldade. Os exemplos pressupõem condições descritas; fatores combinados podem tornar uma ação impossível.", "dificuldades": {"Rotineiro": "Pequenos movimentos acrobáticos ou equilibrismo em condições ideais.", "Fácil": "Saltos e cambalhotas complexas em condições ideais; equilíbrio em tábuas ou pranchas sem influências externas.", "Médio": "Acrobacias simples com chuva ou vento; correr sobre tábuas, pranchas e superfícies estreitas sem pressão externa.", "Difícil": "Acrobacias simples em combate; complexas sob condições climáticas; combate em superfície estreita; equilíbrio em arame ou corda.", "Muito Difícil": "Equilíbrio em arame sob condições climáticas adversas; acrobacias complexas em combate.", "Absurdo": "Combater enquanto equilibrado em arame.", "Impossível": "Acúmulo de fatores externos que inviabiliza a manobra, como lutar de espada sobre corda sujeita a ventos e executar salto mortal."}},
 "Escalar Superfícies": {"pagina": 31, "regras": "Permite escalar superfícies verticais ou quase verticais naturais ou artificiais. Não pode ser usada com cota de malha completa ou couraça. Armadura mais pesada aumenta a dificuldade; pitons, ganchos e cordas a reduzem. Cada teste cobre 10 metros ou fração da subida.", "dificuldades": {"Rotineiro": "Inúmeros pontos de apoio: barrancos ou muros com degraus e muitos defeitos.", "Fácil": "Muitos pontos de apoio: face de montanha perto do sopé ou muro com defeitos.", "Médio": "Bom número de pontos de apoio: muro externo de grande cidade.", "Difícil": "Poucos pontos de apoio, espaçados: face de montanha perto do pico ou muro de castelo.", "Muito Difícil": "Muito poucos pontos de apoio: muro feito para ser liso, como o de uma prisão.", "Absurdo": "Superfície muito lisa, como face oceânica do Pão de Açúcar.", "Impossível": "Superfície com inclinação negativa sem equipamento especial."}},
 "Esquiva": {"pagina": 31, "regras": "Ao anunciar Esquiva, o personagem assume posição inteiramente defensiva e não pode fazer qualquer outra ação na rodada (ataque, magia ou habilidade). Não pode esquivar-se se já agiu nessa rodada. O total de Esquiva diminui as colunas de ataque dos adversários que o atacarem. Não pode esquivar-se de adversário que não vê. Consultar também capítulo IV, item 12.7.", "dificuldades": {}},
 "Montar Animais": {"pagina": 32, "regras": "Executa manobras bruscas e controla montarias. As dificuldades de referência usam equinos; animais diferentes, como camelos ou elefantes, tornam as tarefas mais difíceis. Sem nível na habilidade, o personagem apenas é transportado: não executa manobras nem controla a montaria em pânico. Porte relativo de montador e animal, treinamento e temperamento alteram a dificuldade; cavalo de guerra é mais fácil de montar que cavalo normal.", "dificuldades": {"Rotineiro": "Andar a passo ou a trote; controlar o animal após susto não perigoso.", "Fácil": "Fazer cavalo saltar obstáculo de até 1 metro; mantê-lo calmo durante combate corpo a corpo; cavalgar a toda velocidade.", "Médio": "Manter montaria sob controle durante ataque de flechas, se não foi ferida.", "Difícil": "Fazer cavalo saltar obstáculo maior que 1 metro e menor que 1,5 metro; controlar montaria ferida.", "Muito Difícil": "Controlar montaria durante catástrofe natural, como terremoto ou incêndio florestal.", "Absurdo": "Saltar obstáculo maior que 1,5 metro ou de grande comprimento; controlar montaria sob ataque de predador ou animal grande."}},
 "Natação": {"pagina": 32, "regras": "Permite sobreviver e deslocar-se em águas profundas, onde não é possível apoiar os pés no fundo. Quem não possui esta habilidade não sabe nadar. Não pode ser executada usando cota de malha parcial ou armadura mais pesada. Armadura permitida e carga transportada elevam a dificuldade. Falha pode impedir manter-se à tona e ocasionar afogamento. Cada teste vale 200 metros ou fração; por exemplo, 400 metros exigem dois testes e 550 metros exigem três.", "dificuldades": {"Rotineiro": "Águas calmas: mar de pequenas ondas ou rio de corrente fraca.", "Fácil": "Águas médias: mar com ondas ou rio com corrente forte.", "Médio": "Águas agitadas.", "Difícil": "Águas bravias: mar muito agitado ou corredeiras.", "Absurdo": "Águas assassinas: mar tempestuoso ou rio excepcionalmente encachoeirado."}},
 "Canto": {"pagina": 33, "regras": "Permite cantar afinadamente, com ou sem acompanhamento, e imitar sons de animais e vozes. A imitação de pessoa específica exige estudo prévio da voz: quanto mais palavras forem reproduzidas, maior o tempo de estudo; sotaques e entonações exigem menos tempo. Sons além da capacidade vocal, como rugido de leão, não são possíveis. Falha comum não obtém o efeito desejado; falha catastrófica (Verde) pode causar rouquidão.", "dificuldades": {"Rotineiro": "Cantar música fácil; imitar o pio simples de uma coruja.", "Fácil": "Imitar canto de pássaro; cantar melodia longa ou complexa, mas já ensaiada.", "Médio": "Imitar canto complexo de rouxinol; cantar em língua desconhecida após memorizar a canção; cantar após ouvir poucas vezes; imitar frases simples de outra pessoa.", "Difícil": "Cantar com sucesso após ouvir a canção uma única vez; cantar em combate ou sob pressão; imitar frases complexas em outra voz.", "Muito Difícil": "Imitar outra voz numa conversação complexa, com estudo razoável prévio.", "Impossível": "Cantar submerso em água."}},
 "Comércio": {"pagina": 33, "regras": "Permite negociar e avaliar mercadorias. Antes de negociar, o jogador declara a dificuldade e o lucro desejado, então rola 1d20; falha impede o negócio nas condições propostas. Nova tentativa com a mesma pessoa segue a regra geral de repetição de tentativas. Falha catastrófica (Verde) prejudica a reputação na região e impede novos negócios com aquela pessoa. Para avaliação, o Mestre escolhe a dificuldade e rola secretamente; se falhar, altera o valor informado ao personagem.", "dificuldades": {"Rotineiro": "Comprar ou vender pelo preço justo e conhecido; avaliar item comum ou de produção numerosa.", "Fácil": "Comprar ou vender com pequeno lucro (10% a 20%); avaliar mercadoria mais complexa mas conhecida.", "Médio": "Comprar ou vender com lucro razoável (21% a 50%); avaliar item raro ou sob medida; reconhecer falsificação grosseira.", "Difícil": "Vender com lucro de 51% a 100% ou comprar por metade do valor; avaliar mercadoria rara e estranha; reconhecer falsificação razoável.", "Muito Difícil": "Vender com lucro de 101% a 200% ou comprar por um quarto do valor; avaliar obras de arte ou raridades; reconhecer falsificações excelentes.", "Absurdo": "Vender com lucro acima de 201%; avaliar objeto único e praticamente desconhecido.", "Impossível": "Vender a ponte ou o castelo do rei; avaliar objeto completamente fora da experiência do personagem."}},
 "Dança": {"pagina": 33, "regras": "Permite dominar formas de dança e aprender estilos novos após alguma prática. Em rituais que exigem dança, a dificuldade da execução acompanha a do ritual, ajustada pela prática. Falha comum resulta em dança sem efeito desejado, como passos errados; falha catastrófica (Verde) pode ocasionar queda ou consequência séria.", "dificuldades": {"Rotineiro": "Dançar músicas de salão.", "Fácil": "Dançar músicas folclóricas ou de salão complexas.", "Médio": "Dançar ritual ou acrobaticamente (distinto de Acrobacias); criar passos simples; aprender nova dança rapidamente após observação.", "Difícil": "Criar bailado complexo; dançar em superfície inadequada ou em combate.", "Absurdo": "Dançar enquanto perseguido.", "Impossível": "Dançar sem uso de pernas e braços."}},
 "Liderança": {"pagina": 33, "regras": "Permite impor respeito e confiança aos subordinados. O total na habilidade é somado ao moral dos comandados, reduzindo o risco de insubordinação. O Mestre decide se revela ou mantém secreto o moral dos liderados. O livro não apresenta tabela própria de dificuldades para Liderança.", "dificuldades": {}},
 "Música Instrumental": {"pagina": 34, "regras": "Representa domínio de um instrumento escolhido pelo personagem. Aprender a tocar outro instrumento exige adquirir a habilidade separadamente. A falha comum impede o efeito desejado; a falha catastrófica (Verde) pode danificar o instrumento. Em combate, perseguição ou pressão externa equivalente, tocar é impossível.", "dificuldades": {"Rotineiro": "Tocar melodia simples e bem ensaiada.", "Fácil": "Tocar melodia complexa mas bem ensaiada, ou melodia simples de ouvido.", "Médio": "Tocar melodia complexa sem muitos ensaios; improvisar peça complicada.", "Difícil": "Tocar melodia complexa de ouvido; improvisar por longo tempo e com complexidade.", "Muito Difícil": "Compor melodia complexa sem tempo de estudo.", "Impossível": "Tocar qualquer coisa em combate ou perseguição, ou sob pressão externa equivalente."}},
 "Persuasão": {"pagina": 34, "regras": "Permite convencer uma ou mais pessoas de que um ponto de vista deve ser aceito ou de que devem seguir determinado curso de ação. O jogador informa quem quer convencer, a proposta e os argumentos; o Mestre escolhe a dificuldade e então ocorre o teste. Diferença de raça entre persuasor e interlocutor aumenta a dificuldade. Também permite narrar histórias dramaticamente e com convicção, especialmente para bardos.", "dificuldades": {"Rotineiro": "Convencer alguém de fato claramente óbvio.", "Fácil": "Convencer alguém já predisposto a acreditar ou a ouvir o personagem.", "Médio": "Persuadir alguém não muito inclinado a ser convencido, mas não hostil, como numa pechincha.", "Difícil": "Persuadir alguém hostil, como policiais ou guardas desconfiados.", "Muito Difícil": "Persuadir alguém com intenções perigosas ou violentas contra o personagem, ou sair de situação muito embaraçosa.", "Absurdo": "Conseguir fugir ao ser apanhado em flagrante ou convencer alguém de algo ilógico e meio absurdo.", "Impossível": "Convencer alguém de absurdos completos e sem sentido."}}
};
export const CASOS_ESPECIAIS_HABILIDADES_1991 = "Sem nível: o Mestre pode autorizar tentativa na coluna -7, ajustada pela característica principal, salvo habilidades expressamente vedadas. Ação conjunta: usa-se o maior total de habilidade e acrescenta-se 1 por ajudante que possua nível na habilidade, se o Mestre permitir a cooperação.";

// Tabela III-3.2a: pontos por estagio que cada profissao recebe em cada grupo
export const PONTOS_GRUPO = {
  "Guerreiro":  {subterfugio: 2, manobra: 4, influencia: 2, profissional: 2, geral: 2},
  "Ladrão":     {subterfugio: 6, manobra: 4, influencia: 2, profissional: 2, geral: 2},
  "Sacerdote":  {subterfugio: 1, manobra: 2, influencia: 4, profissional: 3, geral: 2},
  "Mago":       {subterfugio: 2, manobra: 3, influencia: 2, profissional: 2, geral: 2},
  "Rastreador": {subterfugio: 2, manobra: 4, influencia: 2, profissional: 1, geral: 3},
  "Bardo":      {subterfugio: 3, manobra: 3, influencia: 5, profissional: 2, geral: 2}
};

// Tabela II-3.6 (modificadores raciais) e II-4.7 (profissoes possiveis)
const TODAS = ["Guerreiro", "Ladrão", "Sacerdote", "Mago", "Rastreador", "Bardo"];
const TRES = ["Guerreiro", "Ladrão", "Sacerdote"];
export const RACAS = {
  "Humanos":          {mod: {intelecto: 0, aura: 0, carisma: 0, forca: 0, fisico: 0, agilidade: 0},   profissoes: TODAS},
  "Pequeninos":       {mod: {intelecto: 0, aura: 0, carisma: 0, forca: -2, fisico: 1, agilidade: 2},  profissoes: TRES},
  "Anões":            {mod: {intelecto: 0, aura: 0, carisma: -1, forca: 1, fisico: 2, agilidade: 0},  profissoes: TRES},
  "Elfos Florestais": {mod: {intelecto: 1, aura: 0, carisma: 1, forca: 0, fisico: -1, agilidade: 1},  profissoes: TODAS},
  "Elfos Dourados":   {mod: {intelecto: 2, aura: 1, carisma: 1, forca: -1, fisico: -2, agilidade: 1}, profissoes: TODAS},
  "Meio-elfos":       {mod: {intelecto: 0, aura: 0, carisma: 1, forca: 0, fisico: 0, agilidade: 0},   profissoes: TODAS}
};

// acha a raca ("Anão", "anoes", "Elfo Dourado") pelo texto digitado
export function achaRaca(texto) {
  const t = String(texto || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  const radicais = {"Humanos": "human", "Pequeninos": "pequen", "Anões": "an", "Elfos Florestais": "elfo flor", "Elfos Dourados": "elfo dour", "Meio-elfos": "meio"};
  for (const r of Object.keys(RACAS)) {
    if (t.indexOf(radicais[r]) === 0) return r;
  }
  if (t.indexOf("elfos flor") === 0) return "Elfos Florestais";
  if (t.indexOf("elfos dour") === 0) return "Elfos Dourados";
  return null;
}

// ajuste da habilidade (caracteristica ligada) e total = nivel + ajuste (item 3.3.1)
export function totalHabilidade(caracs, h) {
  const d = HABILIDADES[h.nome];
  const aj = d && d.carac ? caracs[CARAC_CHAVE[d.carac]].ajuste : 0;
  return h.nivel + aj;
}

// ---------- Documentos para os compendios ----------
export function docsHabilidades() {
  return Object.keys(HABILIDADES).map(function (n) {
    const h = HABILIDADES[n];
    return {name: n, type: "habilidade", system: {grupo: h.grupo, custo: h.custo, caracteristica: h.carac,
      descricao: [
        "TAGMAR 1ª EDIÇÃO (1991) — HABILIDADE: " + n,
        "REFERÊNCIA: Capítulo III, item " + RESUMOS[n].item + ".",
        "APLICAÇÃO E RESTRIÇÕES: " + RESUMOS[n].resumo,
        "GRUPO: " + GRUPOS[h.grupo] + ". CUSTO POR NÍVEL: " + h.custo + ". CARACTERÍSTICA DE AJUSTE: " + (CARACS[h.carac] || "Nenhuma") + ".",
        ...(DETALHES_HABILIDADES_1991[n] ? [
          "DESCRIÇÃO REVISADA (1991), PÁGINA IMPRESSA " + DETALHES_HABILIDADES_1991[n].pagina + ": " + DETALHES_HABILIDADES_1991[n].regras,
          "EXEMPLOS DE DIFICULDADE DO LIVRO: " + Object.entries(DETALHES_HABILIDADES_1991[n].dificuldades).map(([grau, exemplo]) => grau + " — " + exemplo).join(" | ")
        ] : []),
        "CASOS ESPECIAIS: " + CASOS_ESPECIAIS_HABILIDADES_1991,
        "RESOLUÇÃO: utilize a Tabela de Resolução do capítulo III; para habilidades ainda não revisadas, o resumo não substitui o texto integral do livro de 1991."
      ].join("\n\n")}};
  });
}
export function docsArmas() {
  return Object.keys(ARMAS).map(function (n) {
    const a = ARMAS[n];
    return {name: n, type: "arma", system: {danoMaximo: a[3], ajuste1: a[0], ajuste9: a[1], ajuste16: a[2], preco: precoDaArma(n) || 0}};
  });
}
const DEFESA_ARMADURA = {
  "Couro leve": [2, 3, 4, 5, 6, 7, 8, 8],
  "Couro rígido": [9, 10, 11, 12, 13, 14, 15, 15],
  "Cota de malha parcial": [10, 11, 12, 13, 14, 15, 15, 15],
  "Cota de malha completa": [16, 17, 18, 19, 20, 20, 21, 21],
  "Couraça parcial": [17, 18, 19, 20, 20, 21, 21, 21]
};
export function docsArmaduras() {
  const docs = [];
  for (const n of Object.keys(ARMADURAS)) {
    if (n === "Nenhuma") continue;
    docs.push({name: n, type: "armadura", system: {categoria: "armadura", absorcao: ARMADURAS[n], preco: EQUIPAMENTOS[n].preco, defesaPorAgilidade: DEFESA_ARMADURA[n]}});
  }
  for (const n of Object.keys(ESCUDOS)) {
    if (n === "Nenhum") continue;
    docs.push({name: n, type: "armadura", system: {categoria: "escudo", absorcao: ESCUDOS[n], preco: EQUIPAMENTOS[n].preco, defesaPorAgilidade: []}});
  }
  for (const n of Object.keys(ELMOS)) {
    if (n === "Nenhum") continue;
    docs.push({name: n, type: "armadura", system: {categoria: "elmo", absorcao: ELMOS[n], preco: EQUIPAMENTOS[n].preco, defesaPorAgilidade: []}});
  }
  return docs;
}
export function docsRacas() {
  return Object.keys(RACAS).map(function (n) {
    const r = RACAS[n];
    return {name: n, type: "raca", system: {intelecto: r.mod.intelecto, aura: r.mod.aura, carisma: r.mod.carisma, forca: r.mod.forca, fisico: r.mod.fisico, agilidade: r.mod.agilidade, profissoes: r.profissoes.join(", ")}};
  });
}
export function docsProfissoes(ehInicial, ehEstagio) {
  return Object.keys(PONTOS_GRUPO).map(function (n) {
    return {name: n, type: "profissao", system: {pontos: PONTOS_GRUPO[n], ehInicial: ehInicial[n], ehEstagio: ehEstagio[n]}};
  });
}

// equipamentos que nao sao armas, armaduras, escudos nem elmos (esses ja estao nos seus compendios)
export function docsEquipamentos() {
  const fora = ["Armas", "Armaduras", "Escudos e elmos"];
  return Object.keys(EQUIPAMENTOS).filter(function (n) { return fora.indexOf(EQUIPAMENTOS[n].categoria) < 0 || EQUIPAMENTOS[n].categoria === "Armas" && n.indexOf("Flecha") === 0; }).map(function (n) {
    const e = EQUIPAMENTOS[n];
    return {name: n, type: "equipamento", system: {categoria: e.categoria, preco: e.preco, precoTxt: e.precoTxt, conteudo: e.conteudo || ""}};
  });
}
