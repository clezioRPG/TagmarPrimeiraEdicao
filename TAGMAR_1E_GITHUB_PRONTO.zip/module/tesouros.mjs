// Capitulo XIV (Tesouros): tabelas XIV-2, 3a, 3b, 3.1, 3.2, 3.3a-e, 3.4a-e, 3.5a-b e 3.6. Poderes e magias de cada item: ver itens 3.7 e 3.8 do livro.
const R = function (a, b, t) { return [a, b, t]; };
export function acha(tabela, n) {
  for (const l of tabela) { if (n >= l[0] && n <= l[1]) return l[2]; }
  return tabela[tabela.length - 1][2];
}

// Tabela XIV-2: tesouro monetario (1d10; moedas de cobre, prata e ouro) por tipo de tesouro (1 a 5)
export const MONETARIO = {
  1: [[50, 5, 0], [50, 5, 1], [100, 10, 1], [100, 10, 2], [150, 15, 2], [150, 15, 3], [200, 20, 3], [200, 20, 4], [250, 25, 4], [250, 25, 5]],
  2: [[300, 30, 5], [300, 30, 6], [350, 35, 7], [400, 40, 8], [450, 45, 8], [450, 45, 9], [500, 50, 9], [500, 50, 10], [550, 55, 11], [650, 65, 12]],
  3: [[650, 65, 13], [750, 75, 15], [900, 90, 17], [1000, 100, 20], [1150, 115, 22], [1250, 125, 25], [1500, 150, 30], [1900, 190, 37], [2150, 215, 42], [2500, 250, 50]],
  4: [[3000, 300, 50], [3150, 315, 62], [3750, 375, 75], [4150, 415, 82], [4650, 465, 92], [5000, 500, 100], [5650, 565, 112], [6250, 625, 125], [6900, 690, 137], [7500, 750, 150]],
  5: [[8750, 875, 175], [10000, 1000, 200], [11250, 1125, 225], [12500, 1250, 250], [13750, 1375, 275], [15000, 1500, 300], [17500, 1750, 250], [20000, 2000, 400], [22500, 2250, 450], [25000, 2500, 500]]
};
// Tabela XIV-3a: quantidade de objetos magicos (1d20) por quantidade de tesouro magico
export const QUANTIDADES = ["Muito pouco", "Pouco", "Médio", "Muito", "Vasto"];
export const QTD_MAGICOS = [[1, 2, [0, 0, 0, 0, 0]], [3, 4, [0, 0, 0, 0, 1]], [5, 6, [0, 0, 0, 1, 2]], [7, 8, [0, 0, 0, 1, 3]], [9, 10, [0, 0, 1, 2, 4]], [11, 12, [0, 1, 1, 2, 5]],
  [13, 15, [1, 1, 2, 3, 5]], [16, 17, [1, 2, 3, 3, 6]], [18, 19, [1, 2, 3, 4, 7]], [20, 20, [2, 3, 4, 5, 8]]];
// Tabela XIV-3b: tipo de objeto magico (1d20)
export const TIPO_OBJETO = [R(1, 3, "Anéis"), R(4, 8, "Armas"), R(9, 11, "Armaduras, Elmos e Escudos"), R(12, 14, "Cetros e Cajados"), R(15, 20, "Óleos, Poções e Elixires")];
// Tabela XIV-3.1: bonus somado ao 1d20 (1d10 pelas colunas dos tipos 1 a 5)
export const BONUS = [[0, 0, 10, 30, 40], [0, 0, 10, 40, 50], [0, 10, 20, 40, 50], [0, 10, 20, 40, 50], [0, 20, 30, 50, 60], [0, 20, 30, 50, 60], [10, 20, 30, 50, 60], [10, 20, 30, 50, 60], [10, 30, 40, 60, 70], [20, 30, 40, 60, 70]];

export const ANEIS = [R(1, 4, "Levitação 3 (uma vez por dia)"), R(5, 7, "Resistência 2 (uma vez por dia)"), R(8, 10, "Fanatismo 1 (constante)"), R(11, 14, "Detecções 3 (duas vezes por dia)"),
  R(15, 17, "Focus +3, Medo 2 (uma vez por dia)"), R(18, 21, "Anel da Influência"), R(22, 26, "Linguagem 2 (constante)"), R(27, 30, "Visão Noturna 2 (constante)"), R(31, 32, "Telecinese 5 (duas vezes por dia)"),
  R(33, 35, "Amizade 4 (uma vez por dia)"), R(36, 38, "Detecções 5 (constante)"), R(39, 40, "Regeneração 4 (uma vez por dia)"), R(41, 42, "Invisibilidade 4 (uma vez por dia)"), R(43, 46, "Levitação 5 (duas vezes por dia)"),
  R(47, 49, "Piroproteção 6 (três vezes por dia)"), R(50, 50, "Proteção 3 (constante)"), R(51, 53, "Linguagem 6 (constante)"), R(54, 54, "Focus +8, Geoproteção 6 (uma vez por dia)"), R(55, 58, "Telecinese 7 (uma vez por dia)"),
  R(59, 60, "Fanatismo 7 (constante)"), R(61, 61, "Regeneração 10 (constante)"), R(62, 65, "Medo 8 (uma vez por dia)"), R(66, 66, "Empatia Animal 7 (duas vezes por dia)"), R(67, 70, "Piroproteção 10 (duas vezes por dia)"),
  R(71, 73, "Elo Animal 9 (uma vez por dia)"), R(74, 76, "Anel do Sexto Sentido"), R(77, 77, "Proteção 7 (constante)"), R(78, 80, "Invisibilidade 6 (três vezes por dia)"), R(81, 83, "Focus +10, Resistência 8 (uma vez por dia)"),
  R(84, 86, "Focus +10, Telecinese 10 (uma vez por dia)"), R(87, 88, "Focus +10, Geoproteção 10 (uma vez por dia)"), R(89, 90, "Focus +12, Raio Elétrico 10 (uma vez por dia)")];

export const TIPO_ARMA = [R(1, 2, "leve"), R(3, 13, "media"), R(14, 20, "pesada")];
export const ARMAS_TIPO = {
  leve: [R(1, 1, "Faca"), R(2, 13, "Punhal"), R(14, 20, "Cajado")],
  media: [R(1, 1, "Machado"), R(2, 3, "Machado de guerra"), R(4, 5, "Gládio"), R(6, 9, "Espada"), R(10, 10, "Clava"), R(11, 11, "Maça"), R(12, 14, "Martelo de guerra"), R(15, 16, "Lança leve"), R(17, 17, "Lança pesada"), R(18, 19, "Arco simples"), R(20, 20, "Arco composto")],
  pesada: [R(1, 5, "Espada de mão e meia"), R(6, 10, "Montante"), R(11, 13, "Maça de armas"), R(14, 18, "Mangual"), R(19, 20, "Lança de cavalaria")]
};
export const PODERES_ARMA = [R(1, 12, "+1"), R(13, 15, "+1, Manipulação de Luz 1 (uma vez por dia)"), R(16, 17, "+1, Defesa 2 (uma vez por dia)"), R(18, 19, "+1, Piroproteção 1 (três vezes por dia)"),
  R(20, 20, "+1, Raio Elétrico 2 (duas vezes por dia)"), R(21, 22, "+1, Focus +3"), R(23, 30, "+2"), R(31, 33, "+2, Telecinese 3 (uma vez por dia)"), R(34, 36, "+2, Curas Físicas 5 (uma vez por dia)"),
  R(37, 39, "+2, Invisibilidade 4 (três vezes por dia)"), R(40, 40, "+2, Focus +6"), R(41, 49, "+3"), R(50, 50, "+3, Visão Noturna 4 (uma vez por dia)"), R(51, 52, "+3, Bola de Fogo 5 (duas vezes por dia)"),
  R(53, 54, "+3, Piroproteção 4 (três vezes por dia)"), R(55, 56, "+3, Raio Elétrico 6 (uma vez por dia)"), R(57, 58, "+3, Esconjuração 7 (uma vez por dia)"), R(59, 59, "+3, Focus +4"), R(60, 60, "+3, Focus +7"),
  R(61, 67, "+4"), R(68, 69, "+4, Curas Espirituais 8 (duas vezes por dia)"), R(70, 70, "+4, Quebra de Encantos 8 (duas vezes por dia)"), R(71, 72, "+4, Sono 7 (três vezes por dia)"),
  R(73, 74, "+4, Contatos Mentais 7 (quatro vezes por dia)"), R(75, 76, "+4, Raio Elétrico 6 (duas vezes por dia), Focus +6"), R(77, 77, "+4, Focus +10"), R(78, 82, "+5"),
  R(83, 84, "+5, Curas Espirituais 2 (seis vezes por dia)"), R(85, 85, "+5, Covardia 5 (três vezes por dia)"), R(86, 86, "+5, Focus +9"), R(87, 87, "+5, Proteção 9 (uma vez por dia)"),
  R(88, 88, "+5, Raio Elétrico 10 (uma vez por dia)"), R(89, 89, "+5, Ressurreição 10 (uma vez por dia)"), R(90, 90, "+5, Medo 8 (três vezes por dia), Focus +6")];

export const TIPO_DEFESA = [R(1, 1, "Elmo aberto"), R(2, 2, "Elmo fechado"), R(3, 3, "Escudo pequeno"), R(4, 5, "Escudo grande"), R(6, 20, "Armadura")];
export const TIPO_ARMADURA = [R(1, 4, "Couro leve"), R(5, 9, "Couro rígido"), R(10, 14, "Cota de malha parcial"), R(15, 17, "Cota de malha completa"), R(18, 20, "Couraça metálica")];
export const DEFESA_PODERES = {
  "Armadura": [R(1, 6, "+1"), R(7, 11, "+2"), R(12, 13, "+2, Defesa +1"), R(14, 15, "+2, Manipulação de Luz 1 (duas vezes por dia)"), R(16, 18, "+3"), R(19, 19, "+3, Defesa +1"), R(20, 21, "+3, Piroproteção 2 (duas vezes por dia)"),
    R(22, 23, "+3, Detecções 3 (uma vez por dia)"), R(24, 26, "+4"), R(27, 28, "+4, Defesa +1"), R(29, 30, "+4, Piroproteção 6 (uma vez por dia)"), R(31, 31, "+4, Ações Furtivas 5 (duas vezes por dia)"), R(32, 35, "+5"),
    R(36, 38, "+5, Defesa +1"), R(39, 40, "+5, Armadura Elemental 6 (duas vezes por dia)"), R(41, 42, "+5, Curas Físicas 5 (três vezes por dia)"), R(43, 46, "+6"), R(47, 49, "+6, Defesa +1"),
    R(50, 51, "+6, Curas Espirituais 8 (uma vez por dia)"), R(52, 53, "+6, Montar 9 (três vezes por dia)"), R(54, 58, "+7"), R(59, 60, "+7, Defesa +1"), R(61, 61, "+7, Invisibilidade 6 (uma vez por dia)"),
    R(62, 63, "+7, Detecções 8 (quatro vezes por dia)"), R(64, 67, "+8"), R(68, 69, "+8, Defesa +1"), R(70, 71, "+8, Armadura Elemental 10 (uma vez por dia)"), R(72, 75, "+9"), R(76, 78, "+9, Defesa +1"),
    R(79, 80, "+9, Bênção 9 (duas vezes por dia)"), R(81, 83, "+10"), R(84, 85, "+10, Defesa +2"), R(86, 87, "+11"), R(88, 89, "+11, Defesa +2"), R(90, 90, "+12, Defesa +3")],
  "Elmo": [R(1, 6, "+1"), R(7, 12, "+1, Detecções 1 (três vezes por dia)"), R(13, 17, "+1, Análise 1 (uma vez por dia)"), R(18, 20, "+1, Linguagem 2 (duas vezes por dia)"), R(21, 29, "+2"),
    R(30, 35, "+2, Visão Noturna 4 (uma vez por dia)"), R(36, 38, "+2, Ventriloquismo 3 (uma vez por dia)"), R(39, 40, "+2, Sugestão 3 (uma vez por dia)"), R(41, 43, "+2, Medo 4 (duas vezes por dia)"), R(44, 52, "+3"),
    R(53, 58, "+3, Covardia 5 (uma vez por dia)"), R(59, 63, "+3, Detecções 8 (uma vez por dia)"), R(64, 70, "+3, Domínio 7 (uma vez por dia)"), R(71, 76, "+4"), R(77, 80, "+4, Medo 8 (uma vez por dia)"),
    R(81, 84, "+4, Sugestão 9 (uma vez por dia)"), R(85, 90, "+5, Defesa +2")],
  "Escudo": [R(1, 8, "+1"), R(9, 12, "+1, Manipulação de Luz 1 (uma vez por dia)"), R(13, 16, "+1, Defesa +1"), R(17, 22, "+2"), R(23, 26, "+2, Resistência 2 (duas vezes por dia)"), R(27, 29, "+2, Defesa +1"), R(30, 35, "+3"),
    R(36, 39, "+3, Bênção 3 (uma vez por dia)"), R(40, 42, "+3, Defesa +1"), R(43, 48, "+4"), R(49, 51, "+4, Medo 6 (duas vezes por dia)"), R(52, 54, "+4, Defesa +1"), R(55, 60, "+5"),
    R(61, 63, "+5, Armadura Elemental 8 (uma vez por dia)"), R(64, 67, "+5, Defesa +1"), R(68, 75, "+6"), R(76, 80, "+6, Piroproteção 10 (uma vez por dia)"), R(81, 84, "+6, Defesa +1"),
    R(85, 87, "+7, Quebra de Encantos 8 (uma vez por dia)"), R(88, 90, "+8, Defesa +2")]
};
export const TIPO_CETRO = [R(1, 5, "Cetro comum"), R(6, 8, "Cetro maior"), R(9, 16, "Cajado comum"), R(17, 20, "Cajado maior")];
export const MATRIZES = {"Cetro comum": 1, "Cetro maior": 2, "Cajado comum": 3, "Cajado maior": 4};
export const PODERES_CETRO = [R(1, 5, "Focus +1"), R(6, 7, "Covardia 2"), R(8, 8, "Focus +2, Manipulação de Luz 1"), R(9, 10, "Focus +3"), R(11, 13, "Curas Físicas 4, Curas Espirituais 2"), R(14, 15, "Focus +4"),
  R(16, 16, "Focus +4, Corrente 2"), R(17, 20, "Detecções 3, Esconjuração 3"), R(21, 22, "Focus +4, Pesadelo 3"), R(23, 25, "Focus +4, Raio Elétrico 4"), R(26, 28, "Focus +5"), R(29, 30, "Focus +5, Amizade 4"),
  R(31, 32, "Piromanipulação 4, Piroproteção 6"), R(33, 35, "Focus +7, Armadura Elemental 6"), R(36, 38, "Empatia 5, Sugestão 6"), R(39, 40, "Focus +6, Retorno 7"), R(41, 43, "Curas Físicas 7, Curas Espirituais 8"),
  R(44, 45, "Focus +9, Transporte Dimensional 7"), R(46, 47, "Recuperação Física 7, Regeneração 8"), R(48, 48, "Focus +9, Quebra de Encantos 8"), R(49, 50, "Focus +12"), R(51, 52, "Ilusões Visuais 8, Toque 7, Som 5"),
  R(53, 54, "Focus +11, Bola de Fogo 7"), R(55, 57, "Piroproteção 8, Bola de Fogo 7"), R(58, 58, "Empatia 7, Amizade 7, Medo 8"), R(59, 60, "Focus +15"), R(61, 63, "Focus +16, Covardia 8"),
  R(64, 66, "Controle Climático 9, Relâmpagos 8"), R(67, 69, "Focus +17, Medo 8, Pesadelo 8"), R(70, 70, "Focus +18, Raio Elétrico 10"), R(71, 73, "Focus +20, Quebra de Encantos 10"),
  R(74, 76, "Curas Físicas 9, Ressurreição 10"), R(77, 78, "Focus +20, Transporte Dimensional 9"), R(79, 80, "Controle 10, Domínio 9, Retorno 9"), R(81, 83, "Focus +22, Medo 8, Covardia 8"),
  R(84, 88, "Piromanipulação 10, Bola de Fogo 9"), R(89, 90, "Focus +25, Raio Elétrico 10")];
export const POCOES = [R(1, 2, "Elixir de Diminuição"), R(3, 5, "Poção de Piroproteção 1"), R(6, 8, "Poção de Visão Noturna 2"), R(9, 11, "Óleo de Camuflagem"), R(12, 16, "Poção de Curas Físicas 2"),
  R(17, 18, "Elixir da Influência"), R(19, 21, "Poção de Invisibilidade 2"), R(22, 23, "Elixir Menor do Amor"), R(24, 27, "Poção de Detecções 5"), R(28, 31, "Elixir da Força"), R(32, 34, "Poção de Mutação 5"),
  R(35, 36, "Elixir de Heroísmo"), R(37, 38, "Elixir de Crescimento"), R(39, 42, "Poção de Curas Físicas 5"), R(43, 45, "Poção de Invisibilidade 6"), R(46, 48, "Óleo de Invulnerabilidade"),
  R(49, 50, "Elixir de Força de Gigante"), R(51, 53, "Poção de Ressurreição 10"), R(54, 57, "Poção de Curas Físicas 9"), R(58, 60, "Poção de Levitação 5"), R(61, 63, "Poção de Recuperação Física 7"),
  R(64, 65, "Elixir de Hálito Flamejante"), R(66, 68, "Poção de Mutação 10"), R(69, 70, "Elixir Maior do Amor"), R(71, 73, "Poção de Piroproteção 10"), R(74, 76, "Poção de Controle 10"),
  R(77, 82, "Elixir da Grande Cura"), R(83, 87, "Elixir dos Deuses"), R(88, 90, "Elixir da Vida")];

// ---------- Geracao (a rolagem fica a cargo de quem chama: recebe uma funcao d(lados) -> numero) ----------
export function gerarMagico(tipoTesouro, d) {
  const cat = acha(TIPO_OBJETO, d(20));
  const bonus = BONUS[d(10) - 1][tipoTesouro - 1];
  const dado = d(20);
  const total = dado + bonus;
  let nome, extra = "";
  if (cat === "Anéis") nome = "Anel: " + acha(ANEIS, total);
  else if (cat === "Armas") { const t = acha(TIPO_ARMA, d(20)); nome = acha(ARMAS_TIPO[t], d(20)) + " mágica: " + acha(PODERES_ARMA, total); }
  else if (cat === "Armaduras, Elmos e Escudos") {
    let tipo = acha(TIPO_DEFESA, d(20)); let tabela;
    if (tipo === "Armadura") { tipo = acha(TIPO_ARMADURA, d(20)); tabela = DEFESA_PODERES["Armadura"]; }
    else tabela = DEFESA_PODERES[tipo.split(" ")[0]];
    nome = tipo + " mágico(a): " + acha(tabela, total);
  } else if (cat === "Cetros e Cajados") { const t = acha(TIPO_CETRO, d(20)); nome = t + " (" + MATRIZES[t] + (MATRIZES[t] === 1 ? " matriz" : " matrizes") + " de poder): " + acha(PODERES_CETRO, total); }
  else nome = acha(POCOES, total);
  return {categoria: cat, bonus: bonus, dado: dado, total: total, nome: nome};
}
export function gerarMonetario(tipo, d) { return MONETARIO[tipo][d(10) - 1]; }
export function quantidadeMagicos(colQtd, d) {
  const n = d(20);
  for (const l of QTD_MAGICOS) { if (n >= l[0] && n <= l[1]) return {rolou: n, qtd: l[2][colQtd]}; }
  return {rolou: n, qtd: 0};
}
