import { descricaoVerificadaDaMagia, MAGIAS } from "./magias.mjs";

const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ItemSheetV2 } = foundry.applications.sheets;

// ficha simples e generica para os itens dos compendios (habilidade, arma, armadura, raca, profissao)
export class TagmarItemSheet extends HandlebarsApplicationMixin(ItemSheetV2) {
  static DEFAULT_OPTIONS = {
    classes: ["tagmar1e", "item"],
    position: {width: 420, height: "auto"},
    window: {resizable: true},
    form: {submitOnChange: true}
  };

  static PARTS = {
    corpo: {template: "systems/tagmar1e/templates/item.hbs"}
  };

  // tema visual escolhido nas configuracoes do sistema
  async _onRender(context, options) {
    await super._onRender(context, options);
    this.element.classList.toggle("tema-pergaminho", game.settings.get("tagmar1e", "tema") === "pergaminho");
  }

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const campos = [];
    const leitura = [];
    const textos = [];
    const visita = function (obj, caminho) {
      for (const k of Object.keys(obj)) {
        const v = obj[k];
        const nome = caminho ? caminho + "." + k : k;
        if (Array.isArray(v)) leitura.push({rot: nome, valor: v.map(function (x) { return x !== null && typeof x === "object" ? Object.values(x).join(": ") : x; }).join(v.some(function (x) { return x !== null && typeof x === "object"; }) ? " | " : ", ")});
        else if (v !== null && typeof v === "object") visita(v, nome);
        else if (nome === "descricao") textos.push({nome: "system." + nome, rot: "descrição", valor: v});
        else campos.push({nome: "system." + nome, rot: nome, tipo: typeof v === "number" ? "number" : "text", valor: v});
      }
    };
    visita(this.item.toObject().system, "");
    ctx.item = this.item;
    ctx.editable = this.isEditable;
    ctx.campos = campos;
    ctx.leitura = leitura;
    ctx.textos = textos;
    // Read-only reference independent of existing compendium description; no writes.
    ctx.descricaoOficial = this.item.type === "magia" && Object.hasOwn(MAGIAS, this.item.name)
      ? descricaoVerificadaDaMagia(this.item.name) : "";
    return ctx;
  }
}
