// Magias do Tagmar 1a edicao (capitulo V): custos por lista (tabelas V-9.5b a V-9.5j) e dados de cada magia (listagem do livro).
// "dificuldades" foram lidas por reconhecimento automatico; "ataque" lista o dano maximo dos efeitos das magias de ataque fisico.
export const MAGIAS = {
 "Abrigo": {
  "evocacao": "uma rodada",
  "alcance": "pessoal",
  "duracao": "instantânea",
  "dificuldades": [1, 3, 5],
  "ataque": [],
  "listas": {
   "Rastreador": 2
  }
 },
 "Aeroataque": {
  "evocacao": "instantânea",
  "alcance": "10 metros",
  "duracao": "uma rodada",
  "dificuldades": [1, 3, 5, 7, 10],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Aeromanipulação": {
  "evocacao": "instantânea",
  "alcance": "20 metros",
  "duracao": "30 rodadas",
  "dificuldades": [1, 2, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Alucinação": {
  "evocacao": "instantânea",
  "alcance": "20 metros",
  "duracao": "variável",
  "dificuldades": [1, 2, 4, 5, 6, 7, 8, 9, 10],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Amizade": {
  "evocacao": "instantânea",
  "alcance": "20 metros",
  "duracao": "variável",
  "dificuldades": [1, 2, 4, 6, 8, 10],
  "ataque": [],
  "listas": {
   "Bardo": 4,
   "Mago": 2
  }
 },
 "Análise": {
  "evocacao": "ritual",
  "alcance": "toque",
  "duracao": "1 uso",
  "dificuldades": [
   1,
   4,
   7,
   10
  ],
  "ataque": [],
  "listas": {
   "Bardo": 3,
   "Mago": 1,
   "Ordem Espiritual": 1
  }
 },
 "Apelo": {
  "evocacao": "variável",
  "alcance": "5 metros",
  "duracao": "variável",
  "dificuldades": [1, 3, 5, 6, 7, 9],
  "ataque": [],
  "listas": {
   "Sacerdote": 3,
   "Ordem Espiritual": 2
  }
 },
 "Armadilha": {
  "evocacao": "ritual",
  "alcance": "10 metros",
  "duracao": "variável",
  "dificuldades": [1, 2, 3, 4, 6, 8, 10],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 2
  }
 },
 "Armadura Elemental": {
  "evocacao": "instantânea",
  "alcance": "pessoal",
  "duracao": "15 rodadas",
  "dificuldades": [
   1,
   3,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Rastreador": 4,
   "Colégio Elemental": 1
  }
 },
 "Ações Furtivas": {
  "evocacao": "instantânea",
  "alcance": "pessoal",
  "duracao": "1 uso",
  "dificuldades": [1, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Rastreador": 3
  }
 },
 "Bola de Fogo": {
  "evocacao": "instantânea",
  "alcance": "50 metros",
  "duracao": "instantânea",
  "dificuldades": [
   1,
   2,
   3,
   5,
   7,
   9
  ],
  "ataque": [
   {
    "dificuldade": 1,
    "danoMaximo": 12
   },
   {
    "dificuldade": 2,
    "danoMaximo": 16
   },
   {
    "dificuldade": 3,
    "danoMaximo": 20
   },
   {
    "dificuldade": 5,
    "danoMaximo": 28
   },
   {
    "dificuldade": 7,
    "danoMaximo": 32
   },
   {
    "dificuldade": 9,
    "danoMaximo": 36
   }
  ],
  "listas": {
   "Mago": 2,
   "Colégio Elemental": 1
  }
 },
 "Bênção": {
  "evocacao": "instantânea",
  "alcance": "10 metros",
  "duracao": "10 rodadas",
  "dificuldades": [1, 2, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Ordem Guerreira": 1,
   "Ordem Espiritual": 1
  }
 },
 "Camuflagem": {
  "evocacao": "3 rodadas",
  "alcance": "toque",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Rastreador": 3
  }
 },
 "Canção de Medo": {
  "evocacao": "4 rodadas",
  "alcance": "20 metros",
  "duracao": "10 rodadas",
  "dificuldades": [1, 3, 5, 7, 8, 10],
  "ataque": [],
  "listas": {
   "Bardo": 5
  }
 },
 "Canção de Ânimo": {
  "evocacao": "4 rodadas",
  "alcance": "5 metros",
  "duracao": "20 rodadas",
  "dificuldades": [
   1,
   3,
   5,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Bardo": 4
  }
 },
 "Canções de Sono": {
  "evocacao": "uma rodada",
  "alcance": "20 metros",
  "duracao": "variável",
  "dificuldades": [1,2,3,5,6,7,9,10],
  "ataque": [],
  "listas": {
   "Bardo": 5
  }
 },
 "Conjuração Demoníaca": {
  "evocacao": "ritual",
  "alcance": "10 metros",
  "duracao": "variável",
  "dificuldades": [1, 3, 5, 7],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Contatos": {
  "evocacao": "variável",
  "alcance": "pessoal",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Ordem Espiritual": 2
  }
 },
 "Contatos Mentais": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Mago": 1
  }
 },
 "Controle": {
  "evocacao": "10 rodadas",
  "alcance": "10 metros",
  "duracao": "permanente",
  "dificuldades": [1, 2, 4, 6, 8, 10],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Controle Climático": {
  "evocacao": "3 rodadas",
  "alcance": "10 km",
  "duracao": "uma hora",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Ordem Espiritual": 1
  }
 },
 "Controle da Voz": {
  "evocacao": "instantânea",
  "alcance": "pessoal",
  "duracao": "20 rodadas",
  "dificuldades": [
   1,
   2,
   3,
   4,
   5
  ],
  "ataque": [],
  "listas": {
   "Bardo": 1
  }
 },
 "Convocação": {
  "evocacao": "variável",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [1, 2, 4, 6, 8, 10],
  "ataque": [],
  "listas": {
   "Ordem Guerreira": 2
  }
 },
 "Corrente": {
  "evocacao": "instantânea",
  "alcance": "30 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   4,
   6,
   9
  ],
  "ataque": [],
  "listas": {
   "Sacerdote": 2
  }
 },
 "Covardia": {
  "evocacao": "instantânea",
  "alcance": "50 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   3,
   5,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Sacerdote": 3,
   "Ordem Guerreira": 2,
   "Ordem Espiritual": 2,
   "Colégio das Ilusões": 1
  }
 },
 "Criação": {
  "evocacao": "ritual",
  "alcance": "5 metros",
  "duracao": "permanente",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Curas Espirituais": {
  "evocacao": "instantânea",
  "alcance": "toque",
  "duracao": "instantânea",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Sacerdote": 2,
   "Ordem Guerreira": 1,
   "Ordem Espiritual": 1
  }
 },
 "Curas Físicas": {
  "evocacao": "instantânea",
  "alcance": "toque",
  "duracao": "permanente",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Sacerdote": 2,
   "Ordem Guerreira": 1,
   "Ordem Espiritual": 1
  }
 },
 "Círculo de Proteção": {
  "evocacao": "uma rodada",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Dardos de Gelo": {
  "evocacao": "instantânea",
  "alcance": "50 metros",
  "duracao": "uma rodada",
  "dificuldades": [1, 3, 5, 7, 9],
  "ataque": [
   {
    "dificuldade": 1,
    "danoMaximo": 12
   },
   {
    "dificuldade": 3,
    "danoMaximo": 16
   },
   {
    "dificuldade": 5,
    "danoMaximo": 20
   },
   {
    "dificuldade": 7,
    "danoMaximo": 24
   },
   {
    "dificuldade": 9,
    "danoMaximo": 32
   }
  ],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Degeneração Física": {
  "evocacao": "instantânea",
  "alcance": "15 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Ordem Guerreira": 2,
   "Ordem Espiritual": 2,
   "Colégio Necromântico": 1
  }
 },
 "Desintegração": {
  "evocacao": "uma rodada",
  "alcance": "50 metros",
  "duracao": "instantânea",
  "dificuldades": [1, 2, 4, 6, 8, 10],
  "ataque": [],
  "listas": {
   "Mago": 2,
   "Colégio Elemental": 1
  }
 },
 "Despistamento": {
  "evocacao": "3 rodadas",
  "alcance": "toque",
  "duracao": "3 horas",
  "dificuldades": [1, 2, 3, 5, 6, 7, 8, 10],
  "ataque": [],
  "listas": {
   "Rastreador": 3
  }
 },
 "Detecção de Magia": {
  "evocacao": "uma rodada",
  "alcance": "variável",
  "duracao": "uma rodada",
  "dificuldades": [
   1,
   2,
   3,
   4,
   6
  ],
  "ataque": [],
  "listas": {
   "Bardo": 3,
   "Mago": 2
  }
 },
 "Detecções": {
  "evocacao": "duas rodadas",
  "alcance": "10 metros",
  "duracao": "3 rodadas",
  "dificuldades": [
   1,
   2,
   3,
   5,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Sacerdote": 1
  }
 },
 "Doenças": {
  "evocacao": "instantânea",
  "alcance": "30 metros",
  "duracao": "instantânea",
  "dificuldades": [
   1,
   3,
   5,
   7,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Domínio": {
  "evocacao": "uma rodada",
  "alcance": "30 metros",
  "duracao": "24 horas",
  "dificuldades": [1, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 2
  }
 },
 "Domínio Demoníaco": {
  "evocacao": "10 rodadas",
  "alcance": "10 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Elemental da Terra": {
  "evocacao": "ritual",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Elemental da Água": {
  "evocacao": "ritual",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Elemental do Ar": {
  "evocacao": "ritual",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Elemental do Fogo": {
  "evocacao": "ritual",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [1, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Elo Animal": {
  "evocacao": "variável",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   3,
   4,
   5,
   6,
   7,
   8,
   9,
   10
  ],
  "ataque": [],
  "listas": {
   "Rastreador": 3
  }
 },
 "Empatia": {
  "evocacao": "uma rodada",
  "alcance": "10 metros",
  "duracao": "uma hora",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Empatia Animal": {
  "evocacao": "instantânea",
  "alcance": "10 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   4,
   5,
   6,
   7
  ],
  "ataque": [],
  "listas": {
   "Rastreador": 3
  }
 },
 "Energia Infernal": {
  "evocacao": "instantânea",
  "alcance": "15 metros",
  "duracao": "instantânea",
  "dificuldades": [
   1,
   2,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Escalar Superfícies": {
  "evocacao": "instantânea",
  "alcance": "pessoal",
  "duracao": "1 uso",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Rastreador": 3
  }
 },
 "Esconjuração": {
  "evocacao": "instantânea",
  "alcance": "100 metros",
  "duracao": "1 dia",
  "dificuldades": [1, 2, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Sacerdote": 1,
   "Colégio Necromântico": 1
  }
 },
 "Escuridão": {
  "evocacao": "instantânea",
  "alcance": "30 metros",
  "duracao": "variável",
  "dificuldades": [1, 3, 4, 5, 6, 7, 8, 9, 10],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 2,
   "Colégio Necromântico": 1
  }
 },
 "Escárnio": {
  "evocacao": "10 rodadas",
  "alcance": "30 metros",
  "duracao": "4 semanas",
  "dificuldades": [
   1,
   3,
   4,
   7,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Bardo": 3
  }
 },
 "Fanatismo": {
  "evocacao": "10 rodadas",
  "alcance": "100 metros",
  "duracao": "12 horas",
  "dificuldades": [1, 3, 5, 7],
  "ataque": [],
  "listas": {
   "Ordem Guerreira": 1
  }
 },
 "Geomanipulação": {
  "evocacao": "instantânea",
  "alcance": "20 metros",
  "duracao": "10 rodadas",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Geoproteção": {
  "evocacao": "instantânea",
  "alcance": "toque",
  "duracao": "20 rodadas",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Hidromanipulação": {
  "evocacao": "uma rodada",
  "alcance": "15 metros",
  "duracao": "10 rodadas",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Ilusões Materiais": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [1, 2, 3, 5, 7, 9, 10],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Ilusões Visuais": {
  "evocacao": "instantânea",
  "alcance": "40 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   3,
   4,
   5,
   6,
   7,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Imagem": {
  "evocacao": "variável",
  "alcance": "50 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   9,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Invisibilidade": {
  "evocacao": "instantânea",
  "alcance": "toque",
  "duracao": "10 minutos",
  "dificuldades": [
   1,
   2,
   4,
   6
  ],
  "ataque": [],
  "listas": {
   "Mago": 2,
   "Colégio das Ilusões": 1
  }
 },
 "Ira Divina": {
  "evocacao": "ritual",
  "alcance": "variável",
  "duracao": "uma semana",
  "dificuldades": [1, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Ordem Espiritual": 2
  }
 },
 "Lendas": {
  "evocacao": "ritual",
  "alcance": "toque",
  "duracao": "1 uso",
  "dificuldades": [
   1,
   3,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Bardo": 4
  }
 },
 "Ler Trilhas": {
  "evocacao": "5 rodadas",
  "alcance": "pessoal",
  "duracao": "uma rodada",
  "dificuldades": [
   1,
   3,
   6,
   8
  ],
  "ataque": [],
  "listas": {
   "Rastreador": 1
  }
 },
 "Levitação": {
  "evocacao": "uma rodada",
  "alcance": "pessoal",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5
  ],
  "ataque": [],
  "listas": {
   "Mago": 1
  }
 },
 "Linguagem": {
  "evocacao": "uma rodada",
  "alcance": "pessoal",
  "duracao": "uma hora",
  "dificuldades": [
   1,
   2,
   4,
   6
  ],
  "ataque": [],
  "listas": {
   "Bardo": 4
  }
 },
 "Maldições": {
  "evocacao": "3 rodadas",
  "alcance": "10 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Ordem Espiritual": 2,
   "Colégio Necromântico": 2
  }
 },
 "Manipulação de Luz": {
  "evocacao": "instantânea",
  "alcance": "20 metros",
  "duracao": "variável",
  "dificuldades": [1, 2, 3, 4, 6, 8, 10],
  "ataque": [],
  "listas": {
   "Mago": 1,
   "Ordem Espiritual": 1
  }
 },
 "Medo": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "10 rodadas",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8
  ],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Memorização": {
  "evocacao": "uma rodada",
  "alcance": "toque",
  "duracao": "duas semanas",
  "dificuldades": [1, 2, 3, 5],
  "ataque": [],
  "listas": {
   "Bardo": 3
  }
 },
 "Meteoros": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "instantânea",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [
   {
    "dificuldade": 1,
    "danoMaximo": 12
   },
   {
    "dificuldade": 2,
    "danoMaximo": 16
   },
   {
    "dificuldade": 4,
    "danoMaximo": 20
   },
   {
    "dificuldade": 6,
    "danoMaximo": 24
   },
   {
    "dificuldade": 8,
    "danoMaximo": 28
   },
   {
    "dificuldade": 10,
    "danoMaximo": 32
   }
  ],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Montar": {
  "evocacao": "instantânea",
  "alcance": "pessoal",
  "duracao": "1 uso",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Rastreador": 3
  }
 },
 "Mutação": {
  "evocacao": "uma rodada",
  "alcance": "pessoal",
  "duracao": "uma hora",
  "dificuldades": [
   1,
   3,
   5,
   7,
   10
  ],
  "ataque": [],
  "listas": {
   "Mago": 2
  }
 },
 "Necroanimação": {
  "evocacao": "10 rodadas",
  "alcance": "50 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Necroconhecimento": {
  "evocacao": "ritual",
  "alcance": "2 metros",
  "duracao": "variável",
  "dificuldades": [1, 3, 5, 7, 10],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Odor": {
  "evocacao": "variável",
  "alcance": "10 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Ordens": {
  "evocacao": "instantânea",
  "alcance": "30 metros",
  "duracao": "variável",
  "dificuldades": [1, 2, 4, 6, 7, 10],
  "ataque": [],
  "listas": {
   "Ordem Espiritual": 1
  }
 },
 "Paralisia": {
  "evocacao": "instantânea",
  "alcance": "20 metros",
  "duracao": "30 rodadas",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Pentagrama Místico": {
  "evocacao": "uma rodada",
  "alcance": "10 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Pergunta": {
  "evocacao": "ritual",
  "alcance": "pessoal",
  "duracao": "10 rodadas",
  "dificuldades": [1, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 },
 "Pesadelo": {
  "evocacao": "uma rodada",
  "alcance": "20 metros",
  "duracao": "variável",
  "dificuldades": [1, 3, 5, 8],
  "ataque": [],
  "listas": {
   "Ordem Espiritual": 2,
   "Colégio das Ilusões": 1,
   "Colégio Necromântico": 1
  }
 },
 "Piromanipulação": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "10 rodadas",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Piroproteção": {
  "evocacao": "instantânea",
  "alcance": "toque",
  "duracao": "variável",
  "dificuldades": [1, 2, 4, 6, 8, 10],
  "ataque": [],
  "listas": {
   "Ordem Guerreira": 2,
   "Colégio Elemental": 1
  }
 },
 "Possessão": {
  "evocacao": "variável",
  "alcance": "toque",
  "duracao": "variável",
  "dificuldades": [1, 3, 5, 6, 8, 9, 10],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 3,
   "Colégio Necromântico": 2
  }
 },
 "Prisão": {
  "evocacao": "instantânea",
  "alcance": "30 metros",
  "duracao": "variável",
  "dificuldades": [1, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 2
  }
 },
 "Prisão Demoníaca": {
  "evocacao": "uma rodada",
  "alcance": "20 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 2
  }
 },
 "Projeção": {
  "evocacao": "duas rodadas",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Proteção": {
  "evocacao": "instantânea",
  "alcance": "toque",
  "duracao": "variável",
  "dificuldades": [1, 2, 3, 5, 7, 9, 10],
  "ataque": [],
  "listas": {
   "Ordem Guerreira": 1
  }
 },
 "Pseudoconsciência": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [1, 3, 5],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Quebra de Encantos": {
  "evocacao": "variável",
  "alcance": "20 metros",
  "duracao": "instantânea",
  "dificuldades": [1, 3, 4, 6, 7, 9],
  "ataque": [],
  "listas": {
   "Sacerdote": 3,
   "Mago": 2,
   "Ordem Espiritual": 2
  }
 },
 "Raio Elétrico": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "instantânea",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [
   {
    "dificuldade": 1,
    "danoMaximo": 16
   },
   {
    "dificuldade": 2,
    "danoMaximo": 20
   },
   {
    "dificuldade": 4,
    "danoMaximo": 28
   },
   {
    "dificuldade": 6,
    "danoMaximo": 32
   },
   {
    "dificuldade": 8,
    "danoMaximo": 36
   },
   {
    "dificuldade": 10,
    "danoMaximo": 40
   }
  ],
  "listas": {
   "Mago": 2
  }
 },
 "Rastreamento": {
  "evocacao": "uma rodada",
  "alcance": "pessoal",
  "duracao": "1 uso",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Rastreador": 1
  }
 },
 "Recuperação Física": {
  "evocacao": "uma rodada",
  "alcance": "toque",
  "duracao": "instantânea",
  "dificuldades": [
   1,
   3,
   5,
   6,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Sacerdote": 2
  }
 },
 "Regeneração": {
  "evocacao": "ritual",
  "alcance": "toque",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   4,
   6,
   10
  ],
  "ataque": [],
  "listas": {
   "Ordem Guerreira": 2
  }
 },
 "Relâmpagos": {
  "evocacao": "instantânea",
  "alcance": "100 metros",
  "duracao": "instantânea",
  "dificuldades": [1, 2, 4, 6, 8, 10],
  "ataque": [
   {
    "dificuldade": 1,
    "danoMaximo": 12
   },
   {
    "dificuldade": 2,
    "danoMaximo": 16
   },
   {
    "dificuldade": 4,
    "danoMaximo": 24
   },
   {
    "dificuldade": 6,
    "danoMaximo": 28
   },
   {
    "dificuldade": 8,
    "danoMaximo": 32
   },
   {
    "dificuldade": 10,
    "danoMaximo": 40
   }
  ],
  "listas": {
   "Ordem Espiritual": 2
  }
 },
 "Resistência": {
  "evocacao": "instantânea",
  "alcance": "pessoal",
  "duracao": "10 rodadas",
  "dificuldades": [
   1,
   2,
   4,
   6
  ],
  "ataque": [],
  "listas": {
   "Rastreador": 3,
   "Ordem Guerreira": 1,
   "Ordem Espiritual": 1
  }
 },
 "Resistência Elemental": {
  "evocacao": "instantânea",
  "alcance": "pessoal",
  "duracao": "um dia",
  "dificuldades": [
   1,
   3,
   5,
   7,
   10
  ],
  "ataque": [],
  "listas": {
   "Rastreador": 3,
   "Colégio Elemental": 1
  }
 },
 "Resistência à Fadiga": {
  "evocacao": "instantânea",
  "alcance": "pessoal",
  "duracao": "variável",
  "dificuldades": [1, 3, 5, 7],
  "ataque": [],
  "listas": {
   "Rastreador": 3,
   "Ordem Guerreira": 1
  }
 },
 "Ressurreição": {
  "evocacao": "variável",
  "alcance": "toque",
  "duracao": "variável",
  "dificuldades": [1, 2, 4, 6, 8, 10],
  "ataque": [],
  "listas": {
   "Ordem Espiritual": 1
  }
 },
 "Retorno": {
  "evocacao": "uma rodada",
  "alcance": "100 metros",
  "duracao": "instantânea",
  "dificuldades": [1, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Colégio Elemental": 1
  }
 },
 "Runas": {
  "evocacao": "ritual",
  "alcance": "10 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   5
  ],
  "ataque": [],
  "listas": {
   "Sacerdote": 2
  }
 },
 "Sagração de Itens": {
  "evocacao": "ritual",
  "alcance": "toque",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   4,
   6,
   7,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Ordem Guerreira": 2,
   "Ordem Espiritual": 2
  }
 },
 "Silêncio": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "5 rodadas",
  "dificuldades": [
   1,
   3,
   5
  ],
  "ataque": [],
  "listas": {
   "Bardo": 3
  }
 },
 "Solo Sagrado": {
  "evocacao": "ritual",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   2,
   4,
   6,
   8,
   10
  ],
  "ataque": [],
  "listas": {
   "Ordem Guerreira": 1,
   "Ordem Espiritual": 1
  }
 },
 "Som": {
  "evocacao": "instantânea",
  "alcance": "20 metros",
  "duracao": "20 rodadas",
  "dificuldades": [
   1,
   2,
   3,
   5
  ],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Sombras": {
  "evocacao": "variável",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   4,
   5,
   6,
   7,
   8,
   9,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 2
  }
 },
 "Sono": {
  "evocacao": "instantânea",
  "alcance": "20 metros",
  "duracao": "variável",
  "dificuldades": [1, 2, 3, 5, 7, 10],
  "ataque": [],
  "listas": {
   "Mago": 1
  }
 },
 "Sugestão": {
  "evocacao": "instantânea",
  "alcance": "20 metros",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9,
   10
  ],
  "ataque": [],
  "listas": {
   "Bardo": 5,
   "Colégio das Ilusões": 1
  }
 },
 "Telecinese": {
  "evocacao": "uma rodada",
  "alcance": "30 metros",
  "duracao": "10 rodadas",
  "dificuldades": [1, 2, 3, 5, 7, 9],
  "ataque": [],
  "listas": {
   "Mago": 1
  }
 },
 "Toque": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   10
  ],
  "ataque": [],
  "listas": {
   "Colégio das Ilusões": 1
  }
 },
 "Transformação": {
  "evocacao": "instantânea",
  "alcance": "20 metros",
  "duracao": "variável",
  "dificuldades": [1, 2, 4, 6, 8, 10],
  "ataque": [],
  "listas": {
   "Mago": 2
  }
 },
 "Transporte Dimensional": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "variável",
  "dificuldades": [
   1,
   3,
   5,
   7,
   9
  ],
  "ataque": [],
  "listas": {
   "Mago": 2
  }
 },
 "Ventriloquismo": {
  "evocacao": "instantânea",
  "alcance": "variável",
  "duracao": "15 rodadas",
  "dificuldades": [
   1,
   2,
   3,
   4,
   6
  ],
  "ataque": [],
  "listas": {
   "Bardo": 2,
   "Colégio das Ilusões": 1
  }
 },
 "Visão Noturna": {
  "evocacao": "instantânea",
  "alcance": "toque",
  "duracao": "12 horas",
  "dificuldades": [
   1,
   2,
   4
  ],
  "ataque": [],
  "listas": {
   "Colégio Necromântico": 1
  }
 }
};

export const MISTICOS = ["Mago", "Sacerdote", "Rastreador", "Bardo"];
export const ORDENS = ["Ordem Guerreira", "Ordem Espiritual", "Colégio das Ilusões", "Colégio Elemental", "Colégio Necromântico"];

// listas em que o personagem pode comprar magias: a da profissao mistica e a da ordem/colegio (item 9.5)
export function listasDoPersonagem(profissao, ordem) {
  const l = [];
  if (MISTICOS.indexOf(profissao) >= 0) l.push(profissao);
  if (ORDENS.indexOf(ordem) >= 0) l.push(ordem);
  return l;
}

// custo por nivel: o menor entre as listas disponiveis que contem a magia (null = fora das listas)
export function custoDaMagia(nome, listas) {
  const m = MAGIAS[nome];
  if (!m) return null;
  let melhor = null;
  for (const l of listas) {
    if (m.listas[l] !== undefined && (melhor === null || m.listas[l] < melhor)) melhor = m.listas[l];
  }
  return melhor;
}

// Tabela V-9.5a: pontos de magia ganhos ao passar para o estagio (Intelecto 2, 3-4, 5-8, 9-12, 13-15, 16-17, 18-19, 20, 21, 22+)
const INT_LIM = [2, 4, 8, 12, 15, 17, 19, 20, 21];
const BONUS_ESTAGIO = [0, 1, 1, 2, 2, 2, 3, 3, 3, 4];
export function pontosMagiaEstagio(intelecto, estagio) {
  let ci = INT_LIM.findIndex(function (m) { return intelecto <= m; });
  if (ci < 0) ci = INT_LIM.length;
  // A tabela V-9.5a cadastrada cobre somente os estágios 1 a 10.
  // Não repetir a linha 10 para estágios superiores sem fonte verificada.
  if (!Number.isInteger(estagio) || estagio < 1 || estagio > 10) return null;
  return ci + BONUS_ESTAGIO[estagio - 1];
}
// soma dos pontos de todos os estagios ate o atual, supondo o Intelecto atual em todos eles
export function pontosMagiaTotal(intelecto, estagio) {
  let t = 0;
  for (let e = 1; e <= estagio; e++) {
    const ganho = pontosMagiaEstagio(intelecto, e);
    if (ganho === null) return null;
    t += ganho;
  }
  return t;
}

// Resumos detalhados conferidos visualmente no livro impresso de 1991.
// Redação própria; NÃO completar efeitos sem verificação da fonte.
export const EFEITOS_CONFERIDOS_1991 = {
  "Abrigo": {"pagina": 63, "geral": "Localiza um abrigo relativamente seguro em raio de 5 quilômetros, exclusivamente em ambiente natural. Se não houver abrigo adequado na área, o evocador recebe essa informação. A proteção é contra perigos ambientais, como chuva, sol, inundação, desabamento e terremoto, não contra criaturas hostis. A quantidade de ocupantes varia conforme o efeito.", "niveis": {"1": "Localiza abrigo para uma pessoa.", "3": "Localiza abrigo para três pessoas e três cavalos.", "5": "Localiza abrigo para sete pessoas e sete cavalos."}},
  "Ações Furtivas": {"pagina": 63, "geral": "Magia de Rastreador distinta da habilidade homônima. Facilita uma única utilização da habilidade Ações Furtivas, diminuindo o grau de dificuldade; pode ser usada fora de ambientes naturais. Somente o efeito 9 pode tornar uma tarefa Impossível em Muito Difícil.", "niveis": {"1": "Reduz a dificuldade em um nível.", "3": "Reduz a dificuldade em dois níveis.", "5": "Reduz a dificuldade em três níveis.", "7": "Reduz a dificuldade em quatro níveis.", "9": "Reduz a dificuldade em cinco níveis, inclusive convertendo uma tarefa Impossível em Muito Difícil."}},
  "Aeroataque": {"pagina": "63–64", "geral": "Cria uma faixa de vento de 3 metros de largura na direção escolhida, do evocador até o alcance máximo. Atingir criatura ou objeto exige ataque físico com resultado de pelo menos 50%. O vento pode carregar, derrubar ou arrastar conforme o peso e a dificuldade. Objetos fixos não são afetados; criaturas ou objetos lançados para trás podem cair e colidir com obstáculos. Para se segurar contra o vento é exigida a Força indicada por efeito.", "niveis": {"1": "Carrega até 20 kg; Força 8 para se segurar; derruba até 60 kg.", "3": "Carrega até 40 kg; Força 10 para se segurar; derruba até 120 kg.", "5": "Carrega até 60 kg; Força 12 para se segurar; derruba até 180 kg.", "7": "Carrega até 90 kg; Força 14 para se segurar; derruba até 270 kg.", "10": "Carrega até 150 kg; Força 17 para se segurar; derruba até 450 kg."}},
  "Aeromanipulação": {"pagina": 64, "geral": "Manipula gases e ventos dentro do alcance de 20 metros durante 30 rodadas. Ventos criados dissipam-se gradualmente ao sair da área; podem deslocar objetos de até 30 kg e dificultar o avanço de objetos ou criaturas de até 100 kg. O efeito escolhido define a precisão, proteção ou deslocamento do vento.", "niveis": {"1": "Modela gases em formas desejadas dentro da área de efeito.", "2": "Cria vento forte em uma direção; flechas e outros projéteis que cruzam a área recebem ajuste de -6 colunas.", "3": "Cria barreira de vento ao redor do evocador: impede flechas e outros projéteis; demais ataques recebem -4 colunas.", "5": "Cria ventos fortes em todas as direções, repelindo objetos e criaturas; impede flechas e outros projéteis e aplica -6 colunas aos demais ataques.", "7": "Manipula e carrega objetos por meio do vento com grande precisão, inclusive objetos pequenos.", "9": "Permite voar com o vento à velocidade básica de aproximadamente 72 km/h (300 metros por rodada); carga conforme regras gerais de velocidade e peso."}},
  "Alucinação": {"pagina": "64–65", "geral": "Altera os sentidos de uma vítima dentro de 20 metros, se ela falhar na Resistência à Magia. O evocador escolhe os sentidos afetados e o conteúdo percebido; a ilusão pode ser modificada enquanto a vítima permanecer em alcance e no campo de visão. Uma Percepção difícil pode revelar a falta de confiabilidade dos sentidos, mas não encerra a magia. O feitiço afeta a mente, não cria objetos reais.", "niveis": {"1": "Afeta um sentido por 3 rodadas.", "2": "Afeta um sentido por 5 rodadas.", "4": "Afeta dois sentidos por 3 rodadas.", "5": "Afeta dois sentidos por 5 rodadas.", "6": "Afeta três sentidos por 3 rodadas.", "7": "Afeta três sentidos por 5 rodadas.", "8": "Afeta quatro sentidos por 5 rodadas.", "9": "Afeta quatro sentidos por 8 rodadas.", "10": "Afeta cinco sentidos por 5 rodadas."}},
  "Armadilha": {"pagina": 66, "geral": "Ritual que armazena uma magia de ilusão num local imóvel para disparar quando se cumprir condição objetiva de até 15 palavras, verificável por visão ou audição. A ilusão deve ser evocada na rodada seguinte à conclusão de Armadilha. Condições subjetivas não são válidas e podem provocar disparo imediato. O limite de Karma inclui os custos de ambas as magias. Ao expirar a duração, a ilusão armazenada se dissipa. Após disparar uma Armadilha permanente, o feitiço armazenado fica ativo por 24 horas e a Armadilha volta a funcionar. Não é possível evocar outra Armadilha a menos de 10 metros; ambas se desfazem. Materiais: uma moeda de ouro por dificuldade do efeito.", "niveis": {"1": "Dura 10 dias; armazena até 5 pontos de Karma.", "2": "Dura 20 dias; armazena até 10 pontos de Karma.", "3": "Dura 1 mês; armazena até 15 pontos de Karma.", "4": "Dura 2 meses; armazena até 15 pontos de Karma.", "6": "Dura 5 meses; armazena até 20 pontos de Karma.", "8": "Dura 1 ano e 1 dia; armazena até 35 pontos de Karma.", "10": "Permanente; armazena até 50 pontos de Karma."}},
  "Elemental da Terra": {
    pagina: 76,
    geral: "Ritual que convoca um elemental da Terra, exigindo solo firme e terra suficiente a até cinco metros. Não deve ser realizado em recinto fechado, pois a chegada pode danificar estruturas. O elemental aceita missões após negociação com sacrifício de rubi e Persuasão Rotineira; se não houver acordo, pode ser compelido caso falhe em Resistência à Magia. Se resistir, retorna ao plano depois de cinco rodadas, durante as quais pode atacar o evocador. Ao concluir as missões ou terminar a duração, retorna ao seu plano. Materiais do ritual custam cinco moedas de prata além do rubi.",
    niveis: {1:"Elemental Menor da Terra durante um dia; rubi de uma moeda de ouro.",3:"Elemental da Terra fraco durante um dia; rubi de três moedas de ouro.",5:"Elemental da Terra médio durante um dia; rubi de cinco moedas de ouro.",7:"Elemental da Terra médio durante cinco dias; rubi de sete moedas de ouro.",9:"Elemental da Terra forte durante cinco dias; rubi de nove moedas de ouro."}
  },
  "Elo Animal": {
    pagina: "76–77",
    geral: "Forma elo empático com animal sem capacidade mágica, apenas em ambiente natural. O animal tem direito a Resistência à Magia; se resistir, jamais poderá ser afetado novamente por este encanto. O elo permite transmitir ordens e receber sensações simples, sem ultrapassar a capacidade natural do animal; a comunicação é rudimentar, de até quatro palavras por conceito. A magia pode criar até três elos permanentes; se o animal morrer, o elo permanente não pode ser dissolvido. Após a morte de animal aliado, o evocador fica atordoado três horas e não pode criar novas alianças por um ano. Obrigar animal a sacrificar-se ou trair os melhores interesses de sua espécie é infração grave a critério do Mestre. No efeito 10, todos os pequenos mamíferos e aves de uma mata, dentro de cinco quilômetros, comunicam ao evocador o que percebem; o evocador precisa ter vivido na região por pelo menos três meses.",
    niveis: {1:"Aliança com um animal de Estágio 1; evocação de dez rodadas; duração de 24 horas.",2:"Aliança com animal de Estágio até 3; evocação de dez rodadas, toque, duração de três dias.",3:"Permite perceber com os sentidos de um animal aliado; evocação de uma rodada, toque, duração de vinte rodadas.",4:"Aliança permanente com animal de Estágio até 3; ritual de toque, custo de três moedas de ouro.",5:"Aliança com animal de Estágio até 6; evocação de dez rodadas, toque, duração de seis dias.",6:"Permite perceber com os sentidos de um animal aliado; evocação de uma rodada, toque, duração de três horas.",7:"Aliança permanente com animal de Estágio até 6; ritual de toque, custo de sete moedas de ouro.",8:"Aliança com animal de Estágio até 9; evocação de dez rodadas, toque, duração de 24 horas.",9:"Aliança permanente com animal de Estágio até 9; ritual de toque, custo de quinze moedas de ouro.",10:"Aliança permanente com pequenos mamíferos e aves de uma mata num raio de cinco quilômetros; ritual; custo de quinze moedas de ouro; aliança automática, sem Resistência à Magia."}
  },
  "Empatia": {
    pagina: 77,
    geral: "Cria elo empático com seres a até dez metros, durante uma hora, com evocação de uma rodada. O alvo pode fazer Resistência à Magia. Se resistir, o evocador não consegue perceber nem alterar seus sentimentos e fica extremamente maldisposto em relação ao evocador, com consequências sociais descritas no livro. Quando apenas percebe sentimentos, o evocador ganha redução de um nível de dificuldade em Persuasão e Comércio e ajuste de +5 em Liderança; quando também os manipula, a redução é de dois níveis e o ajuste de Liderança é +10. Os sentimentos só podem ser percebidos ou modificados enquanto a vítima estiver no alcance; os alvos são escolhidos na evocação e não podem ser trocados depois.",
    niveis: {1:"Percebe sentimentos de uma pessoa.",3:"Percebe sentimentos de três pessoas.",5:"Percebe e influencia sentimentos de uma pessoa.",7:"Percebe e influencia sentimentos de três pessoas.",9:"Percebe e influencia sentimentos de sete pessoas."}
  },
  "Domínio": {
    pagina: 74,
    geral: "Controla elementais que falhem em Resistência à Magia, por 24 horas, com alcance de 30 metros e evocação de uma rodada. Cada efeito limita a soma dos Estágios e a categoria máxima dos elementais; criaturas mais fortes não contam no limite porque não são afetadas. Elementais que resistam tendem a atacar o evocador. Os dominados obedecem sem exigir concentração.",
    niveis: {1:"Até 3 Estágios de elementais menores.",3:"Até 8 Estágios de elementais fracos ou menores.",5:"Até 15 Estágios de elementais médios ou menores.",7:"Até 25 Estágios de elementais médios ou menores.",9:"Até 35 Estágios de elementais fortes ou menores."}
  },
  "Domínio Demoníaco": {
    pagina: 74,
    geral: "Evocação de dez rodadas, alcance de dez metros e duração variável. Obriga um demônio a servir ou executar uma tarefa, por negociação e pagamento ou por Resistência à Magia. Servidão dura um ano e um dia, com obediência contínua e limite de três demônios; serviço é uma tarefa determinada, com prazo de até uma semana antes do retorno aos planos infernais, e limite de dez demônios. Pagamento negociado usa Persuasão; sem acordo, a resistência decide. Demônios podem explorar ambiguidades das ordens.",
    niveis: {1:"Demônio de Tipo I ou mais fraco executa um serviço.",2:"Demônio Menor fica em servidão.",3:"Demônio de Tipo II executa um serviço.",5:"Demônio de Tipo I fica em servidão.",7:"Demônio de Tipo III executa um serviço.",9:"Demônio de Tipo II fica em servidão."}
  },
  "Elemental da Água": {
    pagina: "74–75",
    geral: "Ritual que convoca elemental da água para uma ou mais missões, exigindo quantidade proporcional de água a até cinco metros. O elemental aparece onde o evocador escolher dentro desse limite. Pode-se oferecer rubi para tentar obter cooperação mediante Persuasão Rotineira; sem acordo, a criatura faz Resistência à Magia e, se resistir, retorna ao plano após cinco rodadas hostis. Duração conforme efeito; ao terminar a missão ou duração, retorna ao plano. Materiais adicionais custam cinco moedas de prata.",
    niveis: {1:"Elemental Menor da Água por um dia; rubi de uma moeda de ouro.",3:"Elemental da Água fraco por um dia; rubi de três moedas de ouro.",5:"Elemental da Água médio por um dia; rubi de cinco moedas de ouro.",7:"Elemental da Água médio por cinco dias; rubi de sete moedas de ouro.",9:"Elemental da Água forte por cinco dias; rubi de nove moedas de ouro."}
  },
  "Elemental do Ar": {
    pagina: 75,
    geral: "Ritual de convocação de elemental do ar, realizado ao ar livre. A criatura aparece a até cinco metros do evocador e pode aceitar missões por persuasão mediante oferta de diamante, ou ser compelida após falhar em Resistência à Magia. Se resistir, retorna ao plano após cinco rodadas hostis. Ao encerrar as missões ou a duração, retorna ao plano. Materiais adicionais custam cinco moedas de prata.",
    niveis: {1:"Elemental Menor do Ar por um dia; diamante de uma moeda de ouro.",3:"Elemental do Ar fraco por um dia; diamante de três moedas de ouro.",5:"Elemental do Ar médio por um dia; diamante de cinco moedas de ouro.",7:"Elemental do Ar médio por cinco dias; diamante de sete moedas de ouro.",9:"Elemental do Ar forte por cinco dias; diamante de nove moedas de ouro."}
  },
  "Elemental do Fogo": {
    pagina: 75,
    geral: "Ritual que requer fogo proporcional à força do elemental, a até cinco metros do evocador. A criatura aparece no local escolhido, pode ser persuadida a servir com oferta de rubi e teste Rotineiro de Persuasão, ou compelida mediante Resistência à Magia. Se resistir, permanece hostil durante cinco rodadas antes de retornar ao plano. Retorna também ao completar a missão ou duração. Materiais adicionais custam cinco moedas de prata.",
    niveis: {1:"Elemental Menor do Fogo por um dia; rubi de uma moeda de ouro.",3:"Elemental do Fogo fraco por um dia; rubi de três moedas de ouro.",5:"Elemental do Fogo médio por um dia; rubi de cinco moedas de ouro.",7:"Elemental do Fogo médio por cinco dias; rubi de sete moedas de ouro.",9:"Elemental do Fogo forte por cinco dias; rubi de nove moedas de ouro."}
  },

  "Degeneração Física": {
    pagina: 72,
    geral: "Praga usada como punição. Se a vítima falhar na Resistência à Magia, sofre penalidades nas habilidades e no combate pelo período determinado; o efeito mais fraco causa sintomas sem penalidade prática.",
    niveis: {1:"Tremores, tosse, irritações ou coceira por 10 rodadas; não impõe penalidade prática.",3:"Uma ferida profunda impede a ação durante a primeira rodada; depois aplica -2 colunas durante um dia.",5:"Como o efeito 3, mas aplica -4 colunas durante cinco dias.",7:"Como o efeito 3, mas aplica -7 colunas durante uma semana.",9:"A vítima perde a ação durante uma rodada, sofre 5 pontos de dano na EF e -7 colunas; precisa de uma semana de repouso total para se curar, caso contrário o efeito dura um mês."}
  },
  "Desintegração": {
    pagina: 72,
    geral: "Desfaz a coesão da matéria, convertendo-a em poeira. Auras de seres vivos dificultam o efeito; criaturas têm Resistência à Magia para escapar. Minerais e vegetais não têm esse direito. Para atingir uma criatura inteira, o efeito deve alcançar toda a sua aura; objetos podem ser destruídos em partes.",
    niveis: {1:"Desintegra mineral de até 10 × 10 × 10 cm.",2:"Desintegra mineral de até 50 × 50 × 50 cm.",4:"Desintegra mineral de até 1 × 1 × 1 m ou vegetal de até 10 × 10 × 10 cm.",6:"Desintegra mineral de até 2 × 2 × 2 m ou vegetal de até 50 × 50 × 50 cm.",8:"Desintegra mineral de até 3 × 3 × 3 m, vegetal de até 1 × 1 × 1 m ou animal de até 20 × 20 × 20 cm.",10:"Desintegra mineral de até 4 × 4 × 4 m, vegetal de até 2 × 2 × 2 m ou animal de até 60 × 60 × 60 cm."}
  },
  "Despistamento": {
    pagina: "72–73",
    geral: "Apaga ou disfarça os rastros do evocador e/ou companheiros, dificultando a habilidade Seguir Trilhas de perseguidores. Funciona apenas em ambiente natural e dura três horas.",
    niveis: {1:"Afeta uma pessoa e impõe -1 nível de dificuldade a quem segue seus rastros.",2:"Afeta cinco pessoas, com -1 nível de dificuldade.",3:"Afeta uma pessoa, com -2 níveis de dificuldade.",5:"Afeta cinco pessoas, com -2 níveis de dificuldade.",6:"Afeta oito pessoas, com -2 níveis de dificuldade.",7:"Afeta três pessoas, com -3 níveis de dificuldade.",8:"Afeta uma pessoa, com -4 níveis de dificuldade.",10:"Impossibilita rastrear o evocador."}
  },
  "Detecção de Magia": {
    pagina: 73,
    geral: "Permite enxergar o brilho de auras de objetos ou locais sob magia, mas não identifica natureza, força ou origem do encantamento. É preciso linha de visão; uma área inteira afetada pode brilhar uniformemente e impedir distinguir um objeto específico.",
    niveis: {1:"Detecta magia em um objeto ou local tocado.",2:"Detecta magia em objeto ou local a até 1 metro.",3:"Detecta magia em objeto ou local a até 5 metros.",4:"Detecta magia numa área circular de 2 metros de raio centrada no evocador.",6:"Detecta magia numa área circular de 4 metros de raio cujo centro pode ficar a até 5 metros do evocador."}
  },
  "Detecções": {
    pagina: 73,
    geral: "Revela ao evocador indícios de mal ou intenções, apresentados mentalmente. A magia tem alcance de 10 metros e duração de três rodadas. Nos efeitos que investigam intenções ou mentiras, o indivíduo pode tentar Resistência à Magia para ocultar as informações.",
    niveis: {1:"Revela presença de mal concentrado num local, sem identificar origem ou natureza.",2:"Indica presença de demônios na área e sua direção geral.",3:"Indica presença, direção geral e quantidade aproximada de mortos-vivos: poucos (até 5), média (6 a 10) ou muitos (mais de 10).",5:"Leitura de aura de criatura inteligente revela intenções, salvo Resistência à Magia bem-sucedida.",8:"Leitura de aura detecta mentiras, salvo Resistência à Magia bem-sucedida.",10:"Revela falsidades e mentiras na área de efeito, exceto das pessoas que resistirem à magia."}
  },
  "Doenças": {
    pagina: 73,
    geral: "Infecta uma vítima com doença já em estágio avançado, se falhar na Resistência à Magia. A doença não se transmite por contágio. O tempo de cura começa na falha da resistência, e a magia não permite remover a doença simplesmente desfazendo o encantamento. Todos os ajustes são recebidos imediatamente.",
    niveis: {1:"Conjuntivite: -2 colunas em testes de Percepção visual e ataques de projéteis; cura em três dias.",3:"Gripe: -3 em combate e habilidades de esforço físico; cura em sete dias.",5:"Hemofilia: após dano na EF, perde mais 1 EF por rodada até morrer ou o sangramento ser estancado com Curas Físicas; cura em dez dias.",7:"Febre alta e perda de coordenação: -7 em combates, habilidades e feitiços; cura em sete dias.",10:"Febre amarela: impede esforço físico e tarefas delicadas; cura em duas semanas. Sem tratamento até dois dias após contaminação, agrava-se e exige Resistência Física contra força de ataque 10; falha causa morte."}
  },
  "Controle Climático": {
    pagina: 70,
    geral: "Altera gradualmente as condições meteorológicas numa área de raio de 10 km durante uma hora, sem criar condições incompatíveis com o clima local. A sequência de estados vai de tornado a tempestade, chuva, muito nublado, normal, céu limpo, calor seco, seca menor e seca maior. O efeito termina e o clima retoma suas tendências; só pode ser usado uma vez por dia no mesmo local.",
    niveis: {1:"Prevê o tempo dos próximos dois dias, sem alterá-lo.",3:"Altera o tempo local em um passo na escala descrita.",5:"Altera o tempo local em dois passos.",7:"Altera o tempo local em três passos.",9:"Altera o tempo local em quatro passos."}
  },
  "Controle da Voz": {
    pagina: 70,
    geral: "O bardo aperfeiçoa o controle da própria voz, recebendo redução do nível de dificuldade em testes da habilidade Canto durante 20 rodadas. É necessário possuir a habilidade Canto para se beneficiar.",
    niveis: {1:"Reduz em 1 o nível de dificuldade do teste de Canto.",2:"Reduz em 2 níveis a dificuldade do teste de Canto.",3:"Reduz em 3 níveis a dificuldade do teste de Canto.",4:"Reduz em 4 níveis a dificuldade do teste de Canto.",5:"Reduz em 5 níveis a dificuldade do teste de Canto, ou transforma um uso Impossível em Muito Difícil."}
  },
  "Convocação": {
    pagina: "70–71",
    geral: "Milagre que mobiliza pessoas da mesma religião do sacerdote em apoio à sua causa. O alcance, o tempo de evocação e a duração dependem do efeito. Pessoas ocupadas em funções essenciais, como médicos atendendo ou guerreiros em combate, não são convocadas automaticamente. Pode haver Resistência à Magia, embora fiéis normalmente não tentem resistir.",
    niveis: {1:"Torna a causa do sacerdote clara e desperta simpatia em fiéis a até 10 metros; evocação e duração instantâneas.",2:"Permite solicitar pequenos favores sem pagamento aos fiéis próximos, até 5 metros; evocação instantânea e duração de um dia.",4:"Convoca até cinco pessoas aptas a lutar a menos de 1 km; evocação de 10 rodadas e duração de um dia.",6:"Convoca até dez pessoas aptas a lutar a até 2 km; evocação de 20 rodadas e duração de três dias.",8:"Convoca até vinte pessoas a até 5 km; evocação de 10 minutos e duração de uma semana.",10:"Convoca até cinquenta pessoas a até 10 km; evocação de uma hora e duração de um mês."}
  },
  "Corrente": {
    pagina: 71,
    geral: "Força mágica que paralisa vítimas a até 30 metros caso falhem na Resistência à Magia. O alvo permanece consciente do que ocorre, mas fica imóvel, como uma estátua. A duração varia conforme o efeito.",
    niveis: {1:"Paralisa um ser durante uma rodada.",2:"Paralisa um ser durante três rodadas.",4:"Paralisa um ser durante dez rodadas.",6:"Paralisa dois seres durante dez rodadas.",9:"Paralisa três seres durante dez rodadas."}
  },
  "Covardia": {
    pagina: 71,
    geral: "Magia de alcance de 50 metros que retira coragem e Energia Heroica (EH) de uma vítima caso ela falhe na Resistência à Magia. Se a EH chegar a zero por causa do efeito, o alvo foge apavorado por cinco rodadas. Se já não possuir EH, a fuga só ocorre se falhar na resistência.",
    niveis: {1:"Provoca perda de 4 pontos de EH.",2:"Provoca perda de 10 pontos de EH.",3:"Provoca perda de 20 pontos de EH.",5:"Provoca perda de 50 pontos de EH.",8:"Provoca perda de 65 pontos de EH.",10:"Provoca perda de 85 pontos de EH."}
  },
  "Criação": {
    pagina: 71,
    geral: "Ritual necromântico que cria um morto-vivo a partir de cadáver relativamente preservado de uma das raças civilizadas, morto há menos de três dias. A criatura é independente e pode voltar-se contra seu criador; a magia Controle é necessária para dominá-la. Alcance de cinco metros e duração permanente; pode ser evocada em conjunto com Controle.",
    niveis: {1:"Cria um Esqueleto; ritual custa duas moedas de prata.",2:"Cria um Zumbi; ritual custa três moedas de prata.",4:"Cria um Zumbi Consciente; ritual custa uma moeda de ouro.",6:"Cria um Carniçal; ritual custa duas moedas de ouro.",8:"Cria um Espectro Menor; ritual custa cinco moedas de ouro.",10:"Cria um Espectro Maior; ritual custa dez moedas de ouro."}
  },
  "Curas Espirituais": {
    pagina: 71,
    geral: "Milagre de toque e evocação instantânea que recupera imediatamente pontos de Energia Heroica (EH). A EH excedente ao máximo do alvo é perdida. No efeito 8, também pode expulsar espírito que esteja possuindo o alvo, sujeito à Resistência à Magia do espírito.",
    niveis: {1:"Recupera 6 pontos de EH.",2:"Recupera 14 pontos de EH.",4:"Recupera 30 pontos de EH.",6:"Recupera 50 pontos de EH.",8:"Recupera 75 pontos de EH e tenta expulsar espírito possessor; o espírito pode resistir.",10:"Recupera 100 pontos de EH."}
  },
  "Curas Físicas": {
    pagina: 71,
    geral: "Milagre de toque que restaura imediatamente dano à Energia Física (EF), sem ultrapassar a EF máxima do alvo. Evocação instantânea e duração permanente.",
    niveis: {1:"Restaura 2 pontos de EF.",3:"Restaura 7 pontos de EF.",5:"Restaura 12 pontos de EF.",7:"Restaura 25 pontos de EF.",9:"Restaura 45 pontos de EF."}
  },
  "Contatos": {
    pagina: 69,
    geral: "Ritual ou evocação de consulta a uma entidade poderosa sobre fatos do passado ou do presente. As respostas podem ser imprecisas, recusadas ou afetadas por ocultação mágica. O primeiro efeito é instantâneo; os demais são rituais. A resposta costuma levar uma ou duas rodadas, e perguntas equivalentes tendem a obter respostas equivalentes.",
    niveis: {
      1: "Recebe uma intuição geral sobre assunto expresso em até duas palavras. Não controla o conteúdo exato da intuição; evocação instantânea.",
      3: "Obtém resposta sim ou não a pergunta de até quatro palavras; ritual de 10 moedas de ouro.",
      5: "Obtém resposta de uma palavra a pergunta livremente formulada; ritual de 18 moedas de ouro.",
      7: "Obtém resposta de até quatro palavras a pergunta de até seis palavras; ritual de 23 moedas de ouro.",
      9: "Obtém resposta de até sete palavras a pergunta de até oito palavras; ritual de 30 moedas de ouro."
    }
  },
  "Contatos Mentais": {
    pagina: 69,
    geral: "Estabelece comunicação mental com pessoas ou, em efeitos superiores, leitura de pensamentos e implantação de sugestão. Os efeitos de comunicação descritos exigem participação voluntária; a leitura mental do efeito 7 permite Resistência à Magia da vítima. O efeito 9 restringe a sugestão a ações que não coloquem a vítima claramente em perigo.",
    niveis: {
      1: "Transmite pensamentos em uma rodada a uma pessoa disposta a recebê-los, até 20 metros.",
      3: "Permite comunicação mental voluntária entre várias pessoas a até 10 metros do evocador durante cinco rodadas.",
      5: "Como o efeito 3, mas com alcance de 50 metros e duração de dez rodadas.",
      7: "Permite ler a mente de um indivíduo por cinco rodadas, até 20 metros; a vítima pode resistir por Resistência à Magia.",
      9: "Como o efeito 7 e também implanta uma sugestão que não coloque a vítima em perigo evidente."
    }
  },
  "Armadura Elemental": {
    pagina: 66,
    geral: "Proteção pessoal contra dano de ataques elementais, incluindo calor, frio e descargas elétricas. O encantamento absorve uma quantidade limitada de dano antes de se desfazer; se a duração terminar, a proteção remanescente desaparece. Não protege de todos os tipos de ataque.",
    niveis: {1:"Absorve até 6 pontos de dano elemental.",3:"Absorve até 12 pontos de dano elemental.",6:"Absorve até 20 pontos de dano elemental.",8:"Absorve até 30 pontos de dano elemental.",10:"Absorve até 40 pontos de dano elemental."}
  },
  "Bola de Fogo": {
    pagina: 67,
    geral: "Projétil explosivo de fogo lançado da mão do evocador na direção de um alvo. O ataque é resolvido pela regra de ataque mágico físico indicada no capítulo V, e a explosão pode alcançar outras criaturas na área. O dano listado é máximo, não automático.",
    niveis: {1:"Dano máximo 12; raio de 1 metro.",2:"Dano máximo 16; raio de 2 metros.",3:"Dano máximo 20; raio de 4 metros.",5:"Dano máximo 28; raio de 6 metros.",7:"Dano máximo 32; raio de 10 metros.",9:"Dano máximo 36; raio de 10 metros."}
  },
  "Camuflagem": {
    pagina: 67,
    geral: "O rastreador usa o ambiente natural para dificultar a detecção própria ou de companheiros próximos. Exige ar livre e ambiente natural; termina para um alvo que se mova, ataque ou utilize magia. O efeito 10 também impede detecção mágica enquanto o rastreador permanecer sob seu efeito.",
    niveis: {1:"Reduz em 1 nível de dificuldade a rolagem de Ações Furtivas de uma pessoa.",3:"Reduz em 1 nível a dificuldade de Ações Furtivas de até três pessoas.",4:"Reduz em 2 níveis a dificuldade de Ações Furtivas de uma pessoa.",6:"Reduz em 2 níveis a dificuldade de Ações Furtivas de até três pessoas.",8:"Reduz em 3 níveis a dificuldade de Ações Furtivas de uma pessoa.",10:"Reduz em 5 níveis a dificuldade de Ações Furtivas do rastreador, que não pode ser detectado por meios mágicos enquanto o efeito perdurar."}
  },
  "Canção de Ânimo": {
    pagina: 67,
    geral: "Canção de bardo que encoraja aliados. Os níveis menores melhoram o ajuste na coluna de ataque; os maiores também concedem EH temporária, que pode ultrapassar o máximo normal, mas desaparece ao fim do encanto. O bônus de ataque não se acumula com o ajuste já existente: usa-se o resultado pertinente à resolução.",
    niveis: {1:"Até uma pessoa recebe +3 na coluna de ataque.",3:"Até duas pessoas recebem +3 na coluna de ataque.",5:"Até seis pessoas recebem +3 na coluna de ataque.",6:"Uma pessoa recebe +5 EH e +5 na coluna de ataque.",8:"Até duas pessoas recebem +5 EH e +5 na coluna de ataque.",10:"Até seis pessoas recebem +5 EH e +5 na coluna de ataque."}
  },
  "Canções de Sono": {
    pagina: 68,
    geral: "O bardo entoa uma melodia que provoca sonolência ou sono. Salvo indicação diversa no efeito, dura até 20 rodadas ou enquanto o bardo continuar concentrado e cantando, o que for maior; se as vítimas saírem do alcance ou da linha de visão, o efeito persiste apenas até o fim da duração aplicável. Um golpe que cause dor pode despertar uma vítima adormecida.",
    niveis: {1:"Uma vítima fica sonolenta e sofre -5 em Percepções.",2:"Até três vítimas ficam sonolentas e sofrem -5 em Percepções.",3:"Uma pessoa adormece.",5:"Duas pessoas adormecem.",6:"Uma pessoa adormece e só acorda quando a magia é anulada ou termina.",7:"Três pessoas adormecem.",9:"Três pessoas adormecem e só acordam quando a magia é anulada ou termina.",10:"Uma vítima cai em sono profundo permanente, do qual não pode ser despertada normalmente."}
  },
  "Círculo de Proteção": {
    pagina: 68,
    geral: "Círculo previamente desenhado ou entalhado no solo que barra a entrada de mortos-vivos e criaturas extraplanares abrangidos pelo efeito. Cada criatura afetada tem direito a Resistência à Magia; em caso de sucesso, ignora o círculo por uma hora. Quem já estiver dentro quando a magia for lançada não é afetado imediatamente, mas não poderá voltar a entrar após sair. Preparar o círculo demanda tempo e materiais, e danificar qualquer parte compromete sua integridade.",
    niveis: {1:"Barra criaturas de estágio 1 ou menor durante 1 hora.",2:"Barra criaturas de estágio 3 ou menor durante 3 horas.",4:"Barra criaturas de estágio 5 ou menor durante 13 horas.",6:"Barra criaturas de estágio 7 ou menor durante 7 dias.",8:"Barra criaturas de estágio 10 ou menor durante 1 ano e 1 dia.",10:"Barra criaturas de estágio 15 ou menor durante 13 anos."}
  },

  "Amizade": {
    pagina: 65,
    geral: "Encantamento que torna a vítima receptiva às ideias do evocador se ela falhar na Resistência à Magia. A força do efeito determina quanto sua personalidade e suas obrigações são subordinadas ao encanto. A descrição impressa observa que o comportamento posterior pode variar e que o alvo pode retaliar ao fim do efeito.",
    niveis: {
      1: "A vítima passa a sentir simpatia pelo evocador e pode atender a um pedido pequeno e razoável. Dura até o favor ser realizado; o alvo não sabe que foi encantado.",
      2: "A vítima passa a considerar o evocador um bom amigo e atende a seus desejos, desde que não contrariem muito sua índole ou deveres. Duração: uma hora.",
      4: "Como o efeito 2, mas o alvo pode agir de maneira prejudicial a si próprio, desde que não se mate.",
      6: "Como o efeito 4, com duração de uma semana.",
      8: "Como o efeito 6, mas a vítima despreza seus deveres para auxiliar o evocador.",
      10: "Como o efeito 8, com duração de um mês."
    }
  },
  "Análise": {
    pagina: 65,
    geral: "Ritual de toque para identificar propriedades mágicas de um objeto. O evocador reconhece imediatamente se o objeto não é mágico. Quando há várias propriedades, elas são descobertas em sequência, determinadas pelo Mestre; o ritual não revela quais propriedades ainda restam desconhecidas. Cada dificuldade do efeito custa cinco moedas de prata em materiais raros.",
    niveis: {
      1: "Identifica se o objeto é mágico.",
      4: "Determina uma propriedade mágica do objeto.",
      7: "Determina duas propriedades mágicas do objeto.",
      10: "Determina três propriedades mágicas do objeto."
    }
  },
  "Apelo": {
    pagina: 65,
    geral: "Milagre sacerdotal que pede auxílio à divindade por meio de um enviado. Em geral o enviado permanece 30 rodadas; nos efeitos 6 e 9, rituais, o enviado permanece ajudando o sacerdote. O ritual temporário leva uma rodada, enquanto o permanente exige ritual; se o enviado morrer ou a duração terminar, retorna ao plano de seu mestre.",
    niveis: {
      1: "Conjura um enviado menor.",
      3: "Conjura um enviado do tipo I.",
      5: "Conjura um enviado do tipo II.",
      6: "Ritual de custo 30 moedas de ouro que vincula permanentemente um enviado do tipo I ao serviço do evocador, até a morte do enviado ou do evocador.",
      7: "Conjura um enviado do tipo III.",
      9: "Como o efeito 6, mas vincula um enviado do tipo II e custa 50 moedas de ouro."
    }
  },
  "Empatia Animal": {pagina: "77–78", geral: "Permite comunicar emoções, ordens simples ou sugestões a animais de inteligência animal sem capacidade mágica. O animal pode resistir à magia. Não obriga o animal a agir contra a própria natureza; atacar um animal afetado desfaz imediatamente o efeito. Comunicação admite conceitos simples; sugestões duram enquanto o animal estiver sujeito à ordem.", niveis: {1:"Um animal não ataca o evocador durante 10 rodadas.",3:"Comunicação com um animal durante 10 rodadas.",4:"Uma sugestão a um animal durante 10 rodadas.",5:"Até dez animais não atacam o evocador e seus acompanhantes durante 20 rodadas.",6:"Comunicação com uma espécie de animais durante 6 horas.",7:"Uma sugestão a um animal durante 10 horas."}},
  "Energia Infernal": {pagina: 78, geral: "Libera energia infernal numa área imediatamente à frente do evocador, com 3 metros de largura e 15 metros de comprimento. Produz queimaduras extremamente dolorosas e cicatrizes; é nociva à vida. Os números de dano abaixo são os valores apresentados no livro; sua resolução deve respeitar as regras de ataque aplicáveis.", niveis: {1:"Causa 12 pontos de dano.",2:"Causa 16 pontos de dano.",3:"Causa 20 pontos de dano.",5:"Causa 28 pontos de dano.",7:"Causa 32 pontos de dano.",9:"Causa 36 pontos de dano."}},
  "Escalar Superfícies": {pagina: 78, geral: "Auxilia um Rastreador em Escalar Superfícies. Requer ao menos nível 1 nessa habilidade e não pode ser usado quando carrega mais que um terço do próprio peso. Funciona fora do ambiente natural. Reduz a dificuldade do teste; no efeito 9 transforma Impossível em Muito Difícil.", niveis: {1:"Reduz em um nível a dificuldade.",3:"Reduz em dois níveis a dificuldade.",5:"Reduz em três níveis a dificuldade.",7:"Reduz em quatro níveis a dificuldade.",9:"Reduz em cinco níveis a dificuldade e torna Muito Difícil uma tentativa Impossível."}},
  "Escárnio": {pagina: 78, geral: "Canção ou narrativa depreciativa do Bardo que penaliza rolagens de Persuasão de quem falhar na Resistência à Magia. O Bardo deve poder ver todas as vítimas; escolhe quem não é afetado se houver mais pessoas que o máximo do efeito. Dura quatro semanas.", niveis: {1:"Penalidade de +1 nível de dificuldade em Persuasão para até 10 pessoas.",3:"+1 nível de dificuldade para até 30 pessoas.",4:"+2 níveis de dificuldade para até 15 pessoas.",7:"+2 níveis de dificuldade para até 50 pessoas.",8:"+3 níveis de dificuldade para até 20 pessoas.",10:"+3 níveis de dificuldade para até 100 pessoas."}},
  "Esconjuração": {pagina: 78, geral: "Milagre contra mortos-vivos e demônios a até 100 metros, desde que o evocador os veja. Os afetados que falham na Resistência à Magia fogem imediatamente. Somam-se os Estágios dos oponentes a partir dos mais fracos até esgotar o limite do efeito; uma criatura não pode ser parcialmente afetada. Alguns efeitos destroem criaturas de Estágio baixo.", niveis: {1:"Expulsa até 3 Estágios.",2:"Expulsa até 5 Estágios.",3:"Expulsa até 10 Estágios.",5:"Expulsa até 20 Estágios.",7:"Expulsa até 30 Estágios; criaturas de Estágio 3 ou menor, em vez de expulsas, são destruídas.",9:"Expulsa até 60 Estágios e destrói criaturas de Estágio 5 ou menor."}},
  "Escuridão": {pagina: 79, geral: "Cria volume esférico imóvel de escuridão parcial ou total, com raio escolhido pelo evocador até o limite do efeito. Escuridão parcial impõe ajustes de Cegueira Parcial; total impõe Cegueira Total, inclusive a quem normalmente enxerga no escuro. Pode ser lançada sobre uma criatura; nesse caso, a Resistência à Magia determina se o volume acompanha a vítima, e sucesso impede o efeito.", niveis: {1:"Escuridão parcial; raio até 1 metro; duração até 10 rodadas.",3:"Escuridão parcial; raio até 3 metros; duração até 30 rodadas.",4:"Escuridão total; raio até 1 metro; duração até 10 rodadas.",5:"Escuridão parcial; raio até 10 metros; duração até 10 minutos.",6:"Escuridão total; raio até 3 metros; duração até 30 rodadas.",7:"Escuridão parcial; raio até 50 metros; duração até uma hora.",8:"Escuridão total; raio até 10 metros; duração até 10 minutos.",9:"Escuridão parcial; raio até 300 metros; duração até 10 horas.",10:"Escuridão total; raio até 30 metros; duração até uma hora."}},
  "Fanatismo": {pagina: 79, geral: "Milagre que aumenta o moral de até 100 indivíduos que lutam pela causa da divindade. Evocação de 10 rodadas, alcance de 100 metros e duração de 12 horas. Aumenta as colunas de moral conforme o nível.", niveis: {1:"Aumenta o moral em 2 colunas.",3:"Aumenta o moral em 5 colunas.",5:"Aumenta o moral em 9 colunas.",7:"Aumenta o moral em 12 colunas."}}
  ,"Geomanipulação": {pagina:"79–80",geral:"Manipula terra e pedra, nunca metal, a até 20 metros por até 10 rodadas. O evocador determina a forma sem criar matéria e precisa manter concentração. Ao terminar, a matéria volta a comportar-se fisicamente; estruturas inviáveis desabam. Contato do material com a aura de uma criatura encerra o encanto imediatamente.",niveis:{1:"Molda até 4 metros cúbicos.",2:"Molda até 10 metros cúbicos.",4:"Molda até 25 metros cúbicos.",6:"Molda até 35 metros cúbicos.",8:"Molda até 45 metros cúbicos.",10:"Molda até 60 metros cúbicos."}},
  "Geoproteção": {pagina:80,geral:"Protege, por toque, durante até 20 rodadas contra dano à Energia Física ou Heroica causado por minerais sólidos (como pedras e espadas), inclusive quedas e avalanches. Não protege contra materiais vegetais nem minerais líquidos, fogo ou ácidos. O encantamento termina ao atingir sua capacidade máxima de absorção. Aplicações simultâneas não se somam: vale somente a maior proteção.",niveis:{1:"Absorve até 5 pontos de dano.",2:"Absorve até 10 pontos de dano.",4:"Absorve até 15 pontos de dano.",6:"Absorve até 25 pontos de dano.",8:"Absorve até 35 pontos de dano.",10:"Absorve até 50 pontos de dano."}},
  "Hidromanipulação": {pagina:80,geral:"Manipula líquidos a até 15 metros durante 10 rodadas, em volume limitado pelo efeito. Permite erguer ondas, pilares, redemoinhos e buracos em água, sem criar líquido. Líquidos projetados além do alcance voltam ao comportamento normal. Para afogar uma criatura, o evocador deve conseguir carregar seu peso; a vítima pode tentar Natação Difícil a cada rodada para escapar. Após mais de seis rodadas sem respirar, perde a consciência por falta de ar.",niveis:{1:"Manipula até 3 m³ e carrega até 20 kg.",2:"Manipula até 6 m³ e carrega até 40 kg.",4:"Manipula até 15 m³ e carrega até 100 kg.",6:"Manipula até 25 m³ e carrega até 150 kg.",8:"Manipula até 35 m³ e carrega até 250 kg.",10:"Manipula até 50 m³ e carrega até 400 kg."}},
  "Ilusões Materiais": {pagina:"80–81",geral:"Concede pseudomatéria a uma Ilusão Visual ou Imagem, lançada em conjunto, permitindo interação física e potencial dano real à Energia Física se a vítima acreditar nela. A consistência não altera Defesa ou Energia Física da própria ilusão. Contato com ilusão sem este encanto a dissipa; com o encanto, a vítima pode testar Percepção segundo as circunstâncias e a Dificuldade indicada pelo Mestre. A ilusão pode ser destruída por deformação/dano equivalente à EF concedida; quando destruída, desfaz-se toda a composição. Exige concentração para mover a ilusão; fora da concentração, ela fica imóvel. A duração e o alcance acompanham a ilusão vinculada.",niveis:{1:"Concede 2 pontos de EF à ilusão.",2:"Concede 6 pontos de EF à ilusão.",3:"Concede 15 pontos de EF à ilusão.",5:"Concede 25 pontos de EF à ilusão.",7:"Concede 35 pontos de EF à ilusão.",9:"Concede 45 pontos de EF à ilusão.",10:"Concede 55 pontos de EF à ilusão."}}


  ,"Ilusões Visuais": {pagina:"81–82",geral:"Cria uma imagem tridimensional móvel, limitada ao volume e à duração do efeito. Evocação instantânea, alcance de 40 metros. O evocador precisa manter concentração para movimentá-la; se a concentração for interrompida, a imagem para. Desaparece imediatamente se tocada por criatura ou objeto, se o evocador ultrapassar 40 metros de distância ou se o efeito terminar. Pode ser combinada com Ilusão Material, Toque e Som para maior realismo.",niveis:{1:"Cubo de até 1 metro de lado; duração máxima de 5 rodadas.",2:"Cubo de até 1 metro de lado; até 10 rodadas.",3:"Cubo de até 2 metros de lado; até 10 rodadas.",4:"Cubo de até 2 metros de lado; até 15 rodadas.",5:"Cubo de até 3 metros de lado; até 15 rodadas.",6:"Cubo de até 4 metros de lado; até 20 rodadas.",7:"Cubo de até 6 metros de lado; até 20 rodadas.",8:"Cubo de até 12 metros de lado; até 20 rodadas.",10:"Cubo de até 20 metros de lado; até 20 rodadas."}},
  "Imagem": {pagina:82,geral:"Cria uma imagem tridimensional imóvel de objeto ou criatura, sem defesa própria; quando atacada, em geral desaparece, e normalmente se desfaz ao toque. Evocação e duração variam com o efeito; alcance de 50 metros. Pode receber Ilusão Material para ganhar textura e EF. Quando destruída, desfaz-se a composição de encantos; se um efeito de duração permanente for destruído sem que a magia seja dissolvida, a imagem e os efeitos podem se recompor após 24 horas.",niveis:{1:"Evocação de uma rodada; duração de 3 horas; cubo de até 10 metros de lado.",2:"Evocação de uma rodada; duração de 6 horas; cubo de até 10 metros de lado.",4:"Evocação de uma rodada; duração de 6 horas; cubo de até 30 metros de lado.",6:"Evocação de 3 rodadas; duração de 1 dia; cubo de até 45 metros de lado.",8:"Evocação de 3 rodadas; duração de 1 dia; cubo de até 90 metros de lado.",9:"Evocação ritual; duração permanente; cubo de até 10 metros de lado; materiais de 3 moedas de ouro.",10:"Evocação de 3 rodadas; duração de 1 dia; cubo de até 200 metros de lado."}},
  "Invisibilidade": {pagina:82,geral:"Torna invisível opticamente o alvo tocado por 10 minutos; evocação instantânea. O alvo ainda pode ser localizado por odor, ruídos ou rastros. Objetos em contato direto com o beneficiado ficam invisíveis; se largados, tornam-se visíveis. Certos movimentos encerram imediatamente o encanto conforme o efeito.",niveis:{1:"Um objeto pequeno, de no máximo 50 × 50 × 50 centímetros, fica invisível.",2:"Uma criatura fica invisível desde que permaneça completamente parada.",4:"Uma criatura pode se mover, mas movimentos rápidos ou o encanto quebram imediatamente a invisibilidade.",6:"Uma criatura pode se mover, mas um movimento brusco, como atacar ou evocar magia, quebra imediatamente a invisibilidade."}},
  "Ira Divina": {pagina:82,geral:"Ritual sacerdotal de castigo a quem ofendeu o Deus do Sacerdote ou sua causa; duração de uma semana e alcance variável. A magia falha sem motivo justificável. O efeito 7 é reservado a ofensas diretas ao Deus ou perseguição de seus seguidores; o efeito 9 somente a ofensas diretas em gestos ou palavras contra a divindade. Os efeitos de maior alcance podem atingir inocentes e exigem cuidado na escolha.",niveis:{1:"Numa região de 1 km de diâmetro, ocorre uma maré de azar com acidentes menores e desperdício de recursos.",3:"Em até 3 km de diâmetro, surgem superstições, aparições culturais e medo; população e indivíduos normais sem EH recebem ajuste negativo de 3 colunas de moral.",5:"Em até 6 km de diâmetro, há pragas e desastres reais, mas não catastróficos, como insetos, animais inofensivos ou colheitas ruins.",7:"Em até 12 km de diâmetro, acontecem tragédias menores, como tremores fracos, pragas de animais nocivos e doenças leves.",9:"Em até 15 km de diâmetro, ocorrem catástrofes reais, como devastação de lavouras, pestes ou inundações, com risco de atingir inocentes."}}


  ,"Lendas": {pagina:83,geral:"Ritual de toque e uso único que investiga fatos do passado de um objeto ou local. As informações são gerais e podem vir como enigmas ou versos; o objeto ou local deve ter história ou lenda associada, não bastando ter sido esquecido ou fabricado.",niveis:{1:"Informa se existe alguma lenda sobre o objeto examinado.",3:"Revela a impressão emocional mais forte deixada por quem usou o objeto ou frequentou o local, como medo, amor ou ódio.",4:"Informa o nome do local de origem do item, mesmo que esse nome não seja conhecido pelos personagens.",6:"Revela o objetivo geral ao qual o objeto ou local foi dedicado.",8:"Mostra uma visão de acontecimento relevante do passado do objeto ou local; se houver vários, mostra o mais recente, podendo permitir outras visões.",10:"Fornece lendas e histórias associadas ao objeto, sem garantir clareza ou compreensão das narrativas."}},
  "Ler Trilhas": {pagina:83,geral:"Magia pessoal do Rastreador, evocada em cinco rodadas e com duração de uma rodada. Fornece dados sobre rastros em ambientes naturais, sem revelar a direção seguida; para seguir a trilha é necessário Rastreamento. Não funciona para deslocamentos que não deixem rastros, como voo ou teletransporte, nem para rastros com mais de dez dias. As informações dizem respeito ao último grupo que passou pelo local.",niveis:{1:"Indica aproximadamente quantas criaturas passaram e há quanto tempo.",3:"Revela número exato de criaturas, momento da passagem e tipos aproximados.",6:"Revela número, momento e tipos exatos das criaturas que passaram.",8:"Mostra visão do último grupo que passou pelo local. Detalhes exigem teste de Percepção, com dificuldade definida pelo Mestre; se o jogador especificar antes o que busca, recebe +5 colunas na resolução."}}


  ,"Levitação": {pagina:"83–84",geral:"Deslocamento exclusivamente vertical, para cima ou para baixo, limitado a 10 metros por rodada; não permite voo horizontal. Sustenta o evocador e até 50 kg adicionais. O evocador pode se apoiar em paredes, tetos ou árvores para se impulsionar. Não oferece estabilidade contra ventos muito fortes.",niveis:{1:"Paira até um metro acima de superfície líquida ou sólida, por 10 rodadas; exige concentração.",3:"Pode levitar a qualquer altura do solo por 10 minutos, desde que mantenha concentração.",5:"Como o efeito 3, mas dispensa concentração."}},
  "Linguagem": {pagina:84,geral:"Concede temporariamente conhecimento de língua falada que o evocador não dominava, por uma hora. Permite falar e compreender; se o evocador souber ler alguma língua, também poderá ler, mas não escrever, na língua adquirida. Não produz aprendizado permanente.",niveis:{1:"Concede total 1 na língua escolhida.",2:"Concede total 7 na língua escolhida.",4:"Concede total 13 na língua escolhida.",6:"Concede conhecimento infinito da língua escolhida."}},
  "Maldições": {pagina:84,geral:"Encanto maléfico sobre um indivíduo a até 10 metros, com duração variável. Se o alvo falhar na Resistência à Magia, sofre a punição descrita. Os efeitos são variados e o Mestre deve observar o alcance da punição escolhida.",niveis:{1:"Marca permanentemente o corpo com símbolo de amaldiçoado, que pode ser escondido mas não apagado sem quebrar a magia.",2:"Produz alteração física pequena, como aumento do nariz, orelha ou braço, por uma semana; a vítima pode ser alvo de escárnio.",4:"Provoca problema físico ou mental parcial e não violento, como gagueira, cegueira parcial, loucura branda ou perda de memória, por uma hora.",6:"Manipula seres e objetos próximos para dificultar ações da vítima; a vítima e os seres envolvidos têm direito à Resistência à Magia. Dura um mês.",8:"Produz efeito equivalente ao nível 4, mas durante um mês.",10:"Causa deformação física grotesca ou problema mental grave; o efeito é permanente."}},
  "Manipulação de Luz": {pagina:84,geral:"Cria luz ou escuridão em esfera de diâmetro definido, centrada em ponto, objeto ou criatura; se o centro se desloca, a esfera acompanha. Luz forte pode cegar temporariamente, e escuridão é mais difícil de manipular.",niveis:{1:"Luz tênue com 10 metros de diâmetro durante 10 rodadas; não cega.",2:"Reduz a luminosidade numa esfera de 5 metros de diâmetro por 10 rodadas, como noite sem estrelas.",3:"Luz em esfera de 10 metros de diâmetro por 10 minutos; pode cegar o oponente por 2 rodadas.",4:"Escuridão total em esfera de 10 metros de diâmetro por 20 rodadas.",6:"Luz em esfera de 20 metros de diâmetro por uma hora; cega o adversário por 4 rodadas.",8:"Como nível 6, mas por um dia e cegando por 10 rodadas; luz muito forte.",10:"Como nível 8, com 30 metros de diâmetro, duração de um mês e cegueira por 20 rodadas; luz muito forte, capaz de afugentar certos mortos-vivos por 10 rodadas."}},
  "Medo": {pagina:"84–85",geral:"Traz à superfície os medos irracionais das vítimas que falharem em Resistência à Magia. Dura 10 rodadas. As vítimas procuram fugir o máximo possível; se não puderem sair do local, tentam manter a maior distância do evocador.",niveis:{1:"Afeta uma pessoa a até 1 metro.",2:"Afeta uma pessoa a até 10 metros.",4:"Afeta até duas pessoas a até 10 metros.",6:"Afeta até três pessoas a até 10 metros.",8:"Afeta até quatro pessoas a até 15 metros."}},
  "Memorização": {pagina:85,geral:"Memoriza palavras com fidelidade por duas semanas, mesmo sem compreender seu significado. Pode ser usada junto de Leitura e Linguagem e repetida para memorizar textos maiores; nova evocação antes do término renova a duração da memorização.",niveis:{1:"Memoriza até 20 palavras.",2:"Memoriza até 50 palavras.",3:"Memoriza até 150 palavras.",5:"Memoriza até 500 palavras."}},
  "Meteoros": {pagina:85,geral:"Faz cair grandes fragmentos rochosos do ar sobre ponto indicado. Somente pode ser usada ao ar livre. Criaturas na área de impacto podem sofrer dano e críticos de esmagamento, conforme a resolução do ataque. Evocação e duração instantâneas.",niveis:{1:"Dano máximo 12; raio de 1 metro em torno do impacto; alcance de 20 metros.",2:"Dano máximo 16; raio de 1 metro; alcance de 30 metros.",4:"Dano máximo 20; raio de 2 metros; alcance de 40 metros.",6:"Dano máximo 24; raio de 2 metros; alcance de 50 metros.",8:"Dano máximo 28; raio de 3 metros; alcance de 60 metros.",10:"Dano máximo 32; raio de 5 metros; alcance de 75 metros."}},
  "Montar": {pagina:85,geral:"Magia pessoal de evocação instantânea e duração de um uso, que reduz a dificuldade de um teste da habilidade Montar Animais.",niveis:{1:"Reduz a dificuldade em 1 nível.",3:"Reduz a dificuldade em 2 níveis.",5:"Reduz a dificuldade em 3 níveis.",7:"Reduz a dificuldade em 4 níveis.",9:"Reduz a dificuldade em 5 níveis e torna Muito Difícil um teste originalmente Impossível."}},
  "Mutação": {pagina:85,geral:"Permite ao evocador assumir formas diferentes por uma hora. Não modifica sua Energia Heroica ou Energia Física. A forma assumida não concede habilidades não físicas; algumas formas impossibilitam gestos e palavras para evocar magias. Depois de assumir uma forma, ela não pode ser alterada durante o efeito.",niveis:{1:"Altera a aparência como disfarce perfeito, mas não a voz; para copiar pessoa específica, exige pesquisa e contato.",3:"Assume forma de animal entre tamanho de gato e cavalo; objetos carregados não se transformam.",5:"Como nível 3, mas objetos também se transformam, integrando a nova forma.",7:"Assume forma de criatura entre tamanho de formiga e Troll, inclusive criatura mística vista pessoalmente; objetos se transformam.",10:"Como nível 7, mas pode copiar qualquer tipo de criatura, sem restrição de tamanho."}}

  ,"Necroanimação": {pagina:86,geral:"Anima cadáveres de humanos, anões, elfos, meio-elfos e pequeninos como esqueletos ou zumbis, segundo o estado de decomposição decidido pelo Mestre. Conservam estatísticas regulares que tinham em vida, exceto características excepcionais. O evocador controla os mortos-vivos mediante concentração; se a perder, ficam imóveis até recuperá-la. Ao fim da duração, tornam-se pó em uma rodada. O mesmo cadáver não pode ser animado duas vezes, e a duração não pode ser prolongada. Materiais: uma moeda de prata por corpo.",niveis:{1:"Anima 3 corpos durante 1 dia.",2:"Anima 5 corpos durante 3 dias.",4:"Anima 15 corpos durante 10 dias.",6:"Anima 30 corpos durante 15 dias.",8:"Anima 50 corpos durante 1 mês.",10:"Anima 100 corpos durante 2 meses."}},
  "Necroconhecimento": {pagina:86,geral:"Ritual que interroga mortos por intermédio de pelo menos seu crânio, a até 2 metros. O morto deve ter falecido dentro do prazo permitido pelo efeito. Perguntas devem ser feitas em língua que o morto compreendia; ele responde o que considera verdadeiro, mas pode ser obscuro. Perguntas não feitas durante a duração são perdidas; o Mestre mede a duração em tempo real. Materiais: cinco moedas de prata por dificuldade do efeito.",niveis:{1:"Até 1 pergunta, em 3 rodadas (45 segundos); morto há até 24 horas.",3:"Até 2 perguntas, em 6 rodadas (90 segundos); morto há até uma semana.",5:"Até 3 perguntas, em 12 rodadas (3 minutos); morto há até um mês.",7:"Até 5 perguntas, em 20 rodadas (5 minutos); morto há até um ano e um dia.",10:"Até 10 perguntas, em 40 rodadas (10 minutos); morto há até 13 anos."}},
  "Ordens": {pagina:87,geral:"Encantamento instantâneo de alcance 30 metros, que obriga um indivíduo a obedecer a comando se falhar em Resistência à Magia e compreender a ordem. Os efeitos superiores podem impor missões de natureza sagrada, com consequências específicas. A missão deve ser possível de cumprir.",niveis:{1:"Uma ordem de duas palavras, cumprida por uma rodada; não pode ordenar suicídio.",2:"Como efeito 1, mas dura duas rodadas.",4:"Como efeito 1, mas afeta dois oponentes durante três rodadas.",6:"Como efeito 1, mas afeta três indivíduos durante cinco rodadas.",7:"Uma pessoa que siga o Deus do evocador recebe voluntariamente missão sagrada. Durante a missão fica imune a dominação mental e paralisia; se falhar ou desistir, morre imediatamente. Afastar-se por mais de uma semana equivale a desistir. Pecados e maldições são removidos ao término, com êxito ou morte.",10:"Impõe missão possível a qualquer indivíduo. Se falhar ou afastar-se do objetivo, adoece e fica acamado após um dia; persistindo na recusa, morre ao final do segundo dia."}},
  "Paralisia": {pagina:87,geral:"Magia instantânea a até 20 metros, com duração de 30 rodadas. Alvos humanoides fazem Resistência à Magia individualmente; sucesso impede o efeito. A paralisia prejudica apenas músculos voluntários, sem interromper respiração ou batimentos cardíacos. Penalidades aplicam-se às colunas de resolução em combate, habilidades e magia. O evocador escolhe os alvos dentro do alcance, mas não quais músculos serão afetados.",niveis:{1:"Ajuste de -2 nas colunas de resolução de até duas vítimas.",2:"Ajuste de -4 para até duas vítimas.",4:"Ajuste de -4 para até três vítimas.",6:"Ajuste de -7 para até três vítimas.",8:"Ajuste de -8 para uma vítima e impede uso de Energia Heroica.",10:"Paralisa completamente uma vítima, que cai imóvel ao chão até o fim da duração."}}

  ,"Odor": {pagina:"86–87",geral:"Cria, suprime ou modifica odores e sabores numa área, objeto ou criatura; um mesmo objeto ou criatura pode ter odor e sabor afetados de uma só vez. Odores criados se espalham naturalmente. Pode ser combinada com Imagem ou Ilusão Visual.",niveis:{1:"Cria odor muito leve em área de até 10 metros de raio; evocação instantânea, duração 30 rodadas.",3:"Altera um odor numa área de até 10 metros de raio ou num objeto; evocação instantânea, duração 30 rodadas.",5:"Altera todos os odores numa área de até 10 metros de raio, objeto ou criatura; evocação instantânea, duração 1 hora.",7:"Altera todos os odores numa área de até 10 metros de raio, objeto ou criatura; evocação instantânea, duração 24 horas.",10:"Altera um odor em área de até 10 metros de raio, objeto ou criatura; evocação de uma rodada, duração permanente. Requer materiais de 5 moedas de ouro; não pode ser combinado com outros efeitos."}},
  "Pentagrama Místico": {pagina:"87–88",geral:"Energiza pentagrama previamente preparado para prender um morto-vivo ou Demônio que falhe em Resistência à Magia. A criatura pode entrar voluntariamente; apenas uma criatura fica presa por vez. Desenhar o pentagrama requer cerca de seis horas e materiais de 2 moedas de ouro; entalhá-lo leva uma semana e materiais de 5 moedas de ouro. Energizar custa 3 moedas de prata por dificuldade do efeito, inclusive na primeira utilização. Um pentagrama íntegro pode ser reutilizado mediante nova energização; se danificado, perde imediatamente o efeito e não pode ser consertado. Mortos-vivos e Demônios não podem tocar o pentagrama ativo.",niveis:{1:"Aprisiona um ser de Estágio 2 ou inferior durante 13 horas.",2:"Aprisiona um ser de Estágio 4 ou inferior durante 13 horas.",4:"Aprisiona um ser de Estágio 6 ou inferior durante 13 dias.",6:"Aprisiona um ser de Estágio 10 ou inferior durante 13 dias.",8:"Aprisiona um ser de Estágio 15 ou inferior durante 1 ano e 1 dia.",10:"Aprisiona um ser de Estágio 20 ou inferior durante 13 anos."}},
  "Pergunta": {pagina:"88–89",geral:"Ritual pessoal de 10 rodadas que contata um habitante dos planos infernais para obter informação. Pode haver pagamento negociado, exigências ou sacrifícios, a critério do Mestre. Sem pagamento, exige Persuasão Rotineira para obter cooperação; em falha, pode-se tentar forçar resposta mediante Resistência à Magia do Demônio, que responde com má vontade se falhar. O contato pode exigir Resistência à Magia secreta para impedir mentiras. Mesmo uma resposta verdadeira pode ser breve, incompleta ou ambígua.",niveis:{1:"Resposta geral sobre assunto definido em até duas palavras; a entidade oferece uma impressão ou intuição sobre o assunto, sem controle do evocador sobre a resposta.",3:"Responde Sim ou Não a uma pergunta de até quatro palavras; perguntas parecidas produzem respostas iguais.",5:"Como efeito 3, mas a resposta pode ser uma palavra que defina bem a resposta, não apenas Sim ou Não.",7:"Responde a pergunta de até seis palavras com resposta de até quatro palavras.",9:"Responde a pergunta de até oito palavras com resposta de até sete palavras."}},
  "Pesadelo": {pagina:89,geral:"Alvo a até 20 metros faz Resistência à Magia ao ser enfeitiçado. Se falhar, sofre pesadelos aterrorizantes sempre que dorme, sem recuperar Karma ou EH durante o sono. Após a evocação, o alvo pode afastar-se do evocador sem interromper o efeito. A magia termina pelo fim da duração ou por quebra mediante encantos.",niveis:{1:"Duração de 1 dia.",3:"Duração de 3 dias.",5:"Duração de 1 mês.",8:"Duração de 1 ano e 1 dia."}},
  "Piroproteção": {pagina:89,geral:"Concede proteção contra dano por fogo ao alvo tocado. Cada efeito absorve dano até seu limite, de uma só vez: para superar a proteção, um único ataque deve causar mais dano que o valor protegido. Se exceder, a magia se rompe e o dano excedente atinge o alvo normalmente. O dano não se acumula entre ataques; a proteção termina também ao esgotar a duração.",niveis:{1:"Protege contra até 10 pontos de dano por até 10 rodadas.",2:"Protege contra até 15 pontos de dano por até 20 rodadas.",4:"Protege contra até 20 pontos de dano por até 10 minutos.",6:"Protege contra até 25 pontos de dano por até 30 minutos.",8:"Protege contra até 30 pontos de dano por até 1 hora.",10:"Protege contra até 35 pontos de dano por até 2 horas."}},
  "Piromanipulação": {pagina:89,geral:"Manipula o calor e a forma de um fogo existente, podendo criá-lo a partir do efeito 4. Não pode ser evocada para atacar diretamente pessoas (por exemplo, fazer fogo aparecer sob alguém); tentar isso quebra o feitiço. É possível criar uma barreira de fogo em local que o inimigo venha a atravessar. Para modificar a forma do fogo, o evocador deve concentrar-se; sem concentração, conserva a última forma até a duração terminar. Ao final, o fogo continua normalmente se houver combustível, ou se apaga.",niveis:{1:"Contato com o fogo causa 4 pontos de dano; alcance 2 metros.",2:"Contato causa 8 pontos de dano; alcance 3 metros.",4:"Contato causa 12 pontos de dano; alcance 4 metros. Pode criar fogo.",6:"Contato causa 16 pontos de dano; alcance 6 metros. Pode criar fogo.",8:"Contato causa 20 pontos de dano; alcance 9 metros. Pode criar fogo.",10:"Contato causa 24 pontos de dano; alcance 12 metros. Pode criar fogo."}},
  "Possessão": {"pagina": 90, "geral": "Troca os espíritos do evocador e de uma criatura tocada se ela falhar em Resistência à Magia. As características mentais acompanham os espíritos, mas as físicas permanecem com os corpos. Morte de um corpo durante a troca pode matar o ocupante imediatamente e o outro espírito quando a magia terminar. A vítima tende a odiar o evocador após a experiência. Materiais: 5 moedas de prata por dificuldade do efeito.", "niveis": {"1": "Evocação 10 rodadas, duração 20 rodadas. Se a vítima resistir, o evocador fica atordoado por 15 rodadas. Nenhum dos dois usa magia no corpo alheio, mas ambos podem usar habilidades.", "3": "Evocação 2 rodadas, duração 25 rodadas. Se a vítima resistir, evocador atordoado 7 rodadas. Não usam magia no corpo alheio; podem usar habilidades.", "5": "Evocação 2 rodadas, duração 1 hora. Se a vítima resistir, evocador atordoado 2 rodadas. Não usam magia no corpo alheio; podem usar habilidades.", "6": "Como efeito 5, mas não causa atordoamento ao evocador quando a vítima resiste.", "8": "Evocação 2 rodadas, duração 1 dia. Corpo do evocador fica em animação suspensa; a vítima não pode agir nele. Habilidades acompanham as mentes; evocador pode usar magia se o corpo ocupado for humanoide.", "9": "Evocação 2 rodadas, duração 2 dias. Corpo do evocador fica em animação suspensa. Se o corpo da vítima tiver duas pernas, dois braços, tronco e boca, o evocador pode usar magia normalmente.", "10": "Evocação 2 rodadas, duração 2 semanas. Corpo do evocador fica em animação suspensa. Se o corpo ocupado tiver duas pernas, dois braços, tronco e boca, evocador pode usar magia normalmente."}},
  "Prisão": {"pagina": 90, "geral": "Aprisiona um elemental dentro de objeto preparado, a até 30 metros, se o elemental falhar em Resistência à Magia. O mago pode manter até quatro elementais presos simultaneamente. Preparação do objeto exige ritual de 2 horas e materiais de 2 moedas de ouro. Para evocar, o mago toca o objeto; se o elemental resistir, fica livre e pode atacar. Preso, não recebe nem transmite mensagens. Prisão termina ao expirar duração ou destruir objeto; objeto destruído perde valor.", "niveis": {"1": "Prende um elemental menor por até 1 mês.", "3": "Prende um elemental fraco por até 1 mês.", "5": "Prende um elemental médio por até 3 meses.", "7": "Prende um elemental médio por até 1 ano e 1 dia.", "9": "Prende um elemental forte por até 13 anos."}},
  "Prisão Demoníaca": {"pagina": "90–91", "geral": "Aprisiona Demônio em objeto sem partes móveis, previamente preparado com ritual de 8 horas e materiais de 5 moedas de ouro. Alcance 20 metros; evocação de 1 rodada. O Demônio faz Resistência à Magia. A prisão rompe encantos de controle ativos sobre ele. Se libertado, fica furioso e ataca criaturas próximas por 20 rodadas antes de voltar aos planos infernais, salvo se impedido. O mesmo objeto íntegro pode ser reutilizado; nova evocação requer nova Resistência à Magia e pode prolongar prisão.", "niveis": {"1": "Demônio de Estágio até 3; duração 13 horas.", "3": "Demônio de Estágio até 5; duração 13 dias.", "5": "Demônio de Estágio até 9; duração 66 dias.", "7": "Demônio de Estágio até 13; duração 1 ano e 1 dia.", "9": "Demônio de Estágio até 18; duração 13 anos."}},
  "Projeção": {"pagina": 91, "geral": "Evocação de 2 rodadas. A consciência do evocador habita uma imagem sua com sentidos normais e capacidade de movimentação; seu corpo real permanece indefeso, inconsciente e sem percepção do ambiente. A imagem não deixa marcas, não produz ruído ao andar e não pode ficar invisível, mas pode receber outros feitiços. Se receber dano na Energia Física, a imagem se desfaz e a consciência retorna violentamente; evocador faz Resistência à Magia contra Força de Ataque 5 ou fica inconsciente por uma hora. Retorno voluntário ou por fim de duração não exige esse teste.", "niveis": {"1": "Imagem com Defesa 1, Energia Heroica 10, distância máxima 30 m e duração 10 rodadas.", "3": "Defesa 3, EH 20, distância máxima 30 m, duração 10 rodadas.", "5": "Defesa 4, EH 30, distância máxima 200 m, duração 20 rodadas.", "7": "Defesa 5, EH 40, distância máxima 300 m, duração 30 rodadas.", "10": "Defesa 6, EH 55, distância máxima 500 m, duração 1 hora."}},
  "Proteção": {"pagina": 91, "geral": "Milagre de toque e evocação instantânea que aumenta temporariamente a Energia Física real do beneficiário; não é absorção de dano como uma armadura. O aumento também conta para limites máximos de cura e críticos enquanto durar.", "niveis": {"1": "Aumenta a Energia Física em 5 pontos por 10 rodadas.", "2": "Aumenta a Energia Física em 5 pontos por 1 hora.", "3": "Aumenta a Energia Física em 10 pontos por 10 rodadas.", "5": "Aumenta a Energia Física em 10 pontos por 1 hora.", "7": "Aumenta a Energia Física em 15 pontos por 10 rodadas.", "9": "Aumenta a Energia Física em 15 pontos por 1 hora.", "10": "Aumenta a Energia Física em 15 pontos por 6 horas."}},
  "Pseudoconsciência": {"pagina": "91–92", "geral": "Encanta uma Ilusão Visual para que reaja independentemente da concentração do evocador. Deve ser lançada em conjunto com Ilusões Visuais; a duração é a mesma da ilusão. Permite ao evocador agir e evocar outras ilusões enquanto a primeira reage. Se a ilusão se afastar além do alcance deste encanto, o evocador volta a precisar concentrar-se para mantê-la agindo. As capacidades de reação são cumulativas entre efeitos.", "niveis": {"1": "Reações simples, como autodefesa, atacar inimigos e falar banalidades; alcance 10 m.", "3": "Reações normais, incluindo gestos, expressões faciais e conversa inteligente; alcance 200 m. Inclui reações dos efeitos anteriores.", "5": "A ilusão reage como o evocador gostaria que reagisse se pudesse decidir; alcance 5 km. Inclui capacidades anteriores."}},
  "Quebra de Encantos": {"pagina": 92, "geral": "Remove efeitos mágicos ainda ativos a até 20 metros. É preciso escolher efeito adequado ao tipo de magia e gastar a mesma quantidade de Karma que seria necessária para evocar a magia removida; sem Karma suficiente, a remoção falha. Duração instantânea.", "niveis": {"1": "Remove suas próprias magias não permanentes; evocação instantânea.", "3": "Remove suas próprias magias permanentes; evocação instantânea.", "4": "Remove magias não permanentes de outros místicos que você sabe evocar; evocação instantânea.", "6": "Remove magias não permanentes de outros místicos que você conhece (tem ao menos um nível); evocação 3 rodadas.", "7": "Remove magias permanentes de outros místicos que você sabe evocar; evocação ritual.", "9": "Remove magias não permanentes de outros místicos que você desconhece (não tem nível); evocação 1 rodada."}},
  "Raio Elétrico": {"pagina": 92, "geral": "Ataque mágico físico instantâneo: concentra eletricidade nas mãos e dispara contra adversário dentro do alcance. Até o efeito 4, acerta um alvo; a partir do efeito 6 pode bifurcar e atingir até dois alvos simultaneamente. O dano efetivo e eventuais críticos dependem da tabela de resolução de ataques, não são automáticos.", "niveis": {"1": "Dano máximo 16; alcance 5 m.", "2": "Dano máximo 20; alcance 15 m.", "4": "Dano máximo 28; alcance 30 m.", "6": "Dano máximo 32; alcance 50 m; pode atingir dois alvos.", "8": "Dano máximo 36; alcance 50 m; pode atingir dois alvos.", "10": "Dano máximo 40; alcance 100 m; pode atingir dois alvos."}},
  "Rastreamento": {"pagina": 93, "geral": "Encanto pessoal, evocado em uma rodada, válido para um uso da habilidade Seguir Trilhas. Exige ao menos nível 1 nessa habilidade. Reduz a dificuldade do rolamento; não concede a habilidade a quem não a possui.", "niveis": {"1": "Reduz em um nível a dificuldade de um uso de Seguir Trilhas.", "3": "Reduz em dois níveis a dificuldade.", "5": "Reduz em três níveis a dificuldade.", "7": "Reduz em quatro níveis a dificuldade.", "9": "Reduz em três níveis a dificuldade, ou converte um teste Impossível em Muito Difícil."}},
  "Recuperação Física": {"pagina": 93, "geral": "Milagre de toque, evocado em uma rodada, de efeito instantâneo. Trata doenças e neutraliza venenos conforme a gravidade indicada, sem representar recuperação genérica de pontos de dano.", "niveis": {"1": "Cura doenças menores, como gripes e fraquezas.", "3": "Neutraliza venenos não mortais que provoquem sono, fraqueza, torpor e efeitos semelhantes.", "5": "Cura doenças fortes de ação prolongada.", "6": "Neutraliza venenos que causam dano, mas não são mortais.", "7": "Cura qualquer doença.", "9": "Neutraliza venenos mortais."}},
  "Regeneração": {"pagina": 93, "geral": "Milagre ritual de toque que acelera a cura de críticos e, em efeitos superiores, restaura partes do corpo perdidas. A duração e os sacrifícios variam por efeito.", "niveis": {"1": "Se o tempo de cura de um crítico for superior a 12 horas, reduz esse tempo para 12 horas.", "2": "Como efeito 1, mas reduz a cura do crítico a uma hora.", "4": "Remove cicatrizes e marcas naturais, não mágicas. O resultado se completa após um dia.", "6": "Regenera problemas menores, como olho, mão, pé ou orelha, após um dia. Exige sacrifícios de 12 moedas de ouro.", "10": "Como efeito 6, mas também regenera problemas maiores, como braços, pernas e coluna quebrada. Exige sacrifícios de 20 moedas de ouro."}},
  "Resistência": {"pagina": 93, "geral": "Encanto pessoal instantâneo, com duração de 10 rodadas. Aumenta tanto a Resistência Física quanto a Resistência à Magia pelo número de pontos do efeito. Bônus de aplicações desta magia não se acumulam.", "niveis": {"1": "Aumenta ambas as resistências em 1 ponto.", "2": "Aumenta ambas as resistências em 2 pontos.", "4": "Aumenta ambas as resistências em 4 pontos.", "6": "Aumenta ambas as resistências em 6 pontos."}},
  "Resistência à Fadiga": {"pagina": 93, "geral": "Encanto pessoal instantâneo que amplia a resistência do evocador a atividades cansativas, permitindo esforços mais prolongados. O multiplicador varia com o efeito; a duração é variável.", "niveis": {"1": "Duplica a resistência à fadiga.", "3": "Triplica a resistência à fadiga.", "5": "Quadruplica a resistência à fadiga.", "7": "Quintuplica a resistência à fadiga."}},
  "Resistência Elemental": {"pagina": 94, "geral": "Encanto pessoal instantâneo, duração de um dia. Protege o Rastreador contra extremos naturais de calor e frio e contra excesso ou falta de umidade. Não protege contra fogo ou frio mágicos. Dentro da faixa do efeito, há proteção completa; fora dela, protege por cinco rodadas antes de colapso. O Rastreador percebe qual efeito é necessário para a temperatura ambiente.", "niveis": {"1": "Protege de 5 a 45 graus.", "3": "Protege de -5 a 55 graus.", "5": "Protege de -15 a 65 graus.", "7": "Protege de -35 a 85 graus.", "10": "Protege contra quaisquer extremos naturais de temperatura."}},
  "Ressurreição": {"pagina": 94, "geral": "Milagre de toque que mantém ou devolve a alma de um morto ao corpo. Mortes violentas, tempo transcorrido e lesões graves podem impedir o retorno; a concessão é rara e, em geral, reservada aos fiéis do Deus. Os efeitos 1 e 2 preservam possibilidades de retorno, mas não ressuscitam.", "niveis": {"1": "Permite ao morto balbuciar suas últimas palavras (uma ou duas frases), sem controle do sacerdote sobre o conteúdo. Deve ser evocado em até uma hora após a morte; apenas uma vez por morto. Evocação de três rodadas, duração de duas rodadas.", "2": "Mantém a alma no corpo por mais 12 horas e impede a decomposição. Só pode ser aplicado uma vez por morto, em até cinco rodadas após a morte. Evocação instantânea.", "4": "Devolve a vida a quem morreu por dano à Energia Física, salvo críticos incompatíveis com a sobrevivência, como decapitação ou destruição dos pulmões. Deve ser aplicado em até cinco rodadas após a morte, com Energia Física não inferior a -8; o alvo retorna estabilizado com -7 de EF. Evocação de uma rodada, efeito instantâneo.", "6": "Como efeito 4, mas aceita Energia Física até -9.", "8": "Como efeito 4, mas aceita Energia Física até -11.", "10": "Como efeito 4, mas aceita Energia Física até -13."}},
  "Retorno": {"pagina": 94, "geral": "Encanto de uma rodada, alcance 100 metros, duração instantânea. Obriga elementais a regressar ao plano de origem se falharem em Resistência à Magia. Afeta elementais de qualquer origem, até o limite total de Estágios e da categoria do efeito; os mais próximos são afetados primeiro. Elementais acima da categoria permitida são ignorados e não consomem o limite. Obstáculos não impedem o alcance.", "niveis": {"1": "Expulsa até 6 Estágios totais de elementais fracos.", "3": "Expulsa até 15 Estágios totais de elementais fracos.", "5": "Expulsa até 25 Estágios totais de elementais médios.", "7": "Expulsa até 35 Estágios totais de elementais fortes.", "9": "Expulsa até 50 Estágios totais de elementais fortes."}},
  "Relâmpagos": {"pagina": 93, "geral": "O livro imprime o título Relâmpago e chama o feitiço de Relâmpagos no corpo do texto; o identificador Relâmpagos é preservado no catálogo para não quebrar referências existentes. Atrai raios de uma tempestade já presente até o alvo indicado; exige fortes chuvas ou nuvens negras na região. Não cria tempestade. Deve ser lançado a céu aberto, nunca debaixo de teto ou no interior de estrutura; do topo aberto de uma torre é permitido. Evocação e duração instantâneas, alcance de até 100 metros. Dano máximo depende da Tabela de Resolução, não é dano garantido.", "niveis": {"1": "Atinge uma vítima, dano máximo de 12 pontos.", "2": "Atinge uma vítima, dano máximo de 16 pontos.", "4": "Atinge uma vítima, dano máximo de 24 pontos.", "6": "Atinge uma vítima, dano máximo de 28 pontos.", "8": "Atinge até duas vítimas, dano máximo de 32 pontos.", "10": "Atinge até três vítimas, dano máximo de 40 pontos."}},
  "Runas": {"pagina": "94–95", "geral": "Ritual que inscreve em parede ou objeto imóvel uma marca mágica, semelhante a Armadilha, guardando um encanto escolhido na evocação para disparar quando uma condição definida ocorrer. O efeito guardado passa a ter alcance de 10 metros; se atingir uma vítima, ela é escolhida entre as pessoas que entram no alcance na mesma rodada. Não podem existir duas runas do mesmo evocador a menos de 20 metros uma da outra. Objetos rúnicos devem permanecer em repouso ou quase repouso: no máximo uma hora de movimento por mês. Se duas runas do mesmo evocador ficarem a menos de 20 metros, a de menor Karma gasto desaparece e a outra dispara imediatamente; se os gastos forem iguais, ambas disparam. Evocação ritual, alcance de 10 metros, duração variável.", "niveis": {"1": "Armazena um efeito mágico de até 2 pontos de Karma, durante uma semana.", "2": "Armazena um efeito mágico de até 4 pontos de Karma, durante duas semanas.", "5": "Armazena um efeito mágico de até 10 pontos de Karma, durante um ano e um dia."}},
  "Sagração de Itens": {"pagina": 95, "geral": "Ritual de toque que confere propriedades mágicas temporárias a objetos comuns, com finalidade definida ao serem sagrados (como expulsar invasores de um templo ou matar líder inimigo). Termina quando a finalidade é alcançada ou a duração expira, o que ocorrer primeiro. O mesmo Sacerdote pode manter até três objetos sagrados simultaneamente; ao atingir o limite, só pode voltar a sagrar quando um dos encantamentos terminar. Os custos de ritual são indicados em moedas de ouro (m.o.).", "niveis": {"1": "Arma comum passa a atingir criaturas que só poderiam ser feridas por armas mágicas, durante uma semana.", "2": "Arma torna-se magicamente +1 durante uma semana; ritual custa 3 m.o.", "4": "Objeto torna-se um focus +4 durante duas semanas; ritual custa 6 m.o.", "6": "Armadura recebe +3 pontos de absorção e passa a ser tratada como mágica, durante um mês; ritual custa 9 m.o.", "7": "Arma torna-se magicamente +2 durante um mês; ritual custa 11 m.o.", "8": "Objeto torna-se um focus +8 durante um mês; ritual custa 12 m.o.", "10": "Arma torna-se magicamente +4 durante um mês; ritual custa 20 m.o."}},
  "Silêncio": {"pagina": 95, "geral": "Cria silêncio absoluto em área ao redor de ponto escolhido: nenhum som se propaga no interior em nenhuma direção. Evocação instantânea, duração de cinco rodadas, alcance variável. Se usado contra uma pessoa, ela faz Resistência à Magia: em caso de sucesso, o encanto não funciona; em caso de falha, a área de silêncio acompanha a vítima. Dentro da área, somente magias de evocação instantânea podem ser utilizadas; as de evocação mais longa não podem ser concluídas por exigirem componente vocal.", "niveis": {"1": "Silencia área de raio de meio metro ao redor do ponto escolhido.", "3": "Silencia área de raio de um metro.", "5": "Silencia área de raio de dois metros."}},
  "Som": {"pagina": 96, "geral": "Encanto instantâneo, alcance 20 metros, duração 20 rodadas. Cria sons ou vozes em um ou vários pontos dentro do alcance; pode acompanhar outras ilusões para aumentar o realismo. Os sons podem vir simultaneamente de vários locais, desde que todos estejam ao alcance. Para imitar voz de pessoa específica, o evocador deve tê-la ouvido pelo menos uma vez e obter sucesso em Canto com dificuldade Média, modificada pela familiaridade, conforme o Mestre.", "niveis": {"1": "Produz qualquer som cujo volume não supere o de um homem falando.", "2": "Produz som ou grupo de sons com volume não superior ao de cinco homens falando.", "3": "Produz som ou grupo de sons com volume não superior ao de um leão rugindo.", "5": "Produz som ou grupo de sons em qualquer volume desejado."}},
  "Solo Sagrado": {"pagina": "95–96", "geral": "Bênção ritual de uma área de terra contra demônios e mortos-vivos. Um sacerdote pode manter no máximo três áreas sagradas simultaneamente; ao abençoar uma quarta, deve retirar uma bênção anterior. Para entrar, as criaturas afetadas precisam vencer Resistência à Magia; os efeitos mais altos abrangem Estágios maiores. Alcance, duração e custo variam conforme o efeito.", "niveis": {"1": "Raio de até 2 metros; impede a entrada de demônios e mortos-vivos de Estágio 1 durante uma semana.", "2": "Raio de até 3 metros; criaturas de Estágio até 3; duração de um mês.", "4": "Raio de até 10 metros; criaturas de Estágio até 5; duração de dois meses; ritual custa 10 moedas de ouro.", "6": "Raio de até 50 metros; criaturas de Estágio até 7; duração de quatro meses; ritual custa 15 moedas de ouro.", "8": "Raio de até 100 metros; criaturas de Estágio até 9; duração de oito meses; ritual custa 20 moedas de ouro.", "10": "Raio de até 200 metros; criaturas de Estágio até 12; duração de um ano e um dia; ritual custa 25 moedas de ouro."}},
  "Sombras": {"pagina": 96, "geral": "Feitiço que evoca, controla ou destrói Sombras Menores e Sombras Maiores, criaturas infernais. Evocação, duração e alcance mudam de acordo com o efeito. Uma Sombra Menor ou Maior obrigada a servir retorna imediatamente às regiões infernais se ultrapassar a distância máxima do mestre, exceto no efeito 9; pode sofrer consequências se ficar fora do alcance. Criaturas podem fazer Resistência à Magia nos efeitos que a exigem.", "niveis": {"1": "Força uma Sombra Menor a testar Resistência à Magia; se falhar, fica atordoada por uma rodada. Alcance 5 metros; evocação instantânea.", "3": "Invoca uma Sombra Menor e a obriga a servir durante 20 rodadas. Alcance 10 metros; evocação de 3 rodadas.", "4": "Obriga uma Sombra Menor a testar Resistência à Magia; se falhar, é mandada de volta às regiões infernais. Alcance 10 metros; evocação instantânea.", "5": "Invoca uma Sombra Menor para servir durante um dia. Ritual; alcance 20 metros.", "6": "Cria esfera de luz de 3 metros de raio: Sombras Menores dentro da área devem resistir à magia ou ficam aprisionadas na jaula por uma hora. Alcance 20 metros; evocação instantânea.", "7": "Invoca Sombra Menor para servir por um ano e um dia. Ritual; alcance 30 metros; custo de 5 moedas de ouro.", "8": "Invoca Sombra Maior para servir por um dia. Ritual; alcance 30 metros; custo de 3 moedas de ouro.", "9": "Permite a uma Sombra Menor ou Maior já a serviço permanecer a qualquer distância durante 24 horas; evocação ritual; criatura precisa estar a menos de 10 metros no momento da evocação.", "10": "Invoca Sombra Maior para servir por um ano e um dia. Ritual; alcance 30 metros; custo de 15 moedas de ouro."}},
  "Sono": {"pagina": 97, "geral": "Feitiço instantâneo, alcance 20 metros, duração variável. Alvos podem resistir à magia. Sono leve é desfeito por barulhos ou toques leves; sono pesado só é desfeito por pancadas na vítima.", "niveis": {"1": "Uma vítima fica muito sonolenta durante uma rodada, sem perceber o entorno.", "2": "Uma vítima dorme sono leve por 5 rodadas.", "3": "Uma vítima dorme sono pesado por 10 rodadas.", "5": "Uma vítima dorme sono pesado por 10 minutos.", "7": "Duas vítimas dormem sono pesado por 10 rodadas.", "10": "Três vítimas dormem sono pesado por 10 rodadas."}},
  "Sugestão": {"pagina": "97", "geral": "Implanta sugestão na mente de uma vítima a até 20 metros, com evocação instantânea. A vítima tem direito a Resistência à Magia. A frase deve ser gramaticalmente correta, e o limite de palavras e a duração dependem do efeito. Sugestões contrárias à natureza ou inclinações da vítima dão nova Resistência à Magia por rodada enquanto ela as cumpre; se resistir ou a duração terminar, percebe o encantamento. Ordens de suicídio simplesmente não são cumpridas. Se a sugestão não contrariar a natureza da vítima, ela não percebe o encanto mesmo ao resistir. A duração limita o tempo para cumprir a ordem.", "niveis": {"1": "Até 3 palavras, duração de 5 rodadas.", "3": "Até 7 palavras, duração de 15 rodadas.", "5": "Até 15 palavras, duração de uma hora.", "7": "Até 15 palavras, duração de 3 horas.", "9": "Até 45 palavras, duração de 6 horas.", "10": "Até 15 palavras, duração de 24 horas."}},
  "Telecinese": {"pagina": 97, "geral": "Cria força invisível controlada pela concentração do evocador; evocação de uma rodada, alcance 30 metros e duração 10 rodadas. Pode mover, arrastar ou derrubar objetos. Mover significa controle completo em qualquer direção; arrastar é mover junto ao chão; derrubar é tirar o objeto do equilíbrio. Objetos são movidos ou arrastados a 5 metros por rodada. Se usado contra ser com aura, ele tem direito a Resistência à Magia.", "niveis": {"1": "Move até 5 kg, arrasta até 10 kg ou derruba até 15 kg.", "2": "Move até 10 kg, arrasta até 20 kg ou derruba até 30 kg.", "3": "Move até 20 kg, arrasta até 40 kg ou derruba até 60 kg.", "5": "Move até 50 kg, arrasta até 100 kg ou derruba até 150 kg.", "7": "Move até 100 kg, arrasta até 200 kg ou derruba até 300 kg.", "9": "Move até 200 kg, arrasta até 400 kg ou derruba até 600 kg."}},
  "Toque": {"pagina": "97–98", "geral": "Concede a uma Ilusão Visual capacidade de movimentação rápida, combate e interação leve com o real. A ilusão recebe Defesa, Energia Heroica, Coluna de Ataque e dano em EH de acordo com o efeito. A Defesa pode ser escolhida até o máximo permitido; a Coluna de Ataque é fixa. Ataques físicos que atinjam a ilusão podem destruí-la, salvo quando combinada com Ilusões Materiais. Apesar de dispensar concentração para movimentar-se, sua conduta pode depender de Pseudoconsciência. Evocação instantânea; alcance e duração variáveis.", "niveis": {"1": "EH 5, dano máximo 12, Defesa até 3, Coluna de Ataque 0.", "3": "EH 15, dano máximo 16, Defesa até 7, Coluna de Ataque 3.", "5": "EH 30, dano máximo 20, Defesa até 11, Coluna de Ataque 7.", "7": "EH 45, dano máximo 24, Defesa até 15, Coluna de Ataque 11.", "10": "EH 70, dano máximo 28, Defesa até 20, Coluna de Ataque 15."}},
  "Transformação": {"pagina": 98, "geral": "Altera a forma de criatura que falhe em Resistência à Magia; evocação instantânea, alcance 20 metros. A vítima conserva capacidades mentais e conhecimentos e pode usar habilidades ou feitiços apenas se a nova forma permitir. EF e EH permanecem inalteradas. Efeitos até dificuldade 4 não transformam equipamento; nos superiores o equipamento se funde ao corpo. O peso da forma final não pode ser menor que 300 gramas ou metade do peso original, o que for menor. Cada efeito também estabelece um limite de peso para a criatura. Duração variável.", "niveis": {"1": "Transforma em criatura semelhante, de tamanho aproximadamente igual, por meia hora; peso máximo 120 kg.", "2": "Como efeito 1, por 6 horas; peso máximo 120 kg.", "4": "Transforma em criatura semelhante de tamanho aproximadamente igual, por um dia; peso máximo 120 kg.", "6": "Transforma em criatura semelhante com tamanho entre metade e o dobro do original, por 66 dias; peso máximo 300 kg.", "8": "Transforma em outra criatura da mesma classe biológica (mamífero, réptil, ave ou anfíbio), por um ano e um dia; peso máximo 300 kg.", "10": "Transforma em outra criatura, sem restrição de classe, permanentemente; peso máximo 500 kg."}},
  "Transporte Dimensional": {"pagina": "98–99", "geral": "Encanto de evocação instantânea que distorce o espaço, conectando dois pontos. Para transportar-se a um destino, o evocador precisa conhecer o local: estar vendo ou já ter visto esse ponto. Se o destino estiver além do alcance do efeito, a magia falha. Alcance e duração variam conforme o efeito; os efeitos inferiores transportam objetos ou o evocador, enquanto o mais elevado cria um portal temporário.", "niveis": {"1": "Transporta instantaneamente um objeto de até 5 kg, retirado de alguma parte do corpo do evocador (bolso, mãos etc.), a até 5 metros.", "3": "Como efeito 1, mas permite objeto de até 20 kg e distância de até 100 metros.", "5": "Transporta o próprio evocador instantaneamente a até 10 metros, podendo levar 50 kg de peso adicional.", "7": "Como efeito 5, mas a distância máxima aumenta para 100 metros.", "9": "Cria portal circular de 2 metros de diâmetro entre dois pontos separados por até 1 quilômetro. O portal dura duas rodadas; quem o atravessa é transportado instantaneamente de um ponto para o outro."}},
  "Ventriloquismo": {"pagina": 99, "geral": "Projeta a voz do evocador para que pareça originar-se de outro ponto dentro do alcance. Evocação instantânea e duração de 15 rodadas. Enquanto durar o feitiço, o evocador pode mudar instantaneamente o ponto de origem da voz, desde que permaneça dentro do alcance do efeito. Pode ser usada em conjunto com outras magias que produzam ou alterem sons, como Controle da Voz.", "niveis": {"1": "Projeta a voz a até 1 metro de distância.", "2": "Projeta a voz a até 3 metros de distância.", "3": "Projeta a voz a até 10 metros de distância.", "4": "Projeta a voz a até 20 metros de distância.", "6": "Projeta a voz a até 30 metros de distância."}},
  "Visão Noturna": {"pagina": 99, "geral": "Encanto de toque e evocação instantânea, duração de 12 horas. Permite enxergar sob condições de pouca luminosidade, sempre em tons de preto e branco, com alcance de visão equivalente ao que a criatura teria sob luz do dia. Não permite ver quando o ambiente é subitamente iluminado: nessa situação a visão volta ao normal; se a iluminação cessar antes de terminar a duração, o efeito volta a funcionar. Escuridão parcial inclui noites estreladas sem lua e cavernas iluminadas apenas por uma tocha; escuridão total é ausência de qualquer fonte de luz, como em compartimento fechado; escuridão mágica decorre de feitiços como Escuridão.", "niveis": {"1": "Permite enxergar em escuridão parcial.", "2": "Permite enxergar em escuridão total.", "4": "Permite enxergar em escuridão de origem mágica."}},
  "Bênção": {"pagina": "66–67", "geral": "Milagre sacerdotal de evocação instantânea, alcance de 10 metros e duração de 10 rodadas. Os efeitos 1 a 3 ampliam as colunas de ataque de até cinco companheiros, sem acumulação entre bênçãos. Nos efeitos 5, 7 e 9, o Sacerdote sacrifica pontos de sua própria Energia Heroica para aumentar a Energia Heroica de um aliado, inclusive acima do máximo habitual; a parcela excedente desaparece ao fim da duração. O ganho em colunas de ataque também é especificado por efeito.", "niveis": {"1": "Até cinco companheiros recebem +1 coluna de ataque.", "2": "Até cinco companheiros recebem +2 colunas de ataque.", "3": "Até cinco companheiros recebem +4 colunas de ataque.", "5": "Sacerdote perde 5 pontos de EH; um companheiro ganha 15 pontos de EH e +3 colunas de ataque.", "7": "Sacerdote perde 10 pontos de EH; um companheiro ganha 30 pontos de EH e +3 colunas de ataque.", "9": "Sacerdote perde 10 pontos de EH; um companheiro ganha 40 pontos de EH e +5 colunas de ataque."}},
  "Canção de Medo": {"pagina": "67–68", "geral": "Magia de Bardo, evocada em quatro rodadas, alcance de 20 metros e duração de 10 rodadas. A canção afeta alvos visíveis ao Bardo que falhem na Resistência à Magia; os pontos de EH perdidos são recuperados normalmente, não ao terminar a magia. Vítimas que fogem se deslocam na maior velocidade possível até o fim do efeito; se perderem mais EH que a que possuem no momento, fogem obrigatoriamente, mesmo que isso não seja previsto pelo efeito. O efeito 10 também causa pânico e abandono dos objetos carregados, exceto vestimentas.", "niveis": {"1": "Até duas pessoas perdem 5 pontos de EH.", "3": "Até duas pessoas perdem 10 pontos de EH.", "5": "Até três pessoas perdem 10 pontos de EH.", "7": "Até três pessoas perdem 10 pontos de EH e fogem do evocador.", "8": "Até três pessoas perdem 15 pontos de EH e fogem do evocador.", "10": "Até duas pessoas perdem 20 pontos de EH e fogem; quem falhar na Resistência à Magia entra em pânico e larga o que carrega, exceto o que veste."}},
  "Conjuração Demoníaca": {"pagina": "68–69", "geral": "Ritual necromântico que conjura um habitante dos planos infernais a até 10 metros, com duração variável conforme o tipo e o tempo de permanência. Não concede controle sobre o demônio: para isso é necessária a magia Domínio Demoníaco. Se chegar sem restrições, o demônio atacará o evocador, mas poderá fugir diante de um inimigo poderoso. Pode ser combinada com Domínio Demoníaco e com círculos e pentagramas de proteção. Materiais do ritual custam duas moedas de ouro por dificuldade do efeito. O demônio conjurado pode permanecer no plano material por um ano e um dia.", "niveis": {"1": "Conjura um Demônio Menor.", "3": "Conjura um Demônio Tipo I.", "5": "Conjura um Demônio Tipo II.", "7": "Conjura um Demônio Tipo III."}},
  "Controle": {"pagina": "69–70", "geral": "Magia necromântica para controlar mortos-vivos, evocada em dez rodadas, alcance de 10 metros e duração permanente. Mortos-vivos criados pelo próprio evocador são controlados automaticamente; outros têm direito a Resistência à Magia e, se resistirem, tentam destruir o evocador. O morto-vivo controlado obedece ao necromante, mas não pode ser convencido a atacar o próprio mestre. O número de estágios controlados não é cumulativo entre efeitos: os mais fracos são afetados primeiro até o limite. O evocador precisa usar ordens verbais compreensíveis; ao morrer, seus servos ficam livres após cumprirem as últimas instruções. O ritual custa uma moeda de prata por dificuldade e só pode ser usado em um morto-vivo de cada vez.", "niveis": {"1": "Controla até 5 mortos-vivos, cada um de Estágio máximo 1.", "2": "Controla até 12 mortos-vivos, cada um de Estágio máximo 2.", "4": "Controla até 25 mortos-vivos, cada um de Estágio máximo 4.", "6": "Controla até 40 mortos-vivos, cada um de Estágio máximo 6.", "8": "Controla até 60 mortos-vivos, cada um de Estágio máximo 8.", "10": "Controla até 80 mortos-vivos, cada um de Estágio máximo 10."}},
  "Dardos de Gelo": {"pagina": "71–72", "geral": "Feitiço de evocação instantânea, alcance de 50 metros e duração de uma rodada. Cria três dardos pontiagudos de gelo que partem imediatamente contra vítimas escolhidas pelo evocador. Mais de um dardo pode atingir a mesma pessoa. Cada dardo exige resolução de ataque e tem seu próprio dano máximo segundo a dificuldade. Após atingir ou errar, o dardo se fragmenta, derrete rapidamente e a água desaparece; esse processo ocupa uma rodada.", "niveis": {"1": "Cada um dos três dardos causa até 12 pontos de dano.", "3": "Cada dardo causa até 16 pontos de dano.", "5": "Cada dardo causa até 20 pontos de dano.", "7": "Cada dardo causa até 24 pontos de dano.", "9": "Cada dardo causa até 32 pontos de dano."}}
};

// A classificação abaixo é conservadora: somente registros com dano físico
// explicitamente catalogado são marcados como ataque físico.
export function descricaoVerificadaDaMagia(nome) {
  const m = MAGIAS[nome];
  if (!m) return "Magia não encontrada no catálogo da 1ª Edição.";
  const linhas = [
    `TAGMAR 1ª EDIÇÃO (1991) — ${nome}`,
    `DADOS DE CONJURAÇÃO: Evocação: ${m.evocacao}. Alcance: ${m.alcance}. Duração: ${m.duracao}.`,
    `EFEITOS CATALOGADOS (dificuldades): ${m.dificuldades.join(", ")}. Estes números NÃO são, por si sós, a descrição dos efeitos.`,
    `LISTAS E CUSTOS DE AQUISIÇÃO: ${Object.entries(m.listas).map(([lista, custo]) => `${lista}: ${custo}`).join("; ")}.`
  ];
  if (m.ataque.length) {
    linhas.push("ATAQUE FÍSICO MÁGICO — Há efeitos com dano máximo catalogado. Esses ataques utilizam a Tabela de Resolução na rotina do sistema; não confundir com testes de Resistência à Magia.");
    for (const a of m.ataque) linhas.push(`Efeito ${a.dificuldade}: dano máximo catalogado ${a.danoMaximo}. O dano efetivo depende da resolução do ataque; não é dano automático.`);
  } else {
    linhas.push("CLASSIFICAÇÃO NÃO CONFIRMADA — A ausência de dano físico na base não prova que o efeito exija Resistência à Magia, nem que seja inofensivo.");
  }
  const confirmado = EFEITOS_CONFERIDOS_1991[nome];
  if (confirmado) {
    linhas.push(`DESCRIÇÃO CONFERIDA — livro de 1991, capítulo V, página impressa ${confirmado.pagina}: ${confirmado.geral}`);
    for (const [nivel, efeito] of Object.entries(confirmado.niveis)) linhas.push(`EFEITO ${nivel}: ${efeito}`);
    linhas.push("Os textos acima são paráfrases de consulta, conferidas visualmente com a página impressa; em caso de dúvida, prevalece o livro original.");
  } else {
    linhas.push("EFEITOS COMPLETOS POR NÍVEL, ALVOS, RESTRIÇÕES, EXCEÇÕES E EXEMPLOS: ainda NÃO transcritos nem verificados contra o texto impresso de 1991. Consultar a descrição integral no capítulo V do livro antes de arbitrar a magia.");
  }
  linhas.push("Esta ficha separa dados catalogados de lacunas editoriais. Não usa regras da 2ª ou 3ª Edição.");
  return linhas.join("\n\n");
}

export function docsMagias() {
  return Object.keys(MAGIAS).map(function (n) {
    const m = MAGIAS[n];
    return {name: n, type: "magia", system: {
      evocacao: m.evocacao, alcance: m.alcance, duracao: m.duracao, dificuldades: m.dificuldades, ataque: m.ataque,
      descricao: descricaoVerificadaDaMagia(n),
      listas: Object.keys(m.listas).map(function (l) { return {lista: l, custo: m.listas[l]}; })
    }};
  });
}
