import { validarCompraNivel, validarCompraConfirmada } from "./validacoes.mjs";
import { ARMAS, ARMADURAS, ESCUDOS, ELMOS, valorContraDefesa, danoBase, achaProfissao, ALCANCE_ARMAS, SEM_AGILIDADE, MOVIMENTO, TEMPO_MOVIMENTO, GRUPOS_ARMAS, ARMA_INFO } from "./tabelas.mjs";
import { GRUPOS, CARACS, HABILIDADES, RACAS, RESUMOS, achaRaca } from "./dados.mjs";
import { atacar, testarHabilidade, aplicarDano, aplicarDanoNoAlvo, rolarEH, evocarMagia, testarResistencia, subirEstagio, sortearAlturaPeso, sortearClasseSocial, pedirIngresso, queda, reacaoCriatura, dinheiroInicial, comprar } from "./rolagens.mjs";
import { textoMoedas, FAIXAS_CARGA } from "./equipamentos.mjs";
import { MAGIAS, ORDENS, descricaoVerificadaDaMagia } from "./magias.mjs";

const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;

const NOVOS = {
  habilidades: {nome: "Ações Furtivas", nivel: 1},
  armas: {nome: "Espada", grupo: "", alcance: "", nivel: 0},
  magias: {nome: "Abrigo", nivel: 1}
};
const car_for = function (s) { return s.caracteristicas.forca.final; };
const sinal = function (n) { return (n > 0 ? "+" : "") + n; };
const opcoes = function (obj, escolhido) {
  return Object.keys(obj).map(function (k) { return {v: k, rot: k + (obj[k] ? " (+" + obj[k] + ")" : ""), sel: k === escolhido}; });
};
const opcoesHabilidade = function (escolhido) {
  return Object.keys(GRUPOS).map(function (g) {
    return {
      grupo: GRUPOS[g],
      itens: Object.keys(HABILIDADES).filter(function (n) { return HABILIDADES[n].grupo === g; }).map(function (n) { return {v: n, sel: n === escolhido}; })
    };
  });
};

export class TagmarFicha extends HandlebarsApplicationMixin(ActorSheetV2) {
  static DEFAULT_OPTIONS = {
    classes: ["tagmar1e", "ficha"],
    position: {width: 1100, height: 860},
    window: {resizable: true},
    form: {submitOnChange: true},
    actions: {
      addItem: TagmarFicha.#addItem,
      delItem: TagmarFicha.#delItem,
      testarHabilidade: TagmarFicha.#testarHabilidade,
      atacar: TagmarFicha.#atacar,
      rolarIniciativa: TagmarFicha.#rolarIniciativa,
      comprarGrupo: TagmarFicha.#comprarGrupo,
      aplicarDano: TagmarFicha.#aplicarDano,
      aplicarDanoNoAlvo: TagmarFicha.#aplicarDanoNoAlvo,
      restaurarAbsorcao: TagmarFicha.#restaurarAbsorcao,
      rolarEH: TagmarFicha.#rolarEH,
      aplicarEF: TagmarFicha.#aplicarEF,
      evocarMagia: TagmarFicha.#evocarMagia,
      testarResistencia: TagmarFicha.#testarResistencia,
      subirEstagio: TagmarFicha.#subirEstagio,
      sortearAlturaPeso: TagmarFicha.#sortearAlturaPeso,
      sortearClasseSocial: TagmarFicha.#sortearClasseSocial,
      pedirIngresso: TagmarFicha.#pedirIngresso,
      queda: TagmarFicha.#queda,
      reacaoCriatura: TagmarFicha.#reacaoCriatura,
      dinheiroInicial: TagmarFicha.#dinheiroInicial,
      removerPertence: TagmarFicha.#removerPertence,
      abrirPertence: TagmarFicha.#abrirPertence,
      mostrarPertence: TagmarFicha.#mostrarPertence,
      mostrarMagia: TagmarFicha.#mostrarMagia,
      configurarToken: TagmarFicha.#configurarToken,
      selecionarRetrato: TagmarFicha.#selecionarRetrato,
      localizarToken: TagmarFicha.#localizarToken,
      criarToken: TagmarFicha.#criarToken,
      alternarToken: TagmarFicha.#alternarToken,
      comprar: TagmarFicha.#comprar
    }
  };

  static PARTS = {
    ficha: {template: "systems/tagmar1e/templates/ficha.hbs", scrollable: [""]}
  };

  // tema visual escolhido nas configuracoes do sistema
  async _onRender(context, options) {
    await super._onRender(context, options);
    this.element.classList.remove("tg-original-1991");
    this.element.classList.add("tg-ficha-167");
    const tema = game.settings.get("tagmar1e", "tema");
    for (const classe of ["tema-pergaminho", "tema-escuro", "tema-moderno"]) this.element.classList.remove(classe);
    this.element.classList.add("tema-" + (tema === "simples" ? "moderno" : tema));
    // Abas reais: preserva o estado durante rerenders causados por edicao de campos.
    const abaAtual = this._tgAbaAtual ?? "personagem";
    const aplicarAba = (aba) => {
      const permitidas = ["personagem", "combate", "habilidades", "magias", "pertences"];
      if (!permitidas.includes(aba)) return;
      this._tgAbaAtual = aba;
      for (const painel of this.element.querySelectorAll("[data-tg-painel]")) {
        painel.hidden = painel.dataset.tgPainel !== aba;
      }
      for (const botao of this.element.querySelectorAll("[data-tg-tab]")) {
        const ativo = botao.dataset.tgTab === aba;
        botao.classList.toggle("tg-aba-ativa", ativo);
        botao.setAttribute("aria-pressed", String(ativo));
      }
    };
    for (const botao of this.element.querySelectorAll("[data-tg-tab]")) {
      botao.addEventListener("click", (evento) => {
        evento.preventDefault();
        aplicarAba(botao.dataset.tgTab);
      });
    }
    aplicarAba(abaAtual);
    // Controle independente das actions da ficha; falhas aqui nao impedem a abertura.
    const raiz = this.element;
    if (raiz && !raiz.querySelector(".tg-seletor-tema")) {
      const barra = document.createElement("nav");
      barra.className = "tg-seletor-tema";
      barra.setAttribute("aria-label", "Tema visual da ficha");
      const titulo = document.createElement("span");
      titulo.textContent = "Visual da ficha: ";
      barra.append(titulo);
      for (const [valor, rotulo] of [["pergaminho", "Pergaminho"], ["escuro", "Medieval escuro"], ["moderno", "Moderno"]]) {
        const botao = document.createElement("button");
        botao.type = "button";
        botao.textContent = rotulo;
        botao.dataset.tema = valor;
        botao.addEventListener("click", async (event) => {
          event.preventDefault();
          try {
            await game.settings.set("tagmar1e", "tema", valor);
            // Atualiza esta ficha mesmo se o listener global nao estiver disponivel.
            for (const classe of ["tema-pergaminho", "tema-escuro", "tema-moderno"]) raiz.classList.remove(classe);
            raiz.classList.add("tema-" + valor);
          } catch (erro) {
            console.error("Tagmar | Falha ao mudar tema", erro);
            ui.notifications.error("Nao foi possivel mudar o tema da ficha.");
          }
        });
        barra.append(botao);
      }
      const destino = raiz.querySelector(".window-content") ?? raiz;
      destino.prepend(barra);
    }

  }

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const s = this.actor.system;
    const aAgi = s.caracteristicas.agilidade.ajuste;
    const aFor = s.caracteristicas.forca.ajuste;
    ctx.actor = this.actor;
    ctx.pertencesItens = this.actor.items.filter(i => ["equipamento", "arma", "armadura"].includes(i.type)).map(i => ({id:i.id, nome:i.name, tipo:i.type === "arma" ? "Arma" : i.type === "armadura" ? "Proteção" : "Equipamento", quantidade:i.system.quantidade ?? 1, descricao:i.system.descricao ?? i.system.descricaoCurta ?? "", preco:i.system.preco ?? "", peso:i.system.peso ?? ""}));
    ctx.system = s;
    ctx.editable = this.isEditable;
    ctx.isGM = game.user.isGM;
    const nomes = {intelecto: "Intelecto", aura: "Aura", carisma: "Carisma", forca: "Força", fisico: "Físico", agilidade: "Agilidade"};
    ctx.car = Object.keys(nomes).map(function (k) {
      const c = s.caracteristicas[k];
      return {k: k, nome: nomes[k], inicial: c.inicial, racial: c.racial, final: c.final, ajusteTxt: sinal(c.ajuste)};
    });
    ctx.habilidades = s.habilidades.map(function (h, i) {
      const d = HABILIDADES[h.nome];
      return {
        i: i, nivel: h.nivel, total: h.total,
        grupo: d ? GRUPOS[d.grupo] : "", custo: d ? d.custo : "", carac: d ? CARACS[d.carac] : "",
        acima: h.nivel > s.estagio, opcoes: opcoesHabilidade(h.nome),
        resumo: RESUMOS[h.nome] ? "Cap. III, item " + RESUMOS[h.nome].item + ". " + RESUMOS[h.nome].resumo : ""
      };
    });
    ctx.pontosHab = s.pontosHab.map(function (g) {
      return {nome: g.nome, gastos: g.gastos, totalTxt: g.total === null ? "?" : g.total, excedeu: g.total !== null && g.gastos > g.total};
    });
    const nomesMagias = Object.keys(MAGIAS).sort(function (a, b) { return a.localeCompare(b, "pt"); });
    ctx.magias = s.magias.map(function (m, i) {
      const d = MAGIAS[m.nome];
      const opcoesM = nomesMagias.map(function (n) { return {v: n, sel: n === m.nome}; });
      if (!d) opcoesM.unshift({v: m.nome, sel: true, rot: m.nome || "— escolha uma magia —"});
      return {
        i: i, nivel: m.nivel, opcoes: opcoesM,
        custoTxt: m.custo === null || m.custo === undefined ? "fora da lista" : String(m.custo),
        evocacao: d ? d.evocacao : "", alcance: d ? d.alcance : "", duracao: d ? d.duracao : "",
        ataque: !!(d && d.ataque.length),
        descricaoOficial: d ? descricaoVerificadaDaMagia(m.nome) : ""
      };
    });
    ctx.ordens = [{v: "", rot: "Nenhuma", sel: !s.ordem}].concat(ORDENS.map(function (o) { return {v: o, rot: o, sel: o === s.ordem}; }));
    ctx.pontosMagia = {gastos: s.pontosMagia.gastos, txt: s.pontosMagia.disponiveis === null ? (s.pontosMagia.pendente ? "não tabelado (consulte o Mestre)" : "— (sem lista de magias)") : String(s.pontosMagia.disponiveis), origem: s.pontosMagia.origem};
    ctx.armas = s.armas.map(function (a, i) {
      const conhecida = !!ARMAS[a.nome];
      const nivelEfetivo = a.nivelEfetivo ?? a.nivel;
      const total = nivelEfetivo + (SEM_AGILIDADE.indexOf(a.nome) >= 0 ? 0 : aAgi);
      const ataque = [];
      let dano = [];
      if (conhecida) {
        for (let d = 1; d <= 21; d++) ataque.push(total + valorContraDefesa(a.nome, d));
        dano = [100, 75, 50, 25].map(function (p) { return danoBase(a.nome, p) + aFor; });
      }
      return {
        i: i, nome: a.nome, grupo: a.grupo, alcance: a.alcance, nivel: nivelEfetivo, total: total, conhecida: conhecida,
        alcanceTxt: ALCANCE_ARMAS[a.nome] ? ALCANCE_ARMAS[a.nome] + " m" : (conhecida ? "2 m" : "—"),
        grupoTxt: a.grupoCalc || "—", mao: a.mao || "—", acima: nivelEfetivo > s.estagio,
        forcaTxt: a.forcaMin === null ? "" : (a.forcaOk ? "Força mín. " + a.forcaMin : "Força " + car_for(s) + " < mín. " + a.forcaMin),
        forcaOk: a.forcaOk,
        ataque: ataque, dano: dano,
        opcoes: Object.keys(ARMAS).map(function (n) { return {v: n, sel: n === a.nome}; })
      };
    });
    const fmt = function (x) { return x === null ? "não pode" : String(Math.round(x * 10) / 10); };
    const vb = s.velocidadeBase;
    ctx.movimento = vb === null ? [] : MOVIMENTO.map(function (r) {
      return {faixa: r.faixa, atual: r.faixa === FAIXAS_CARGA[s.faixaCarga], andando: fmt(vb * r.andando), fundo: fmt(r.fundo === null ? null : vb * r.fundo), curta: fmt(r.curta === null ? null : vb * r.curta)};
    });
    ctx.tempoMov = TEMPO_MOVIMENTO;
    ctx.dinheiroTxt = textoMoedas(s.dinheiro);
    ctx.carga = {pontos: s.pontosCarga, vestes: s.pontosVestes, faixa: FAIXAS_CARGA[s.faixaCarga],
      armas: [["leve", "Leves (5 punhais, uma espada ou um arco composto)"], ["media", "Médias (espada, punhal e arco composto)"], ["pesada", "Pesadas (montante e arco composto)"]].map(function (o) { return {v: o[0], rot: o[1], sel: o[0] === s.carga.armas}; }),
      equip: [["leve", "Leve (cabe folgado numa mochila)"], ["medio", "Médio (cabe apertado numa mochila)"], ["pesado", "Pesado (cabe em duas mochilas)"], ["absurdo", "Absurdo (não cabe em duas mochilas)"]].map(function (o) { return {v: o[0], rot: o[1], sel: o[0] === s.carga.equip}; })};
    ctx.estagioPE = s.estagioPE;
    ctx.proximoPE = s.pePara === null ? "—" : s.pePara;
    ctx.gruposArmas = Object.entries(GRUPOS_ARMAS).map(([codigo, info]) => ({codigo, nome: info.nome, custo: info.custo, nivel: s.niveisGrupos?.[codigo] || 0, custoProximo: info.custo, podeComprar: (s.niveisGrupos?.[codigo] || 0) < s.estagio && s.pontosCombate.disponiveis !== null && s.pontosCombate.disponiveis - s.pontosCombate.gastos >= info.custo}));
    ctx.pontosCombate = {gastos: s.pontosCombate.gastos, txt: s.pontosCombate.disponiveis === null ? "— (informe a profissão)" : String(s.pontosCombate.disponiveis)};
    ctx.efTxt = s.efTabela === null ? "informe o peso" : (s.efTabela > 0 ? String(s.efTabela) : "inviável");
    ctx.velTxt = s.velocidadeBase === null ? "informe a altura" : String(s.velocidadeBase);
    ctx.defTxt = s.defesa + " (" + s.defesaInconsciente + " sem consciência)";
    ctx.resFis = s.resistenciaFisica;
    ctx.resMag = s.resistenciaMagia;
    ctx.karmaMax = s.karmaMax;
    ctx.armaduras = opcoes(ARMADURAS, s.absorcao.armadura);
    ctx.escudos = opcoes(ESCUDOS, s.absorcao.escudo);
    ctx.elmos = opcoes(ELMOS, s.absorcao.elmo);
    return ctx;
  }

  // formularios enviam listas como objetos {0:..., 1:...}; converte de volta em arrays.
  // Trocar armadura/escudo/elmo restaura a absorcao.
  _prepareSubmitData(event, form, formData, updateData) {
    const data = super._prepareSubmitData(event, form, formData, updateData);
    for (const k of ["habilidades", "armas", "magias"]) {
      const v = foundry.utils.getProperty(data, "system." + k);
      if (v && !Array.isArray(v)) {
        const lista = Object.keys(v).sort(function (a, b) { return Number(a) - Number(b); }).map(function (i) { return v[i]; });
        foundry.utils.setProperty(data, "system." + k, lista);
      }
    }
    const ab = foundry.utils.getProperty(data, "system.absorcao");
    const atual = this.actor.system.absorcao;
    if (ab && (ab.armadura !== atual.armadura || ab.escudo !== atual.escudo || ab.elmo !== atual.elmo)) {
      ab.restante = null;
    }
    return data;
  }

  // arrastar itens dos compendios para a ficha
  async _onDropItem(event, item) {
    if (!this.actor.isOwner) return null;
    const src = this.actor.toObject().system;
    const aviso = function (t) { ui.notifications.warn(t); };
    switch (item.type) {
      case "habilidade": {
        if (src.habilidades.some(function (h) { return h.nome === item.name; })) { aviso("A ficha já tem a habilidade " + item.name + "."); return null; }
        src.habilidades.push({nome: item.name, nivel: 1});
        return this.actor.update({"system.habilidades": src.habilidades});
      }
      case "magia": {
        if (src.magias.some(function (m) { return m.nome === item.name; })) { aviso("A ficha já tem a magia " + item.name + "."); return null; }
        src.magias.push({nome: item.name, nivel: 1});
        return this.actor.update({"system.magias": src.magias});
      }
      case "arma": {
        src.armas.push({nome: item.name, grupo: "", alcance: "", nivel: 0});
        await this.actor.update({"system.armas": src.armas});
        const dados = item.toObject(); delete dados._id;
        return this.actor.createEmbeddedDocuments("Item", [dados]);
      }
      case "armadura": {
        const campo = {armadura: "armadura", escudo: "escudo", elmo: "elmo"}[item.system.categoria];
        if (!campo) return null;
        await this.actor.update({["system.absorcao." + campo]: item.name, "system.absorcao.restante": null});
        const dados = item.toObject(); delete dados._id;
        return this.actor.createEmbeddedDocuments("Item", [dados]);
      }
      case "raca": {
        const s = item.system;
        const prof = achaProfissao(src.profissao);
        if (prof && RACAS[item.name] && RACAS[item.name].profissoes.indexOf(prof) < 0) aviso(item.name + " não podem ser " + prof + " (tabela II-4.7).");
        return this.actor.update({
          "system.raca": item.name,
          "system.caracteristicas.intelecto.racial": s.intelecto, "system.caracteristicas.aura.racial": s.aura,
          "system.caracteristicas.carisma.racial": s.carisma, "system.caracteristicas.forca.racial": s.forca,
          "system.caracteristicas.fisico.racial": s.fisico, "system.caracteristicas.agilidade.racial": s.agilidade
        });
      }
      case "equipamento": {
        // Itens reais do Foundry: preserva preco, descricao e demais dados do compendio.
        const dados = item.toObject();
        delete dados._id;
        return this.actor.createEmbeddedDocuments("Item", [dados]);
      }
      case "profissao": {
        const raca = achaRaca(src.raca);
        if (raca && RACAS[raca].profissoes.indexOf(item.name) < 0) aviso(raca + " não podem ser " + item.name + " (tabela II-4.7).");
        return this.actor.update({"system.profissao": item.name});
      }
      default:
        return null;
    }
  }

  // Controles de token: usam documentos e interfaces nativos do Foundry VTT 14.
  // As acoes sao opcionais e nao modificam as regras de Tagmar.
  static #tokenAtivo(actor) {
    const tokens = actor.getActiveTokens?.() ?? [];
    return tokens.find(t => t.controlled) ?? tokens[0] ?? null;
  }

  // Foundry VTT 14: usar a acao nativa de ActorSheetV2 para o token
  // PROTOTIPO. TokenConfig configura um token colocado em uma cena e nao
  // aceita o PrototypeToken (DataModel) como DocumentSheetV2.document.
  static async #configurarToken(event, target) {
    event?.preventDefault?.();
    if (!this.actor.isOwner) return ui.notifications.warn("Sem permissao para configurar este personagem.");
    try {
      const acaoNativa = ActorSheetV2.DEFAULT_OPTIONS?.actions?.configurePrototypeToken;
      if (typeof acaoNativa !== "function") {
        return ui.notifications.error("Acao nativa de token prototipo indisponivel nesta versao do Foundry.");
      }
      await acaoNativa.call(this, event, target);
    } catch (erro) {
      console.error("Tagmar | Configuracao do token prototipo", erro);
      ui.notifications.error("Falha ao configurar o token prototipo. Consulte o console F12.");
    }
  }

  // Usa o navegador de imagens do Foundry, que permite upload do computador
  // conforme as permissoes do usuario, sem alterar itens ou regras de jogo.
  static async #selecionarRetrato(event, target) {
    event?.preventDefault?.();
    if (!this.actor.isOwner) return ui.notifications.warn("Sem permissao para alterar o retrato.");
    try {
      const Picker = foundry.applications?.apps?.FilePicker?.implementation ?? globalThis.FilePicker;
      if (!Picker) return ui.notifications.error("Navegador de arquivos indisponivel.");
      const picker = new Picker({
        type: "image",
        current: this.actor.img,
        callback: async (path) => { if (path) await this.actor.update({img: path}); }
      });
      await picker.render(true);
    } catch (erro) {
      console.error("Tagmar | Selecao de retrato", erro);
      ui.notifications.error("Falha ao abrir o navegador de imagens. Consulte F12.");
    }
  }

  static async #localizarToken(event, target) {
    if (!canvas?.ready) return ui.notifications.warn("Abra uma cena antes de localizar o token.");
    const token = TagmarFicha.#tokenAtivo(this.actor);
    if (!token) return ui.notifications.warn("Este personagem nao possui token na cena atual.");
    canvas.animatePan({x: token.center.x, y: token.center.y, scale: canvas.stage.scale.x});
    if (token.isOwner) token.control({releaseOthers: true});
  }

  static async #criarToken(event, target) {
    if (!game.user.isGM) return ui.notifications.warn("Somente o Mestre pode criar tokens por este botao.");
    if (!canvas?.ready || !canvas.scene) return ui.notifications.warn("Abra uma cena antes de criar um token.");
    try {
      const posicao = canvas.stage?.pivot ?? {x: 0, y: 0};
      const token = await this.actor.getTokenDocument({x: Math.max(0, Math.round(posicao.x)), y: Math.max(0, Math.round(posicao.y))});
      await canvas.scene.createEmbeddedDocuments("Token", [token.toObject()]);
      ui.notifications.info("Token criado no centro da visualizacao. Ajuste sua posicao na cena.");
    } catch (erro) {
      console.error("Tagmar | Criacao do token", erro);
      ui.notifications.error("Nao foi possivel criar o token. Consulte F12.");
    }
  }

  static async #alternarToken(event, target) {
    if (!game.user.isGM) return ui.notifications.warn("Somente o Mestre pode alterar a visibilidade do token.");
    if (!canvas?.ready) return ui.notifications.warn("Abra uma cena antes de alterar o token.");
    const token = TagmarFicha.#tokenAtivo(this.actor);
    if (!token) return ui.notifications.warn("Este personagem nao possui token na cena atual.");
    try {
      await token.document.update({hidden: !token.document.hidden});
    } catch (erro) {
      console.error("Tagmar | Visibilidade do token", erro);
      ui.notifications.error("Nao foi possivel alterar a visibilidade do token. Consulte F12.");
    }
  }

  static async #addItem(event, target) {
    const tipo = target.dataset.tipo;
    const lista = this.actor.toObject().system[tipo];
    lista.push(foundry.utils.deepClone(NOVOS[tipo]));
    await this.actor.update({["system." + tipo]: lista});
  }

  static async #delItem(event, target) {
    const tipo = target.dataset.tipo;
    const lista = this.actor.toObject().system[tipo];
    lista.splice(Number(target.dataset.index), 1);
    await this.actor.update({["system." + tipo]: lista});
  }

  static async #abrirPertence(event, target) {
    const item = this.actor.items.get(target.dataset.itemId);
    if (item) item.sheet.render(true);
  }

  static async #mostrarPertence(event, target) {
    const item = this.actor.items.get(target.dataset.itemId);
    if (!item) return;
    const escapar = (valor) => foundry.utils.escapeHTML(String(valor ?? ""));
    const descricao = item.system?.descricao ?? item.system?.description ?? "";
    const conteudo = `<article class="tagmar-item-chat"><h3>${escapar(item.name)}</h3><p><strong>Tipo:</strong> ${escapar(item.type)}</p>${descricao ? `<p>${escapar(descricao)}</p>` : ""}</article>`;
    await ChatMessage.create({
      user: game.user.id,
      speaker: ChatMessage.getSpeaker({actor: this.actor}),
      content: conteudo
    });
  }

  // Compartilha a descricao oficial sem modificar o compendio nem gastar Karma.
  static async #mostrarMagia(event, target) {
    const indice = Number(target.dataset.index);
    const magia = this.actor.system.magias?.[indice];
    if (!Number.isInteger(indice) || indice < 0 || !magia?.nome) return;
    const escapar = (valor) => foundry.utils.escapeHTML(String(valor ?? ""));
    const dados = MAGIAS[magia.nome];
    const descricao = descricaoVerificadaDaMagia(magia.nome);
    const detalhes = [
      ["Nivel", magia.nivel],
      ["Evocacao", dados?.evocacao],
      ["Alcance", dados?.alcance],
      ["Duracao", dados?.duracao]
    ].filter(([, valor]) => valor !== undefined && valor !== null && valor !== "")
      .map(([rotulo, valor]) => `<p><strong>${escapar(rotulo)}:</strong> ${escapar(valor)}</p>`).join("");
    const texto = descricao
      ? `<div style="white-space:pre-wrap">${escapar(descricao)}</div>`
      : "<p>Descricao oficial nao encontrada para esta magia.</p>";
    await ChatMessage.create({
      user: game.user.id,
      speaker: ChatMessage.getSpeaker({actor: this.actor}),
      content: `<article class="tagmar-magia-chat"><h3>${escapar(magia.nome)}</h3>${detalhes}${texto}</article>`
    });
  }

  static async #removerPertence(event, target) {
    if (!this.actor.isOwner) return;
    const item = this.actor.items.get(target.dataset.itemId);
    if (!item || !["equipamento", "arma", "armadura"].includes(item.type)) return;
    const confirmar = await foundry.applications.api.DialogV2.confirm({
      window: {title: "Remover pertence"},
      content: `<p>Remover <strong>${foundry.utils.escapeHTML(item.name)}</strong> da ficha?</p>`,
      modal: true
    });
    if (confirmar) await item.delete();
  }

  static async #testarHabilidade(event, target) { await testarHabilidade(this.actor, Number(target.dataset.index)); }
  static async #rolarIniciativa(event, target) {
    // Usa o encontro nativo para que trackers como Carousel recebam o mesmo valor.
    const combate = game.combat;
    if (!combate) { ui.notifications.warn("Crie ou abra um encontro no Combat Tracker antes de rolar iniciativa."); return; }
    const tokens = this.actor.getActiveTokens();
    const combatente = combate.combatants.find(c => c.actor?.id === this.actor.id && (!tokens.length || tokens.some(t => t.id === c.tokenId)));
    if (!combatente) { ui.notifications.warn("Adicione o token deste personagem ao encontro antes de rolar iniciativa."); return; }
    try {
      await combate.rollInitiative([combatente.id]);
    } catch (erro) {
      console.error("tagmar1e | falha na iniciativa nativa", erro);
      ui.notifications.error("Não foi possível rolar iniciativa no encontro. Veja o console (F12).");
    }
  }
  static async #comprarGrupo(event, target) {
    const codigo = target.dataset.grupo;
    const info = GRUPOS_ARMAS[codigo];
    const s = this.actor.system;
    if (!info || !this.actor.isOwner) return;
    const atual = s.niveisGrupos?.[codigo] || 0;
    if (s.pontosCombate.disponiveis === null) { ui.notifications.warn("Informe uma profissão válida antes de comprar níveis."); return; }
    const erroCompra = validarCompraNivel({nivelAtual: atual, estagio: s.estagio, custo: info.custo,
      disponiveis: s.pontosCombate.disponiveis, gastos: s.pontosCombate.gastos});
    if (erroCompra) { ui.notifications.warn(erroCompra); return; }
    const confirmar = await foundry.applications.api.DialogV2.confirm({window: {title: "Comprar nível de grupo"}, content: `<p>Comprar nível ${atual + 1} de <b>${info.nome}</b> por <b>${info.custo}</b> ponto(s) de combate?</p>`, rejectClose: false});
    if (!confirmar) return;
    const atualAgora = this.actor.system.niveisGrupos?.[codigo] || 0;
    const saldoAgora = this.actor.system.pontosCombate;
    const erroAtual = validarCompraConfirmada({nivelInicial: atual, nivelAtual: atualAgora, estagio: this.actor.system.estagio,
      custo: info.custo, disponiveis: saldoAgora.disponiveis, gastos: saldoAgora.gastos});
    if (erroAtual) { ui.notifications.warn(erroAtual); return; }
    // Sincroniza armas antigas do grupo para evitar nivel individual divergente.
    const armas = this.actor.toObject().system.armas;
    for (const arma of armas) if (ARMA_INFO[arma.nome]?.grupo === codigo) arma.nivel = Math.max(arma.nivel, atual + 1);
    await this.actor.update({[`system.gruposArmas.${codigo}`]: atual + 1, "system.armas": armas});
  }
  static async #atacar(event, target) { await atacar(this.actor, Number(target.dataset.index)); }
  static async #aplicarDano(event, target) { await aplicarDano(this.actor); }
  static async #aplicarDanoNoAlvo(event, target) { await aplicarDanoNoAlvo(); }
  static async #restaurarAbsorcao(event, target) { await this.actor.update({"system.absorcao.restante": null}); }
  static async #rolarEH(event, target) { await rolarEH(this.actor); }
  static async #subirEstagio(event, target) { await subirEstagio(this.actor); }
  static async #sortearAlturaPeso(event, target) { await sortearAlturaPeso(this.actor); }
  static async #sortearClasseSocial(event, target) { await sortearClasseSocial(this.actor); }
  static async #pedirIngresso(event, target) { await pedirIngresso(this.actor); }
  static async #queda(event, target) { await queda(this.actor); }
  static async #dinheiroInicial(event, target) { await dinheiroInicial(this.actor); }
  static async #comprar(event, target) { await comprar(this.actor); }
  static async #reacaoCriatura(event, target) { await reacaoCriatura(this.actor); }
  static async #evocarMagia(event, target) { await evocarMagia(this.actor, Number(target.dataset.index)); }
  static async #testarResistencia(event, target) { await testarResistencia(this.actor); }
  static async #aplicarEF(event, target) {
    const v = this.actor.system.efTabela;
    if (!v) { ui.notifications.warn("Sem EF calculada: informe o peso e confira Força e Físico."); return; }
    await this.actor.update({"system.ef.max": v, "system.ef.value": v});
  }
}
