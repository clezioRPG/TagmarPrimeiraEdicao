// Tagmar 1a edicao - ATAQUE completo (macro de script, Foundry VTT). Sem crases, para copiar e colar sem quebrar.
// Usa: Tabela de Resolucao, Tabela IV-8.2 (ataque x defesa), IV-10.3a/b (dano) e as tabelas de critico e falha.
// Voce informa Agilidade e Forca FINAIS da ficha; o macro converte em ajuste (tabela II-5.8).
// Coluna final = nivel no grupo + ajuste de Agilidade + valor da arma contra a Defesa do alvo (+ ajuste extra).
// Dano de cada porcentagem = (dano maximo da arma x %) + ajuste de Forca.
const COLS = {"-7": "VVVVVVBBBBBBBBYYLRAC", "-6": "VVVVVBBBBBBBBYYYLRAC", "-5": "VVVVBBBBBBBBYYYYLRAC", "-4": "VVVBBBBBBBBBYYYLLRAC", "-3": "VVVBBBBBBBBYYYYLLRAC", "-2": "VVVBBBBBBBBYYYLLRRAC", "-1": "VVBBBBBBBBYYYYLLRRAC", "0": "VVBBBBBBBBYYYLLLRRAC", "1": "VBBBBBBBBYYYYLLRRAAC", "2": "VBBBBBBBBYYYLLLRRAAC", "3": "VBBBBBBBYYYYLLLRRAAC", "4": "VBBBBBBBYYYLLLRRRAAC", "5": "VBBBBBBYYYYLLLRRAAAC", "6": "VBBBBBBYYYLLLLRRAAAC", "7": "VBBBBBYYYYLLLRRRAAAC", "8": "VBBBBBYYYLLLLRRRAAAC", "9": "VBBBBYYYYLLLLRRAAAAC", "10": "VBBBBYYYLLLLRRRAAAAC", "11": "VBBBYYYYLLLLRRRAAAAC", "12": "VBBBYYYLLLLLRRRAAAAC", "13": "VBBYYYYLLLLRRRAAAACC", "14": "VBBYYYLLLLLRRRAAAACC", "15": "VBYYYYLLLLLRRRAAAACC", "16": "VBYYYLLLLLRRRRAAAACC", "17": "VYYYYLLLLLRRRAAAAACC", "18": "VYYYLLLLLRRRRAAAAACC", "19": "VYYYLLLLLRRRRAAAAACC", "20": "VYYLLLLLRRRRRAAAAACC"};
const CRIT = {"corte": {"cinza": "Oponente é decapitado.", "azul": "100% de dano. Corte vara um olho. A dor paralisa o adversário por duas rodadas.", "vermelho": "75% de dano. Corte no músculo do braço inutiliza o mesmo por uma semana.", "laranja": "75% de dano. Corte na cabeça põe adversário em coma por um dia se o mesmo não estiver usando elmo.", "amarelo": "50% de dano. Com um belo golpe, não só atinge o inimigo, como também o desarma.", "branco": "50% de dano. Corte no ombro impõe um ajuste de -4 por 1 dia.", "verde": "25% de dano. Corte no músculo do braço dá um ajuste de -4 na próxima rodada."}, "esmagamento": {"cinza": "Afundamento torácico destrói os pulmões do adversário.", "azul": "100% de dano. Golpe no pulso destrói a articulação, obrigando à amputação em 2 dias. O inimigo é paralisado por uma rodada.", "vermelho": "75% de dano. Pancada na cabeça. Elmo se parte (caso não seja mágico). Se não estiver de elmo, entra em coma por dois dias.", "laranja": "75% de dano. Escudo do inimigo se quebra (caso não seja mágico). Na ausência deste, seu braço se quebra (cura em 1 mês).", "amarelo": "50% de dano. Golpe no tórax derruba o adversário, que deixa cair sua arma (ou o que estiver segurando).", "branco": "50% de dano. Golpe duro no ombro paralisa o oponente na próxima rodada.", "verde": "25% de dano. Golpe no tronco desequilibra o adversário na próxima rodada, dando um ajuste de -4."}, "penetracao": {"cinza": "Golpe certeiro perfura o coração.", "azul": "100% de dano. Estocada na mão a inutiliza permanentemente. A dor paralisa o inimigo por duas rodadas.", "vermelho": "75% de dano. Perfuração no músculo do braço o inutiliza por uma semana.", "laranja": "75% de dano. Golpe no tronco derruba adversário que estiver usando escudo. Caso contrário, incapacita-o por 2 dias.", "amarelo": "50% de dano. Estocada no peito paralisa o adversário pelas próximas 3 rodadas.", "branco": "50% de dano. Penetração causa ajuste de -4 por dois dias. Se for flecha, o ajuste será de -6 até a mesma ser retirada.", "verde": "25% de dano. Estocada na perna reduz o movimento à metade e causa um ajuste de -2 por uma hora."}, "garras": {"cinza": "Força do golpe rasga a jugular.", "azul": "100% de dano. Ataque ao olho rasga o globo ocular, paralisando o adversário por duas rodadas.", "vermelho": "75% de dano. Ataque rasga o braço causando ajuste de -8 por 2 dias.", "laranja": "75% de dano. A ferocidade do golpe derruba o adversário impedindo-o de atacar pelas próximas 3 rodadas.", "amarelo": "75% de dano. Feroz ataque à mão desarma o inimigo.", "branco": "50% de dano. Rasgo na mão impede o adversário de realizar o seu próximo ataque.", "verde": "25% de dano. Ataque desequilibra o inimigo, levando-o a cair e a perder uma rodada."}, "magia": {"cinza": "Impacto total da magia mata o adversário.", "azul": "100% de dano. Impacto no pé causa a destruição do mesmo. O adversário fica paralisado por duas rodadas.", "vermelho": "75% de dano. Poder da magia leva o inimigo à inconsciência por meia hora.", "laranja": "75% de dano. Potente impacto paralisa o adversário, impedindo-o de atacar por 3 rodadas.", "amarelo": "50% de dano. A força da magia arremessa o adversário a 2 metros de distância, fazendo com que ele deixe cair sua arma.", "branco": "50% de dano. Impacto no braço causa um ajuste de -4 por um dia.", "verde": "25% de dano. Poder da magia atordoa o inimigo, impedindo que o mesmo realize o seu próximo ataque."}};
const FALHA = {"cinza": "Em um golpe ruim, erra o adversário.", "azul": "O descontrole lhe dá um ajuste de -4 nas próximas 3 rodadas.", "vermelho": "Ataque precipitado causa 25% de dano em si mesmo.", "laranja": "Ataque desastroso causa 50% de dano em si mesmo.", "amarelo": "Sua arma escapa de suas mãos, caindo a 3 metros de distância.", "branco": "Tropeção o impede de realizar o seu próximo ataque.", "verde": "Faça um ataque no seu companheiro mais próximo."};
// arma: [valor na defesa 1, valor na defesa 9, valor na defesa 16 (cada faixa cai 1 por defesa), dano maximo]
const ARMAS = {"Faca": [1, -3, -6, 8], "Punhal": [1, -2, -5, 12], "Cajado": [1, -1, -4, 12], "Porrete": [2, -1, -5, 12], "Machado": [2, -1, -4, 16], "Machado de guerra": [1, 3, 1, 20], "Gládio": [3, 0, -4, 16], "Espada": [3, 0, -3, 20], "Clava": [2, -1, -5, 16], "Maça": [0, 1, -2, 20], "Martelo de guerra": [0, 1, -1, 16], "Lança leve": [2, -1, -3, 16], "Lança pesada": [1, -1, -3, 20], "Arco simples": [4, 1, -2, 16], "Arco composto": [4, 1, -2, 20], "Espada de mão e meia (uma mão)": [2, 1, -1, 20], "Espada de mão e meia (duas mãos)": [0, 0, 1, 20], "Montante": [0, 2, 5, 24], "Maça de armas": [1, 2, 0, 20], "Mangual": [-2, 1, 4, 24], "Lança de cavalaria": [-1, 1, 4, 24]};

const COR = {
  V: {nome: "Verde",    hex: "#2d8d24", fg: "#fff", txt: "FALHA", pct: 0},
  B: {nome: "Branco",   hex: "#fbfbfc", fg: "#222", txt: "Errou o golpe", pct: 0},
  Y: {nome: "Amarelo",  hex: "#ea9d26", fg: "#222", txt: "25% do dano máximo", pct: 25},
  L: {nome: "Laranja",  hex: "#e46c23", fg: "#fff", txt: "50% do dano máximo", pct: 50},
  R: {nome: "Vermelho", hex: "#d7261a", fg: "#fff", txt: "75% do dano máximo", pct: 75},
  A: {nome: "Azul",     hex: "#1a719c", fg: "#fff", txt: "100% do dano máximo", pct: 100},
  C: {nome: "Cinza",    hex: "#93989c", fg: "#fff", txt: "CRÍTICO", pct: 0}
};
const CHAVE = {V: "verde", B: "branco", Y: "amarelo", L: "laranja", R: "vermelho", A: "azul", C: "cinza"};

function badge(letra, n) {
  const c = COR[letra];
  return '<span style="display:inline-block;min-width:1.6em;text-align:center;padding:1px 8px;border:1px solid #000;border-radius:3px;background:' + c.hex + ';color:' + c.fg + ';font-weight:bold">' + n + '</span> <b>' + c.nome + '</b>';
}

function valorContraDefesa(arma, defesa) {
  const s = ARMAS[arma];
  const seg = defesa <= 8 ? 0 : (defesa <= 15 ? 1 : 2);
  const inicio = [1, 9, 16][seg];
  return s[seg] - (defesa - inicio);
}

// Tabela II-5.8: valor da caracteristica -> ajuste
function ajusteDe(v) {
  if (v < 3) return -7;
  if (v <= 4) return -5;
  if (v <= 6) return -3;
  if (v <= 8) return -1;
  if (v <= 12) return 0;
  if (v <= 15) return 1;
  if (v <= 17) return 2;
  if (v <= 19) return 3;
  if (v === 20) return 4;
  if (v === 21) return 5;
  return 6;
}

function danoDe(arma, pct, forca) {
  return Math.round(ARMAS[arma][3] * pct / 100) + forca;
}

async function pedirDados() {
  let opArmas = "";
  for (const nome of Object.keys(ARMAS)) { opArmas += '<option value="' + nome + '">' + nome + '</option>'; }
  const html =
    '<div style="display:grid;grid-template-columns:auto 1fr;gap:6px 10px;align-items:center">' +
    '<label>Arma</label><select name="arma" style="width:100%">' + opArmas + '</select>' +
    '<label>Nível no grupo</label><input type="number" name="nivel" value="0" style="width:100%">' +
    '<label>Agilidade (final)</label><input type="number" name="agi" value="11" style="width:100%">' +
    '<label>Força (final)</label><input type="number" name="forca" value="11" style="width:100%">' +
    '<label>Defesa do alvo</label><input type="number" name="defesa" value="10" min="1" max="21" style="width:100%">' +
    '<label>Ajuste extra</label><input type="number" name="extra" value="0" style="width:100%">' +
    '<label>Tipo de crítico</label><select name="tipo" style="width:100%">' +
    '<option value="corte">Corte</option><option value="esmagamento">Esmagamento</option>' +
    '<option value="penetracao">Penetração</option><option value="garras">Garras (animais)</option>' +
    '<option value="magia">Magia (ataque energético)</option></select>' +
    '</div>';
  const ler = function (f) {
    return {arma: f.arma.value, nivel: Number(f.nivel.value), agi: Number(f.agi.value), forca: Number(f.forca.value),
            defesa: Number(f.defesa.value), extra: Number(f.extra.value), tipo: f.tipo.value};
  };
  const DV2 = foundry && foundry.applications && foundry.applications.api && foundry.applications.api.DialogV2;
  if (DV2) {
    return DV2.prompt({
      window: {title: "Tagmar 1ª ed. - Ataque"},
      content: html,
      ok: {label: "Atacar", callback: function (ev, button) { return ler(button.form.elements); }},
      rejectClose: false
    });
  }
  return new Promise(function (resolve) {
    new Dialog({
      title: "Tagmar 1ª ed. - Ataque",
      content: "<form>" + html + "</form>",
      buttons: {ok: {label: "Atacar", callback: function (h) { resolve(ler(h.find("form")[0].elements)); }}},
      default: "ok",
      close: function () { resolve(null); }
    }).render(true);
  });
}

async function rolarNaColuna(col, flavor) {
  const roll = await new Roll("1d20").evaluate();
  const n = roll.total;
  const letra = COLS[String(col)][n - 1];
  await roll.toMessage({
    speaker: ChatMessage.getSpeaker(),
    flavor: flavor + "<br>Coluna <b>" + col + "</b>: " + badge(letra, n)
  });
  return {n: n, letra: letra};
}

function pctDoTexto(texto, regex) {
  const m = texto.match(regex);
  return m ? Number(m[1]) : null;
}

const dados = await pedirDados();
const valido = dados && ARMAS[dados.arma] && [dados.nivel, dados.agi, dados.forca, dados.defesa, dados.extra].every(Number.isFinite);
if (valido) {
  const defAv = Math.max(1, Math.min(21, Math.round(dados.defesa)));
  const aviso = defAv !== dados.defesa ? " (Defesa limitada a " + defAv + ")" : "";
  const aAgi = ajusteDe(dados.agi);
  const aFor = ajusteDe(dados.forca);
  const vArma = valorContraDefesa(dados.arma, defAv);
  const bruta = Math.round(dados.nivel + aAgi + vArma + dados.extra);
  const col = Math.max(-7, Math.min(20, bruta));
  const avCol = col !== bruta ? " (coluna limitada de " + bruta + ")" : "";
  const resumo = "<b>" + dados.arma + "</b> vs Defesa " + defAv + aviso + "<br>Coluna: " + dados.nivel + " (nível) + " + aAgi + " (Agi " + dados.agi + ") + " + vArma + " (arma) + " + dados.extra + " (extra) = <b>" + col + "</b>" + avCol + "<br>Ajuste de Força: " + aFor + " (Força " + dados.forca + ")";

  const r1 = await rolarNaColuna(col, resumo);
  let msg;
  const c1 = COR[r1.letra];
  if (c1.pct > 0) {
    msg = "<b>" + c1.txt + "</b>: dano <b>" + danoDe(dados.arma, c1.pct, aFor) + "</b> (na Energia Heróica; quando ela acabar, na Física, descontando a absorção da armadura)";
  } else if (r1.letra === "B") {
    msg = "<b>Errou o golpe.</b>";
  } else {
    const ehCrit = r1.letra === "C";
    const r2 = await rolarNaColuna(col, ehCrit ? "<b>Crítico</b> (" + dados.tipo + ")" : "<b>Falha</b>");
    const tabela = ehCrit ? CRIT[dados.tipo] : FALHA;
    const efeito = tabela[CHAVE[r2.letra]];
    if (ehCrit) {
      const p = pctDoTexto(efeito, /^(\d+)% de dano/);
      const dano = p ? " <b>Dano: " + danoDe(dados.arma, p, aFor) + "</b> direto na Energia Física, ignorando a armadura." : "";
      msg = "<b>CRÍTICO (" + dados.tipo + "):</b> " + efeito + "<br>" + dano.trim();
    } else {
      const p = pctDoTexto(efeito, /(\d+)% de dano em si/);
      const dano = p ? "<br><b>Você sofre " + danoDe(dados.arma, p, aFor) + " de dano.</b>" : "";
      msg = "<b>FALHA:</b> " + efeito + dano;
    }
  }
  await ChatMessage.create({speaker: ChatMessage.getSpeaker(), content: msg});
}
