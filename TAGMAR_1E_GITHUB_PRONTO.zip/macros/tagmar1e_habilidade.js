// Tagmar 1a edicao - TESTE DE HABILIDADE (macro de script, Foundry VTT). Sem crases.
// Regra (cap. III, itens 4.2.1 a 4.2.3): a coluna e o Total na habilidade; a dificuldade e uma cor;
// sucesso = d20 igual ou maior que o menor numero daquela cor na coluna. Verde (d20 = 1) sempre falha.
// Cada nova tentativa depois de um fracasso sobe a dificuldade em 2 niveis.
const COLS = {"-7": "VVVVVVBBBBBBBBYYLRAC", "-6": "VVVVVBBBBBBBBYYYLRAC", "-5": "VVVVBBBBBBBBYYYYLRAC", "-4": "VVVBBBBBBBBBYYYLLRAC", "-3": "VVVBBBBBBBBYYYYLLRAC", "-2": "VVVBBBBBBBBYYYLLRRAC", "-1": "VVBBBBBBBBYYYYLLRRAC", "0": "VVBBBBBBBBYYYLLLRRAC", "1": "VBBBBBBBBYYYYLLRRAAC", "2": "VBBBBBBBBYYYLLLRRAAC", "3": "VBBBBBBBYYYYLLLRRAAC", "4": "VBBBBBBBYYYLLLRRRAAC", "5": "VBBBBBBYYYYLLLRRAAAC", "6": "VBBBBBBYYYLLLLRRAAAC", "7": "VBBBBBYYYYLLLRRRAAAC", "8": "VBBBBBYYYLLLLRRRAAAC", "9": "VBBBBYYYYLLLLRRAAAAC", "10": "VBBBBYYYLLLLRRRAAAAC", "11": "VBBBYYYYLLLLRRRAAAAC", "12": "VBBBYYYLLLLLRRRAAAAC", "13": "VBBYYYYLLLLRRRAAAACC", "14": "VBBYYYLLLLLRRRAAAACC", "15": "VBYYYYLLLLLRRRAAAACC", "16": "VBYYYLLLLLRRRRAAAACC", "17": "VYYYYLLLLLRRRAAAAACC", "18": "VYYYLLLLLRRRRAAAAACC", "19": "VYYYLLLLLRRRRAAAAACC", "20": "VYYLLLLLRRRRRAAAAACC"};
const NIVEIS = [
  {nome: "Rotineiro",     cor: "B"},
  {nome: "Fácil",         cor: "Y"},
  {nome: "Médio",         cor: "L"},
  {nome: "Difícil",       cor: "R"},
  {nome: "Muito difícil", cor: "A"},
  {nome: "Absurdo",       cor: "C"}
];
const RANK = {V: 0, B: 1, Y: 2, L: 3, R: 4, A: 5, C: 6};
const COR = {
  V: {nome: "Verde",    hex: "#2d8d24", fg: "#fff"},
  B: {nome: "Branco",   hex: "#fbfbfc", fg: "#222"},
  Y: {nome: "Amarelo",  hex: "#ea9d26", fg: "#222"},
  L: {nome: "Laranja",  hex: "#e46c23", fg: "#fff"},
  R: {nome: "Vermelho", hex: "#d7261a", fg: "#fff"},
  A: {nome: "Azul",     hex: "#1a719c", fg: "#fff"},
  C: {nome: "Cinza",    hex: "#93989c", fg: "#fff"}
};

function badge(letra, n) {
  const c = COR[letra];
  return '<span style="display:inline-block;min-width:1.6em;text-align:center;padding:1px 8px;border:1px solid #000;border-radius:3px;background:' + c.hex + ';color:' + c.fg + ';font-weight:bold">' + n + '</span> <b>' + c.nome + '</b>';
}

// menor resultado de d20 que da sucesso: primeira linha da coluna com cor igual ou melhor que a dificuldade (sem contar o verde)
function minimoParaSucesso(coluna, corAlvo) {
  const linhas = COLS[String(coluna)];
  for (let i = 0; i < 20; i++) {
    if (linhas[i] !== "V" && RANK[linhas[i]] >= RANK[corAlvo]) return i + 1;
  }
  return null;
}

async function pedirDados() {
  let opNiveis = "";
  for (let i = 0; i < NIVEIS.length; i++) { opNiveis += '<option value="' + i + '"' + (i === 2 ? " selected" : "") + '>' + NIVEIS[i].nome + '</option>'; }
  const html =
    '<div style="display:grid;grid-template-columns:auto 1fr;gap:6px 10px;align-items:center">' +
    '<label>Total na habilidade</label><input type="number" name="total" value="0" style="width:100%">' +
    '<label>Ajuste extra</label><input type="number" name="adj" value="0" style="width:100%">' +
    '<label>Dificuldade</label><select name="nivel" style="width:100%">' + opNiveis + '</select>' +
    '<label>Tentativa nº</label><input type="number" name="tent" value="1" min="1" style="width:100%">' +
    '</div>';
  const ler = function (f) {
    return {total: Number(f.total.value), adj: Number(f.adj.value), nivel: Number(f.nivel.value), tent: Math.max(1, Number(f.tent.value))};
  };
  const DV2 = foundry && foundry.applications && foundry.applications.api && foundry.applications.api.DialogV2;
  if (DV2) {
    return DV2.prompt({
      window: {title: "Tagmar 1ª ed. - Habilidade"},
      content: html,
      ok: {label: "Rolar d20", callback: function (ev, button) { return ler(button.form.elements); }},
      rejectClose: false
    });
  }
  return new Promise(function (resolve) {
    new Dialog({
      title: "Tagmar 1ª ed. - Habilidade",
      content: "<form>" + html + "</form>",
      buttons: {ok: {label: "Rolar d20", callback: function (h) { resolve(ler(h.find("form")[0].elements)); }}},
      default: "ok",
      close: function () { resolve(null); }
    }).render(true);
  });
}

const dados = await pedirDados();
if (dados && [dados.total, dados.adj, dados.nivel, dados.tent].every(Number.isFinite)) {
  const bruta = Math.round(dados.total + dados.adj);
  const col = Math.max(-7, Math.min(20, bruta));
  const avCol = col !== bruta ? " (coluna limitada de " + bruta + ")" : "";
  const idx = dados.nivel + 2 * (dados.tent - 1);
  if (idx >= NIVEIS.length) {
    await ChatMessage.create({speaker: ChatMessage.getSpeaker(), content: "<b>Impossível.</b> Depois de tantas tentativas a dificuldade passou do Absurdo: nenhum dado é rolado e a ação falha."});
  } else {
    const nivel = NIVEIS[idx];
    const minimo = minimoParaSucesso(col, nivel.cor);
    const roll = await new Roll("1d20").evaluate();
    const n = roll.total;
    const letra = COLS[String(col)][n - 1];
    const ok = letra !== "V" && minimo !== null && n >= minimo;
    const cabeca = "<b>Habilidade</b> - coluna <b>" + col + "</b>" + avCol + "<br>Dificuldade: <b>" + nivel.nome + "</b> (" + COR[nivel.cor].nome + "), tentativa " + dados.tent + "<br>Precisa de <b>" + (minimo === null ? "nenhum resultado serve" : minimo + " ou mais") + "</b> no d20";
    await roll.toMessage({speaker: ChatMessage.getSpeaker(), flavor: cabeca + "<br>Rolou: " + badge(letra, n)});
    let msg;
    if (letra === "V") {
      msg = "<b>FALHA</b> (verde). Algo terrível ou embaraçoso pode acontecer, a critério do Mestre.";
    } else if (ok) {
      msg = "<b>SUCESSO!</b>";
    } else {
      msg = "<b>Fracasso.</b> Se tentar de novo, a dificuldade sobe 2 níveis (próxima tentativa: nº " + (dados.tent + 1) + ").";
    }
    await ChatMessage.create({speaker: ChatMessage.getSpeaker(), content: msg});
  }
}
