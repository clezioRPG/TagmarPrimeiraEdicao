// Tagmar 1a edicao - DANO, ABSORCAO DE ARMADURA E ENERGIAS (macro de script, Foundry VTT). Sem crases.
// Regras (cap. IV, itens 10, 10.4 e 11): dano normal tira da Energia Heroica (EH); o que passa de zero some.
// Com a EH zerada, o dano vai na Energia Fisica (EF) e a armadura absorve primeiro (e se desgasta).
// Critico vai direto na EF e ignora a armadura. EF entre 0 e -7: inconsciente; abaixo de -7: morte.
// Interpretacao minha: a absorcao gasta e igual aos pontos de dano que ela recebe (1 para 1).
const ARMADURAS = {"Nenhuma": 0, "Couro leve": 3, "Couro rígido": 6, "Cota de malha parcial": 9, "Cota de malha completa": 12, "Couraça parcial": 15};
const ESCUDOS = {"Nenhum": 0, "Escudo pequeno": 3, "Escudo grande": 5};
const ELMOS = {"Nenhum": 0, "Elmo aberto": 1, "Elmo fechado": 2};

function opcoes(obj) {
  let h = "";
  for (const k of Object.keys(obj)) { h += '<option value="' + k + '">' + k + (obj[k] ? " (+" + obj[k] + ")" : "") + '</option>'; }
  return h;
}

async function pedirDados() {
  const html =
    '<div style="display:grid;grid-template-columns:auto 1fr;gap:6px 10px;align-items:center">' +
    '<label>EH atual</label><input type="number" name="eh" value="0" style="width:100%">' +
    '<label>EF atual</label><input type="number" name="ef" value="0" style="width:100%">' +
    '<label>Armadura</label><select name="arm" style="width:100%">' + opcoes(ARMADURAS) + '</select>' +
    '<label>Escudo</label><select name="esc" style="width:100%">' + opcoes(ESCUDOS) + '</select>' +
    '<label>Elmo</label><select name="elmo" style="width:100%">' + opcoes(ELMOS) + '</select>' +
    '<label>Absorção restante</label><input type="number" name="absr" value="" placeholder="vazio = total" style="width:100%">' +
    '<label>Dano recebido</label><input type="number" name="dano" value="0" min="0" style="width:100%">' +
    '<label>Tipo do golpe</label><select name="tipo" style="width:100%"><option value="normal">Normal</option><option value="critico">Crítico (direto na EF)</option></select>' +
    '</div>';
  const ler = function (f) {
    return {eh: Number(f.eh.value), ef: Number(f.ef.value), arm: f.arm.value, esc: f.esc.value, elmo: f.elmo.value,
            absr: f.absr.value === "" ? null : Number(f.absr.value), dano: Number(f.dano.value), tipo: f.tipo.value};
  };
  const DV2 = foundry && foundry.applications && foundry.applications.api && foundry.applications.api.DialogV2;
  if (DV2) {
    return DV2.prompt({
      window: {title: "Tagmar 1ª ed. - Dano e armadura"},
      content: html,
      ok: {label: "Aplicar dano", callback: function (ev, button) { return ler(button.form.elements); }},
      rejectClose: false
    });
  }
  return new Promise(function (resolve) {
    new Dialog({
      title: "Tagmar 1ª ed. - Dano e armadura",
      content: "<form>" + html + "</form>",
      buttons: {ok: {label: "Aplicar dano", callback: function (h) { resolve(ler(h.find("form")[0].elements)); }}},
      default: "ok",
      close: function () { resolve(null); }
    }).render(true);
  });
}

const d = await pedirDados();
const nums = d && [d.eh, d.ef, d.dano].every(Number.isFinite) && (d.absr === null || Number.isFinite(d.absr));
if (nums) {
  const total = ARMADURAS[d.arm] + ESCUDOS[d.esc] + ELMOS[d.elmo];
  let abs = d.absr === null ? total : Math.max(0, d.absr);
  let eh = d.eh, ef = d.ef;
  const dano = Math.max(0, d.dano);
  const linhas = [];
  if (d.tipo === "critico") {
    ef -= dano;
    linhas.push("Crítico: <b>" + dano + "</b> direto na EF, ignorando a armadura (ela não perde absorção).");
  } else if (eh > 0) {
    const perdido = Math.min(eh, dano);
    eh = Math.max(0, eh - dano);
    linhas.push("<b>" + perdido + "</b> de dano na Energia Heróica." + (dano > perdido ? " O excesso (" + (dano - perdido) + ") desaparece." : ""));
    if (eh === 0) linhas.push("EH zerada: os próximos golpes vão na Energia Física.");
  } else {
    const absorvido = Math.min(abs, dano);
    abs -= absorvido;
    const passou = dano - absorvido;
    ef -= passou;
    linhas.push("EH já zerada. Armadura absorveu <b>" + absorvido + "</b> e <b>" + passou + "</b> foi na EF.");
  }
  let estado = "";
  if (ef < -7) estado = "<br><b>MORTE imediata</b> (EF abaixo de -7).";
  else if (ef <= 0) estado = "<br><b>Inconsciente</b> (EF entre 0 e -7): morre em 1 hora sem cuidados médicos (Medicina, dificuldade média).";
  const msg = linhas.join("<br>") + "<br>Agora: <b>EH " + eh + "</b> | <b>EF " + ef + "</b> | <b>Absorção " + abs + "</b> de " + total + estado;
  await ChatMessage.create({speaker: ChatMessage.getSpeaker(), content: msg});
}
