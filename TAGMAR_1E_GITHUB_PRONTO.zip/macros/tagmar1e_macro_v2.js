// Tagmar 1a edicao - Teste na Tabela de Resolucao de Acoes (macro de script, Foundry VTT)
// Versao sem crases (backticks), para nao quebrar ao copiar e colar.
// V verde (falha) | B branco (errou) | Y amarelo 25% | L laranja 50% | R vermelho 75% | A azul 100% | C cinza (critico)
const COLS = {"-7": "VVVVVVBBBBBBBBYYLRAC", "-6": "VVVVVBBBBBBBBYYYLRAC", "-5": "VVVVBBBBBBBBYYYYLRAC", "-4": "VVVBBBBBBBBBYYYLLRAC", "-3": "VVVBBBBBBBBYYYYLLRAC", "-2": "VVVBBBBBBBBYYYLLRRAC", "-1": "VVBBBBBBBBYYYYLLRRAC", "0": "VVBBBBBBBBYYYLLLRRAC", "1": "VBBBBBBBBYYYYLLRRAAC", "2": "VBBBBBBBBYYYLLLRRAAC", "3": "VBBBBBBBYYYYLLLRRAAC", "4": "VBBBBBBBYYYLLLRRRAAC", "5": "VBBBBBBYYYYLLLRRAAAC", "6": "VBBBBBBYYYLLLLRRAAAC", "7": "VBBBBBYYYYLLLRRRAAAC", "8": "VBBBBBYYYLLLLRRRAAAC", "9": "VBBBBYYYYLLLLRRAAAAC", "10": "VBBBBYYYLLLLRRRAAAAC", "11": "VBBBYYYYLLLLRRRAAAAC", "12": "VBBBYYYLLLLLRRRAAAAC", "13": "VBBYYYYLLLLRRRAAAACC", "14": "VBBYYYLLLLLRRRAAAACC", "15": "VBYYYYLLLLLRRRAAAACC", "16": "VBYYYLLLLLRRRRAAAACC", "17": "VYYYYLLLLLRRRAAAAACC", "18": "VYYYLLLLLRRRRAAAAACC", "19": "VYYYLLLLLRRRRAAAAACC", "20": "VYYLLLLLRRRRRAAAAACC"};
const CRIT = {"corte": {"cinza": "Oponente é decapitado.", "azul": "100% de dano. Corte vara um olho. A dor paralisa o adversário por duas rodadas.", "vermelho": "75% de dano. Corte no músculo do braço inutiliza o mesmo por uma semana.", "laranja": "75% de dano. Corte na cabeça põe adversário em coma por um dia se o mesmo não estiver usando elmo.", "amarelo": "50% de dano. Com um belo golpe, não só atinge o inimigo, como também o desarma.", "branco": "50% de dano. Corte no ombro impõe um ajuste de -4 por 1 dia.", "verde": "25% de dano. Corte no músculo do braço dá um ajuste de -4 na próxima rodada."}, "esmagamento": {"cinza": "Afundamento torácico destrói os pulmões do adversário.", "azul": "100% de dano. Golpe no pulso destrói a articulação, obrigando à amputação em 2 dias. O inimigo é paralisado por uma rodada.", "vermelho": "75% de dano. Pancada na cabeça. Elmo se parte (caso não seja mágico). Se não estiver de elmo, entra em coma por dois dias.", "laranja": "75% de dano. Escudo do inimigo se quebra (caso não seja mágico). Na ausência deste, seu braço se quebra (cura em 1 mês).", "amarelo": "50% de dano. Golpe no tórax derruba o adversário, que deixa cair sua arma (ou o que estiver segurando).", "branco": "50% de dano. Golpe duro no ombro paralisa o oponente na próxima rodada.", "verde": "25% de dano. Golpe no tronco desequilibra o adversário na próxima rodada, dando um ajuste de -4."}, "penetracao": {"cinza": "Golpe certeiro perfura o coração.", "azul": "100% de dano. Estocada na mão a inutiliza permanentemente. A dor paralisa o inimigo por duas rodadas.", "vermelho": "75% de dano. Perfuração no músculo do braço o inutiliza por uma semana.", "laranja": "75% de dano. Golpe no tronco derruba adversário que estiver usando escudo. Caso contrário, incapacita-o por 2 dias.", "amarelo": "50% de dano. Estocada no peito paralisa o adversário pelas próximas 3 rodadas.", "branco": "50% de dano. Penetração causa ajuste de -4 por dois dias. Se for flecha, o ajuste será de -6 até a mesma ser retirada.", "verde": "25% de dano. Estocada na perna reduz o movimento à metade e causa um ajuste de -2 por uma hora."}, "garras": {"cinza": "Força do golpe rasga a jugular.", "azul": "100% de dano. Ataque ao olho rasga o globo ocular, paralisando o adversário por duas rodadas.", "vermelho": "75% de dano. Ataque rasga o braço causando ajuste de -8 por 2 dias.", "laranja": "75% de dano. A ferocidade do golpe derruba o adversário impedindo-o de atacar pelas próximas 3 rodadas.", "amarelo": "75% de dano. Feroz ataque à mão desarma o inimigo.", "branco": "50% de dano. Rasgo na mão impede o adversário de realizar o seu próximo ataque.", "verde": "25% de dano. Ataque desequilibra o inimigo, levando-o a cair e a perder uma rodada."}, "magia": {"cinza": "Impacto total da magia mata o adversário.", "azul": "100% de dano. Impacto no pé causa a destruição do mesmo. O adversário fica paralisado por duas rodadas.", "vermelho": "75% de dano. Poder da magia leva o inimigo à inconsciência por meia hora.", "laranja": "75% de dano. Potente impacto paralisa o adversário, impedindo-o de atacar por 3 rodadas.", "amarelo": "50% de dano. A força da magia arremessa o adversário a 2 metros de distância, fazendo com que ele deixe cair sua arma.", "branco": "50% de dano. Impacto no braço causa um ajuste de -4 por um dia.", "verde": "25% de dano. Poder da magia atordoa o inimigo, impedindo que o mesmo realize o seu próximo ataque."}};
const FALHA = {"cinza": "Em um golpe ruim, erra o adversário.", "azul": "O descontrole lhe dá um ajuste de -4 nas próximas 3 rodadas.", "vermelho": "Ataque precipitado causa 25% de dano em si mesmo.", "laranja": "Ataque desastroso causa 50% de dano em si mesmo.", "amarelo": "Sua arma escapa de suas mãos, caindo a 3 metros de distância.", "branco": "Tropeção o impede de realizar o seu próximo ataque.", "verde": "Faça um ataque no seu companheiro mais próximo."};

const COR = {
  V: {nome: "Verde",    hex: "#2d8d24", fg: "#fff", txt: "FALHA"},
  B: {nome: "Branco",   hex: "#fbfbfc", fg: "#222", txt: "Errou o golpe"},
  Y: {nome: "Amarelo",  hex: "#ea9d26", fg: "#222", txt: "25% do dano máximo"},
  L: {nome: "Laranja",  hex: "#e46c23", fg: "#fff", txt: "50% do dano máximo"},
  R: {nome: "Vermelho", hex: "#d7261a", fg: "#fff", txt: "75% do dano máximo"},
  A: {nome: "Azul",     hex: "#1a719c", fg: "#fff", txt: "100% do dano máximo"},
  C: {nome: "Cinza",    hex: "#93989c", fg: "#fff", txt: "CRÍTICO"}
};
const CHAVE = {V: "verde", B: "branco", Y: "amarelo", L: "laranja", R: "vermelho", A: "azul", C: "cinza"};

function badge(letra, n) {
  const c = COR[letra];
  return '<span style="display:inline-block;min-width:1.6em;text-align:center;padding:1px 8px;border:1px solid #000;border-radius:3px;background:' + c.hex + ';color:' + c.fg + ';font-weight:bold">' + n + '</span> <b>' + c.nome + '</b>';
}

async function pedirDados() {
  const html =
    '<div style="display:grid;grid-template-columns:auto 1fr;gap:6px 10px;align-items:center">' +
    '<label>Coluna</label><input type="number" name="col" value="0" min="-7" max="20" style="width:100%">' +
    '<label>Ajuste</label><input type="number" name="adj" value="0" style="width:100%">' +
    '<label>Modo</label><select name="modo" style="width:100%">' +
    '<option value="combate">Combate / ataque</option>' +
    '<option value="cor">Só a cor (habilidade)</option></select>' +
    '<label>Crítico</label><select name="tipo" style="width:100%">' +
    '<option value="corte">Corte</option>' +
    '<option value="esmagamento">Esmagamento</option>' +
    '<option value="penetracao">Penetração</option>' +
    '<option value="garras">Garras (animais)</option>' +
    '<option value="magia">Magia (ataque energético)</option></select>' +
    '</div>';
  const ler = function (f) {
    return {col: Number(f.col.value), adj: Number(f.adj.value), modo: f.modo.value, tipo: f.tipo.value};
  };
  const DV2 = foundry && foundry.applications && foundry.applications.api && foundry.applications.api.DialogV2;
  if (DV2) {
    return DV2.prompt({
      window: {title: "Tagmar 1ª ed. - Tabela de Resolução"},
      content: html,
      ok: {label: "Rolar d20", callback: function (ev, button) { return ler(button.form.elements); }},
      rejectClose: false
    });
  }
  return new Promise(function (resolve) {
    new Dialog({
      title: "Tagmar 1ª ed. - Tabela de Resolução",
      content: "<form>" + html + "</form>",
      buttons: {ok: {label: "Rolar d20", callback: function (h) { resolve(ler(h.find("form")[0].elements)); }}},
      default: "ok",
      close: function () { resolve(null); }
    }).render(true);
  });
}

async function rolarNaColuna(col, flavor) {
  const roll = await new Roll("1d20").evaluate();
  const n = roll.total;
  const letra = COLS[String(col)][n - 1];
  await roll.toMessage({
    speaker: ChatMessage.getSpeaker(),
    flavor: flavor + "<br>Coluna <b>" + col + "</b>: " + badge(letra, n)
  });
  return {n: n, letra: letra};
}

const dados = await pedirDados();
if (dados && Number.isFinite(dados.col)) {
  let col = Math.round(dados.col + (dados.adj || 0));
  const aviso = (col < -7 || col > 20) ? " (coluna limitada de " + col + ")" : "";
  col = Math.max(-7, Math.min(20, col));

  const r1 = await rolarNaColuna(col, "<b>Tagmar 1ª ed.</b>" + aviso);
  let msg = "<b>Resultado:</b> " + COR[r1.letra].txt;

  if (dados.modo === "combate" && (r1.letra === "C" || r1.letra === "V")) {
    const ehCrit = r1.letra === "C";
    const r2 = await rolarNaColuna(col, ehCrit ? "<b>Crítico</b> (" + dados.tipo + ")" : "<b>Falha</b>");
    const tabela = ehCrit ? CRIT[dados.tipo] : FALHA;
    const efeito = tabela[CHAVE[r2.letra]];
    msg = ehCrit
      ? "<b>CRÍTICO (" + dados.tipo + "):</b> " + efeito + "<br><i>Dano vai direto na Energia Física e ignora a armadura.</i>"
      : "<b>FALHA:</b> " + efeito;
  }
  if (dados.modo === "cor") {
    msg += "<br><i>Para habilidades, interprete a cor conforme a regra do livro (Sucesso/Fracasso e Nível de Dificuldade).</i>";
  }
  await ChatMessage.create({speaker: ChatMessage.getSpeaker(), content: msg});
}
