import assert from 'node:assert/strict';
import { validarEvocacao, validarCompraNivel, totalCreditosHistoricos } from '../module/validacoes.mjs';
import { pontosMagiaEstagio, pontosMagiaTotal } from '../module/magias.mjs';
import { PONTOS_GRUPO } from '../module/dados.mjs';
import { karmaDe, PROFISSOES } from '../module/tabelas.mjs';
const base={dificuldades:[1,3,5],nivel:5,dificuldade:3,gasto:3,karma:10,estagio:5};
assert.equal(validarEvocacao(base),null);
for(const alteracao of [{dificuldade:2},{dificuldade:6},{gasto:2},{gasto:6},{karma:2},{gasto:2.5}])
  assert.notEqual(validarEvocacao({...base,...alteracao}),null);
assert.equal(validarCompraNivel({nivelAtual:1,estagio:3,custo:2,disponiveis:5,gastos:3}),null);
for(const a of [{nivelAtual:3},{gastos:4},{custo:0},{nivelAtual:-1}])
  assert.notEqual(validarCompraNivel({nivelAtual:1,estagio:3,custo:2,disponiveis:5,gastos:3,...a}),null);
assert.equal(totalCreditosHistoricos([2,3,4],2),5);
assert.equal(totalCreditosHistoricos([{geral:2},{geral:3}],2,'geral'),5);
assert.equal(totalCreditosHistoricos([2],2),null);
assert.equal(totalCreditosHistoricos([2,-1],2),null);
assert.equal(totalCreditosHistoricos([{geral:2},{}],2,'geral'),null);
assert.equal(pontosMagiaTotal(10,3),[1,2,3].reduce((s,e)=>s+pontosMagiaEstagio(10,e),0));
assert.equal(pontosMagiaEstagio(10,11),null);
for(const p of PROFISSOES) assert.ok(PONTOS_GRUPO[p] && Object.keys(PONTOS_GRUPO[p]).length===5,p);
for(const aura of [2,8,12,20]) for(const e of [1,5,10]) assert.ok(Number.isFinite(karmaDe(aura,e)));
console.log('Auditoria 0.14.8: validações, históricos, pontos de magia, profissões e Karma OK.');
