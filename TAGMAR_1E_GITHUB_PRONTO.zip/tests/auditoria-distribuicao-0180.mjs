import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'system.json'), 'utf8'));
assert.equal(manifest.id, 'tagmar1e');
assert.equal(manifest.version, '0.18.0');
assert.equal(manifest.compatibility.verified, '14');
for (const file of [...manifest.esmodules, ...manifest.styles, 'README.md', 'VALIDACAO_0.18.0.md', 'ALTERACOES_0.18.0.md']) {
  assert.ok(fs.statSync(path.join(root, file)).isFile(), `Ausente: ${file}`);
}
for (const file of ['templates/actor.hbs', 'templates/item.hbs']) {
  if (fs.existsSync(path.join(root, file))) assert.ok(fs.statSync(path.join(root, file)).size > 0);
}
console.log('Auditoria de distribuição 0.18.0: OK');
