import assert from 'node:assert/strict';
import {sugestaoDanoParaAlvo} from '../module/rolagens.mjs';
assert.equal(sugestaoDanoParaAlvo(null), null);
assert.equal(sugestaoDanoParaAlvo({id:'alvo',actor:{uuid:'Actor.x'}}), null);
console.log('Auditoria 0.17.2: sem sugestão não há dano implícito.');
