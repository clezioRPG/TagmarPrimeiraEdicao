import assert from 'node:assert/strict';
import {validarSaldoCompra,validarCompraNivel,validarEvocacao,estadoHistorico,totalCreditosHistoricos} from '../module/validacoes.mjs';
for (const creditos of [0,1,2,7,15]) for (const gastos of [0,1,3,8,20]) for (const custo of [1,2,4,9]) {
 const r=validarSaldoCompra({creditos,gastos,custo});
 assert.equal(r===null, gastos<=creditos && creditos-gastos>=custo);
}
assert.match(validarSaldoCompra({creditos:5,gastos:6,custo:1}),/ultrapassam/);
assert.match(validarSaldoCompra({creditos:5,gastos:1,custo:1.5}),/inválido/);
assert.match(validarCompraNivel({nivelAtual:0,estagio:3,custo:1,disponiveis:-1,gastos:0}),/inválidos/);
assert.match(validarEvocacao({dificuldades:[1],nivel:1,dificuldade:1,gasto:1,karma:-1,estagio:1}),/não existe|inteiros|insuficiente/);
assert.equal(estadoHistorico([{geral:2}],1,[]),'invalido');
assert.equal(estadoHistorico([{geral:2}],1,['geral']),'valido');
assert.equal(totalCreditosHistoricos([{geral:2},{geral:3}],2,'geral'),5);
assert.equal(totalCreditosHistoricos([{geral:2},{geral:-3}],2,'geral'),null);
console.log('Auditoria 0.15.0: limites de saldo, validação de evocação e históricos OK.');
