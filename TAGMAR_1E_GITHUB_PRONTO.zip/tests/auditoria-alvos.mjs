import assert from 'node:assert/strict';
import {alvoDeCombate} from '../module/rolagens.mjs';
assert.equal(alvoDeCombate([]), null);
assert.equal(alvoDeCombate([{},{}]), null);
assert.equal(alvoDeCombate([{name:'Goblin',actor:{system:{defesa:12}}}]).defesa, 12);
assert.equal(alvoDeCombate([{name:'Teste',actor:{system:{defesa:40}}}]).defesa, 21);
assert.equal(alvoDeCombate([{name:'Teste',actor:{system:{defesa:'?'}}}]), null);
console.log('Auditoria 0.17.0: selecao e defesa de alvos OK.');
