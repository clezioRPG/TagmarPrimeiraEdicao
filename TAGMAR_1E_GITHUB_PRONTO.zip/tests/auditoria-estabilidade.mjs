import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const raiz = path.resolve(import.meta.dirname, '..');
const sistema = JSON.parse(fs.readFileSync(path.join(raiz,'system.json'),'utf8'));
assert.equal(sistema.version,'0.18.0');
assert.equal(sistema.id,'tagmar1e');
assert.equal(sistema.compatibility.verified,'14');
for (const arquivo of ['tagmar1e.mjs','module/sheet.mjs','module/item-sheet.mjs','module/token-bars.mjs','module/magias.mjs','templates/item.hbs','styles/tagmar.css']) {
  assert.ok(fs.existsSync(path.join(raiz,arquivo)),`Arquivo ausente: ${arquivo}`);
}
const token = fs.readFileSync(path.join(raiz,'module/token-bars.mjs'),'utf8');
assert.match(token,/preCreateToken/);
assert.match(token,/displayBars: SEM_BARRAS/);
assert.match(token,/updateEmbeddedDocuments\('Token'/);
const sheet = fs.readFileSync(path.join(raiz,'module/sheet.mjs'),'utf8');
assert.match(sheet,/configurePrototypeToken/);
assert.match(sheet,/selecionarRetrato/);
const item = fs.readFileSync(path.join(raiz,'templates/item.hbs'),'utf8').trim();
assert.match(item,/^<[^!]/);
assert.match(item,/<\/[^>]+>\s*$/);
const app = fs.readFileSync(path.join(raiz,'tagmar1e.mjs'),'utf8');
assert.match(app,/diagnosticarSistema/);
console.log('Auditoria 0.16.8: estrutura, integrações críticas e diagnóstico OK.');
