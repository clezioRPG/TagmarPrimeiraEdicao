import assert from 'node:assert/strict';
import fs from 'node:fs';
const s=fs.readFileSync(new URL('../module/painel-combate.mjs',import.meta.url),'utf8');
assert.match(s,/Somente o Mestre pode alterar o combate/);
assert.match(s,/await combatente\.setFlag\("tagmar1e", "condicoesPainel", lista\);\s*try \{\s*await criarEfeitoMarcador/);
assert.match(s,/lista\.filter\(m => m\.id !== marcador\.id\)/);
assert.match(s,/marcadorPainelId/);
assert.match(s,/changes: \[\]/);
console.log('Painel: guarda de Mestre, reversão de inclusão e efeitos informativos verificados.');
